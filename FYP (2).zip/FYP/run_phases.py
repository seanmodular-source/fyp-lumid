"""One command that rebuilds everything.

    python -m FYP.run_phases              # full study, ~20-25 minutes
    python -m FYP.run_phases --quick      # smoke test, a few minutes
    python -m FYP.run_phases --phase 2    # a single phase; 5, 6 and 7 include 5b, 6b
                                          # and 7b, which can also be run alone

Writes to FYP/artifacts (FYP/artifacts_quick with --quick):
    phase*_*.csv, bottom_line_*.csv   every table in the study
    figures/*.png       every figure
    verdict.txt         the auto-generated conclusion
"""
from __future__ import annotations

import argparse
import os
import sys

import matplotlib
matplotlib.use("Agg")                       # headless: write files, open nothing
matplotlib.rcParams["figure.max_open_warning"] = 0   # every figure is built, then saved

from . import phases as P
from .plots import build_figures, use_style


def save_figures(res: dict) -> list[str]:
    os.makedirs(P.FIGURES, exist_ok=True)
    use_style()
    paths = []
    for name, fig in build_figures(res).items():
        path = os.path.join(P.FIGURES, f"{name}.png")
        fig.savefig(path, dpi=150, bbox_inches="tight")
        paths.append(path)
    return paths


def _phase5_and_holdout(cfg) -> dict:
    """Phase 5 and the fresh holdout that re-scores its picks (phase 5b)."""
    p5 = P.phase5_real(cfg)
    p5h = P.phase5_holdout(cfg, p5)
    return {**p5, **{f"holdout_{k}": v for k, v in p5h.items()}}


def _lab_phases(cfg, which: str) -> dict:
    """Phases that need the phase 1 lab and the phase 2 arms."""
    p1 = P.phase1_lab(cfg)
    p2 = P.phase2_frontiers(p1["lab"], cfg)
    if which == "2":
        return p2
    out = {}
    if which == "7":
        out.update(P.phase7_benchmarks(p1["lab"], cfg, p2))
    if which in ("7", "7b"):
        out.update({f"factorial_{k}": v for k, v in
                    P.phase7b_factorial(p1["lab"], cfg, p2).items()})
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="When to trade, and how far to move: the rebalancing study")
    ap.add_argument("--quick", action="store_true", help="small, fast smoke run")
    ap.add_argument("--phase", type=str, default=None,
                    help="run one phase only: 1-8, or 5b, 6b, 7b")
    ap.add_argument("--paths", type=int, default=None, help="override Monte-Carlo paths")
    ap.add_argument("--bars", type=int, default=None, help="override bars per path")
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args(argv)

    # Scale first, then apply overrides, then clear `quick` so that the
    # phases (which each call cfg.scaled() again) do not shrink it back.
    cfg = P.PhaseConfig(quick=args.quick).scaled()
    if args.paths:
        cfg.n_paths = args.paths
    if args.bars:
        cfg.n_bars = args.bars
    cfg.quick = False

    if args.quick:
        # A smoke run must never overwrite the real results. Without this,
        # `--quick` would silently replace every table and figure with
        # 64-path versions -- including the figures a report or deck embeds.
        # The download cache is deliberately shared, so a smoke run stays
        # offline-friendly.
        P.ARTIFACTS = P.ARTIFACTS + "_quick"
        P.FIGURES = os.path.join(P.ARTIFACTS, "figures")
        print(f"quick mode: writing to {P.ARTIFACTS} (real artifacts untouched)")

    if args.phase is not None:
        phase = args.phase.lower()
        runner = {
            "1": lambda: P.phase1_lab(cfg),
            "3": lambda: P.phase3_execution(cfg),
            "4": lambda: P.phase4_power(cfg),
            "5": lambda: _phase5_and_holdout(cfg),
            "5b": lambda: _phase5_and_holdout(cfg),     # 5b re-scores phase 5's picks
            "6": lambda: {**P.phase6_regime_map(cfg),
                          **{f"shape_{k}": v for k, v in P.phase6b_cost_shape(cfg).items()}},
            "6b": lambda: P.phase6b_cost_shape(cfg),
        }
        if phase in runner:
            out = runner[phase]()
        elif phase in ("2", "7", "7b"):
            out = _lab_phases(cfg, phase)
        elif phase == "8":
            out = P.run_all(cfg)["p8"]          # the verdict needs every phase
        else:
            print(f"unknown phase {args.phase}", file=sys.stderr)
            return 2
        for key, value in out.items():
            if not key.startswith("_") and hasattr(value, "to_string"):
                print(f"\n=== {key} ===")
                print(value.round(4).to_string(index=False))
        return 0

    res = P.run_all(cfg)

    os.makedirs(P.ARTIFACTS, exist_ok=True)
    with open(os.path.join(P.ARTIFACTS, "verdict.txt"), "w", encoding="utf-8") as fh:
        fh.write(res["p8"]["text"] + "\n")

    if not args.no_figures:
        print("\nwriting figures ...")
        for path in save_figures(res):
            print("  " + os.path.relpath(path, P.ARTIFACTS))

    print(f"\nartifacts -> {P.ARTIFACTS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
