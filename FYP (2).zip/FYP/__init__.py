"""BT4101 FYP: when to trade, and how far to move.

The question: for a fixed alpha, is the value of a closed-loop rebalancing rule
in WHEN it trades (an event trigger instead of a clock) or in HOW FAR it moves
(part of the way instead of all the way)? Alpha, sizing and costs are held
identical across arms, so the rule is the only thing that varies, and every
rule exposes both decisions (`trigger`, `move_fraction`) so they can be varied
one at a time.

The answer, in the simulated market: feedback beats the clock, but through
pacing, not picking the moment. Moving part of the way each day spreads every
rebalance over several days, and that carries almost all of the gain, whatever
the trigger. Moving all the way, no event trigger beats a calendar trading as
much, and with the move size held fixed none beats the calendar at any move
size. The pace is set per strategy from costs (fees, spread, impact against
volume) and how fast the signal fades. Phase 6b asks when picking the moment
starts to pay: how cost grows with trade size, and a fixed fee per order.

Architecture (five swappable interfaces, so a new rule or a new alpha is a
one-line change):

    AlphaProvider  -> target weights          alpha.py, generator.py
    Scheduler      -> when to trade, how far  schedulers.py
    Cost / Execution -> what it costs         costs.py, microstructure.py
    Simulator      -> NAV, turnover, cost     core.py
    Evaluator      -> metrics, CIs, power     evaluation.py

Module map:
    core.py           vectorised drifting-book simulator, batched over paths
    schedulers.py     the rules: every trigger x every move fraction
    generator.py      synthetic market with alpha calibrated to Sharpe 1.0
    alpha.py          real-data alpha providers and sizing
    data.py           BTC/ETH download from Yahoo Finance
    costs.py          spread + fees + square-root impact + order fee; cost shapes
    microstructure.py intra-bar execution: TWAP, VWAP, POV, Almgren-Chriss
    evaluation.py     metrics, attribution, frontier selection, power analysis
    portfolio.py      equal-risk-contribution sizing
    plots.py          every figure in the study
    phases.py         phases 1-8 (with 5b, 6b, 7b) and the bottom line
    run_phases.py     one command: python -m FYP.run_phases
    tests.py          invariants: no look-ahead, drift, cost, ruin, sizing, axes
    research.ipynb    the notebook: hypothesis, references, results, verdict

Real data: BTC-USD and ETH-USD daily closes and volumes from Yahoo Finance.
"""
