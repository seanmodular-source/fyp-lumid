"""Equal-risk-contribution sizing.

Sizing is kept separate from timing, so the scheduler is the only thing that
varies between arms.

With exactly two assets (BTC and ETH) ERC reduces to inverse-volatility
weighting for *any* correlation, so the real-data leg cannot tell the two
allocators apart. The synthetic lab does not use ERC: it vol-targets on a known
equicorrelated covariance, where ERC = inverse-vol = 1/N anyway.
"""
from __future__ import annotations
import numpy as np


def risk_parity_cov(cov: np.ndarray, budgets: np.ndarray | None = None,
                    iters: int = 200, tol: float = 1e-10) -> np.ndarray:
    """Equal Risk Contribution weights from a covariance matrix.

    Uses the damped multiplicative fixed point

        w_i  <-  sqrt( w_i * b_i / (Sigma w)_i ) ,   then renormalise,

    whose fixed point satisfies w_i (Sigma w)_i = const * b_i, i.e. risk
    contributions proportional to the budgets b. Long-only, sums to one. The
    square root is the geometric mean of the current iterate and the undamped
    step b_i/(Sigma w)_i; it removes the oscillation that makes the undamped
    version crawl (500 iterations without converging on a 9-asset covariance)
    and typically converges in a few dozen.

        Maillard, Roncalli & Teiletche (2010), "The properties of equally
        weighted risk contribution portfolios", JPM 36(4), 60-70.
        Spinu (2013), "An algorithm for computing risk parity weights", SSRN.

    NOTE (this replaces a gradient-descent version with a fixed learning rate):
    that earlier solver took steps of size lr * (risk contribution error). On
    daily-return covariances the error terms are O(1e-4), so the weights moved
    by O(1e-6) in total and the function silently returned 1/N. Any experiment
    that compared 1/N against "risk parity" was therefore comparing 1/N with
    itself. This iteration is scale-invariant: multiplying the covariance by
    any constant leaves the answer unchanged.
    """
    cov = np.asarray(cov, dtype=float)
    n = cov.shape[0]
    if n == 0:
        return np.zeros(0)
    if n == 1:
        return np.ones(1)
    b = np.ones(n) / n if budgets is None else np.asarray(budgets, float) / np.sum(budgets)

    # Start from inverse-vol, which is already the exact answer when all
    # correlations are equal (and, for n = 2, the exact answer always).
    vol = np.sqrt(np.maximum(np.diag(cov), 1e-24))
    w = (1.0 / vol) / np.sum(1.0 / vol)
    for _ in range(iters):
        mrc = cov @ w
        w_new = np.sqrt(w * b / np.maximum(mrc, 1e-24))
        s = w_new.sum()
        if s <= 0:
            break
        w_new /= s
        if np.max(np.abs(w_new - w)) < tol:
            return w_new
        w = w_new
    return w
