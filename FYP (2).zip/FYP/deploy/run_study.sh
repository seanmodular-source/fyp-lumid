#!/usr/bin/env bash
# Run the study inside the container.
#   run_study           -> invariant tests, then the full study (~20 min on a laptop)
#   run_study --quick   -> tests, then a small smoke run (written to artifacts_quick/)
# Results: /workspace/FYP/artifacts (or artifacts_quick). They are lost when the
# task ends, so copy them back with scp before stopping it.
set -euo pipefail
export PATH=/opt/venv/bin:$PATH MPLBACKEND=Agg
cd /workspace
python -m FYP.tests
python -m FYP.run_phases "$@"
