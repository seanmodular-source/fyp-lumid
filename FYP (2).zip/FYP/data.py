"""BTC and ETH daily prices and volumes from Yahoo Finance.

We use yfinance because it is free, reproducible and requires no API key, so
anyone can rebuild the exact same panel.

Volume units. Everywhere else in this package `volumes` means *units traded*
(coins), and dollar volume is computed as volume x price. Yahoo reports crypto
volume already in US dollars, so it is divided by the close once, here, to put
it in coins. Skipping that step multiplies by price twice and inflates BTC's
median daily dollar volume by roughly its price (~$449 trillion a day instead
of tens of billions), which silently sets market impact to zero.
"""
from __future__ import annotations
import pandas as pd
import yfinance as yf


def download_ohlcv(tickers: list[str], start: str, end: str, interval: str = "1d") -> dict[str, pd.DataFrame]:
    """Download one clean OHLCV DataFrame per ticker (indexed by UTC date).

    Only close and volume are kept downstream (align_panel); open, high and
    low are downloaded but not used anywhere in the study.
    """
    out: dict[str, pd.DataFrame] = {}
    for t in tickers:
        df = yf.download(
            t, start=start, end=end, interval=interval,
            progress=False, auto_adjust=False, group_by="column",
        )
        # yfinance sometimes returns a MultiIndex column layout even for a single
        # ticker. Flatten defensively.
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        df = df.rename(columns=str.lower)[["open", "high", "low", "close", "volume"]]
        df = df.dropna()
        # Force naive timestamps so alignment across tickers is trivial.
        df.index = pd.to_datetime(df.index).tz_localize(None)
        out[t] = df
    return out


def align_panel(ohlcv_by_ticker: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Align tickers on the intersection of dates.

    Returns two [T x N] frames: closes and volumes exactly as Yahoo reports
    them. Intersection avoids look-ahead from forward-filling missing bars.
    """
    closes = pd.concat({t: df["close"] for t, df in ohlcv_by_ticker.items()}, axis=1).dropna()
    volumes = pd.concat({t: df["volume"] for t, df in ohlcv_by_ticker.items()}, axis=1).reindex(closes.index)
    return closes, volumes


def dollar_volume_to_units(dollar_volumes: pd.DataFrame, closes: pd.DataFrame) -> pd.DataFrame:
    """Yahoo crypto volume is in dollars; convert it to coins traded."""
    return dollar_volumes / closes
