"""Transaction-cost model built from primitives, not from assumptions.

Multiplying a baseline slippage by a per-algorithm constant (a discount for
being "smart") assumes the answer to the question this project measures. Here
cost is assembled from three economically meaningful terms instead:

    cost = half-spread + fee          (proportional, paid on every unit traded)
         + eta * sigma * sqrt(Q/ADV)  (temporary market impact, square-root law)
         + order fee                  (fixed, paid once per order; 0 by default)

The square-root law is the most robust empirical regularity in market impact:
the cost of trading a parent order of size Q scales with the square root of
participation Q/ADV, multiplied by the asset's volatility.

    Toth, Lemperiere, Deremble, de Lataillade, Kockelkoren & Bouchaud (2011),
    "Anomalous price impact and the critical nature of liquidity",
    Physical Review X 1, 021006.
    Almgren & Chriss (2000), "Optimal execution of portfolio transactions",
    Journal of Risk 3(2), 5-39.

Everything is expressed as a fraction of NAV so it can be subtracted directly
from a portfolio return.

How cost grows with the size of a trade is what decides whether *when* or *how
far* matters more (phase 6b). Proportional costs make splitting a trade free of
charge and favour a no-trade band; convex costs (impact) make one large trade
dearer than several small ones and favour partial moves; a fixed fee per order
makes every trade dear however small and favours trading rarely.
`equal_cost_shapes` builds the three shapes at the same price for a typical
trade, so only the shape differs.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np


ORDER_DUST = 1e-9          # a weight change below this is not an order


@dataclass
class CostModel:
    """Proportional costs plus optional square-root impact.

    fee_bps          : exchange/broker fee per unit notional traded.
    half_spread_bps  : half the quoted bid-ask spread (cost of crossing).
    impact_eta       : Y in the square-root law; empirically ~0.5-1.0.
    impact_exponent  : 0.5 reproduces the square-root law; 1.0 gives linear
                       (Kyle) impact. Exposed so the exponent can be stressed.
    enable_impact    : False -> purely proportional costs, which is the regime
                       in which the no-trade-band policy is provably optimal
                       (Constantinides 1986; Davis & Norman 1990).
    order_fee_bps    : fixed charge per order, in bps of NAV, one order per
                       asset traded (a $5 ticket on a $100k book is 0.5 bps).
                       The cost of *acting* rather than of trading volume.
    """

    fee_bps: float = 1.0
    half_spread_bps: float = 2.0
    impact_eta: float = 0.5
    impact_exponent: float = 0.5
    enable_impact: bool = True
    order_fee_bps: float = 0.0

    # ---- proportional part -------------------------------------------------

    @property
    def linear_bps(self) -> float:
        """Cost in bps charged on every unit of notional traded."""
        return self.fee_bps + self.half_spread_bps

    # ---- full model --------------------------------------------------------

    def trade_cost(
        self,
        dw: np.ndarray,
        notional: np.ndarray | float,
        adv: np.ndarray | None = None,
        sigma: np.ndarray | float = 0.0,
    ) -> np.ndarray:
        """Cost of a rebalance, as a fraction of NAV.

        dw       : (..., N) weight change per asset (signed).
        notional : (...,) or scalar portfolio notional in currency units.
        adv      : (..., N) average daily dollar volume per asset.
        sigma    : (..., N) or scalar per-bar volatility of each asset.

        Returns (...,) cost as a fraction of NAV.
        """
        traded = np.abs(dw)
        cost = traded.sum(axis=-1) * (self.linear_bps * 1e-4)
        if self.order_fee_bps:
            orders = (traded > ORDER_DUST).sum(axis=-1)
            cost = cost + orders * (self.order_fee_bps * 1e-4)

        if not self.enable_impact or adv is None:
            return cost

        notional_arr = np.asarray(notional, dtype=float)
        if notional_arr.ndim > 0:
            notional_arr = notional_arr[..., None]
        # Participation rate of the parent order in each asset.
        # No upper clip: an order larger than a day's volume costs *more*,
        # not the same. Capping at 1.0 would silently understate impact in
        # exactly the capacity stress test where the number matters most.
        participation = np.maximum(
            traded * notional_arr / np.maximum(adv, 1e-12), 0.0
        )
        impact = self.impact_eta * np.asarray(sigma) * participation ** self.impact_exponent
        # Impact is a price concession paid on the traded notional only.
        return cost + (traded * impact).sum(axis=-1)

    # ---- reporting ---------------------------------------------------------

    def effective_bps(
        self, participation: float, sigma: float
    ) -> float:
        """Round-trip-free cost in bps for one unit traded at a participation
        rate -- used to build the cost curves shown in the notebook."""
        bps = self.linear_bps
        if self.enable_impact:
            bps += 1e4 * self.impact_eta * sigma * participation ** self.impact_exponent
        return bps


# ---- cost shapes -----------------------------------------------------------


def equal_cost_shapes(base: CostModel, participation: float,
                      sigma: float) -> dict[str, CostModel]:
    """Three cost models that charge the same per unit on a typical trade.

    participation : the typical trade's size as a share of daily volume
                    (phase 6b uses the median trade of the benchmark).
    sigma         : the typical per-bar volatility.

    proportional  : impact replaced by a flat charge equal to its value at the
                    typical size, so a trade of any size pays the same rate;
    square-root   : `base` itself, total cost ~ size^1.5;
    linear impact : impact linear in participation, total cost ~ size^2 (the
                    quadratic cost of Garleanu & Pedersen 2013), with eta set
                    so the typical trade pays exactly what it pays in `base`.

    Smaller trades pay least under linear impact and most under proportional
    costs; that ordering is the experiment.
    """
    p = max(float(participation), 1e-12)
    per_unit_bps = 1e4 * base.impact_eta * float(sigma) * p ** base.impact_exponent
    return {
        "proportional": replace(base, half_spread_bps=base.half_spread_bps + per_unit_bps,
                                enable_impact=False),
        "square-root": base,
        "linear impact": replace(base, impact_exponent=1.0,
                                 impact_eta=base.impact_eta * p ** (base.impact_exponent - 1.0)),
    }


# ---- presets -------------------------------------------------------------
#   lab           : the synthetic laboratory (phases 1-3, 6, 7). A cheap, liquid
#                   market, so cost and staleness are of comparable size and
#                   the scheduler question is not decided by cost alone.
#   crypto_retail : BTC and ETH on real prices (phase 5), at public estimates
#                   of a retail taker's all-in cost.

COST_PRESETS: dict[str, CostModel] = {
    "lab": CostModel(fee_bps=0.5, half_spread_bps=1.0, impact_eta=0.5),
    "crypto_retail": CostModel(fee_bps=2.0, half_spread_bps=2.0, impact_eta=0.5),
}
