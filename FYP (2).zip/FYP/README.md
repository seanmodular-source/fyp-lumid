# When to Trade, and How Far to Move

**BT4101 Final Year Project.** Should a portfolio trade every time its signal changes,
on a fixed calendar, or only when it has drifted far enough from where it should be?
This repository holds the full study: the hypothesis, the data, the method, the code,
the results and their limits.

New to the project? [OVERVIEW.md](OVERVIEW.md) explains it step by step in plain words.

---

## The answer in one paragraph

**Feedback beats the clock - but the timing that works is pacing the trade, not picking
the moment.** With the same signal and the same costs, moving only a quarter of the way to
the target each day - so each rebalance is spread over several days (half done in about 2.4
days) - earned a net Sharpe of **0.89 against 0.78** for the trade-every-change benchmark
(+0.11, 95% interval +0.08 to +0.15) while trading **58% less**, and 98% of that gain
comes from the pacing. Crossing five triggers with three move sizes confirms
it is general: holding the move fixed, **no trigger beats a calendar**; holding the
trigger fixed, **moving part of the way wins by +0.11 for every trigger**. Changing only
the shape of trading costs shows why and where it stops: the more convex the cost, the
more moving part of the way is worth (+0.03 / +0.12 / +0.44 under proportional /
square-root / linear impact), and only a **fixed fee per order** makes picking the
moment earn anything. On real BTC/ETH the rule was ahead of the benchmark out of sample on both
signals, and again on fresh 2025-26 data with every choice frozen since 2021 - significantly
in 3 of those 4 tests.

**The practical lesson.** A systematic strategy should not trade its signal blindly - all
the way, every time it changes. It should pace each rebalance, at a speed set by what trading
costs (fees, spread, and market impact, which depends on trade size against daily volume)
and by how fast the signal's value fades, chosen on past data and then frozen.

### What the comparisons add

Partial adjustment itself is well studied (Garleanu and Pedersen 2013). The contribution
here is what the comparisons say about two kinds of timing: **pacing** a trade over
several days (the move fraction) and **picking the moment** to trade (the trigger):

| # | Finding | Evidence |
|---|---|---|
| 1 | **Picking the moment does not transfer to costly rebalancing.** Moving all the way, no trigger beats a calendar trading exactly as much; with the move size held fixed, none beats the calendar at any move size | Phase 7: best full-move trigger +0.006 [-0.025, +0.037]; Phase 7b: -0.007 / -0.006 / -0.002 at move fractions 1 / 0.5 / 0.25 |
| 2 | **Better than random is not better than regular.** A band trigger beats random times at its own rate but only ties a calendar trading as much | +0.052 [+0.026, +0.078] vs random; -0.001 [-0.025, +0.023] vs calendar |
| 3 | **Pacing works whatever the trigger**, and once moves are partial every trigger's best setting fires on most days - every trigger turns into pacing | Phase 7b: +0.107 to +0.114 for all 5 triggers; best partial rules trade on 75-98% of days |
| 4 | **Pacing wins more the more convex the cost; a fee per order erodes it, and only then does picking the moment earn something** | Phase 6b: how far +0.03 / +0.12 / +0.44; when at most +0.016 without a fee, up to +0.09 with one |
| 5 | **Picking the moment's one apparent exception was noise** | Phase 6: +0.12 in the grid, +0.05 [-0.02, +0.12] on 256 fresh paths |

These are post-hoc (designed after the criteria were scored) and reported as findings,
never as criteria.

![Scorecard](artifacts/figures/00a_scorecard.png)

*Numbers in this README come from the run in `artifacts/`; `python -m FYP.run_phases`
regenerates every one of them.*

---

## 1. The problem

A trading signal says which portfolio to hold, and it keeps changing.

* **Trade every time it changes** and you pay fees, spread and market impact on every
  small update.
* **Trade rarely** and you hold a stale portfolio that no longer matches the signal.

Every implementation splits a fixed budget between these two losses:

```
net Sharpe = paper Sharpe   - tracking loss   - cost drag
             (free trading)   (being stale)     (paying to trade)
```

The question is which rule makes that split best.

## 2. Research question and hypothesis

**Question.** For a fixed signal, does a rebalancing rule whose trigger and trade size
depend on the state of the portfolio (*closed loop*) beat one that trades on a clock
(*open loop*) once costs, signal decay and market impact are all included?

**Hypothesis (H1).** A closed-loop rule delivers a higher net Sharpe than an open-loop
rule **at equal annual turnover**, and the advantage is largest where staleness is
expensive (fast signals) and trading is expensive (high costs).

**Null (H0).** At equal turnover, the closed-loop rule is no better than a calendar.

H1 is kept exactly as registered. **Its answer: supported in its claim, corrected in its
mechanism.** Feedback does beat the clock (C1, C4), but not through the trigger: the gain
comes from *pacing* - moving part of the way each day, which spreads every rebalance over
several days - not from *picking the moment* to trade. Once the results showed this, two
exploratory questions were added (phases 7b and 6b): is that true for every trigger and
move size, and under which trading costs does picking the moment start to matter?

**Theoretical anchor.** Astrom and Bernhardsson (2002) proved that, for a first-order
stochastic system, event-based (Lebesgue) sampling achieves lower error than periodic
(Riemann) sampling at the same average rate. This project asks whether that result
survives trading costs, signal decay and market impact.

**Pass/fail criteria** (C1, C2, C3 and C5 fixed before the results; C4 see note; all scored automatically):

| | Criterion | Passes if |
|---|---|---|
| C1 | Closed loop beats open loop across turnover budgets | significant at >= 3 budgets |
| C2 | The trigger beats random timing | p < 0.05 against a matched placebo |
| C3 | The mechanism behaves as predicted | advantage rises with burstiness; price-detector edge rises with coupling |
| C4 | The ordering survives on real prices | beats the benchmark out of sample on BTC/ETH, both signals* |
| C5 | Execution savings are measured, not assumed | measured saving with timing risk quantified |

\*C4 originally read ">= 2 asset classes"; it was amended when the study was narrowed
to BTC/ETH. The crypto results of the earlier multi-asset run were already known by then,
so C4 is a post-hoc check, not a pre-registered one.

## 3. Proposed solution

Replace the clock with feedback. The rules tested, grouped by what decides "is moving
worth it?":

| Family | Trigger | Loop | Reference |
|---|---|---|---|
| clock | time elapsed (incl. **AlwaysTrade**, the benchmark) | open | industry practice |
| activity | volume traded | open | Ane and Geman (2000); Easley et al. (2012) |
| price-event | volatility-scaled CUSUM on prices | closed | Page (1954); Lopez de Prado (2018) ch. 2 |
| target-event | cumulative motion of the target book | closed | this project |
| **state-feedback** | gap between book and target: **no-trade band**, **partial adjustment** | closed | Constantinides (1986); Davis and Norman (1990); Garleanu and Pedersen (2013) |
| control | buy-and-hold, random timing | - | placebo |

**Partial adjustment** (the recommended rule) trades each day toward the target, but only
a fixed fraction `lambda` of the gap: `new = old + lambda x (target - old)`. Garleanu and
Pedersen (2013) show that under quadratic costs the optimal policy trades a constant
fraction of the way toward an *aim* portfolio; this rule is the simplified version that
aims at the current target.

**Two decisions, made explicit.** The families above bundle two choices. In the code every
rule states both, so they can be crossed (phase 7b):

| Decision | Attribute | Values |
|---|---|---|
| WHEN to trade | `trigger` | clock, activity, price-event, target-event, gap |
| HOW FAR to move | `move_fraction` | 1.0 (all the way), 0.5, 0.25 (part of the way); none for a move to a band edge |

Seen this way, partial adjustment is a *clock* rule (it trades every day) whose feedback is
entirely in how far it moves. Over several days, though, how far it moves each day *is* a
timing decision: closing a quarter of the gap a day spreads each rebalance across time.
The study therefore compares two kinds of timing - **pacing** the trade and **picking the
moment**. Where a phase or test name says "timing" (pure timing test, random-timing placebo,
timing recheck), it means picking the moment.

## 4. Inputs

### 4a. The simulated market (the main experiment)

Real data cannot separate "a better rule" from "a luckier signal", so the main test runs
in a market where the signal's quality is known exactly.

| Setting | Value |
|---|---|
| Paths (independent histories) | 256, split 40% calibration / 60% evaluation |
| Length | 1,008 daily bars (4 years), 252 bars per year |
| Assets | 6 |
| Signal | AR(1) latent alpha, 10-bar half-life, calibrated so trading it free earns **Sharpe 1.00** |
| Information arrival | burstiness 0.6 (clustered, per Cont 2001), coupling 0.4 |
| Book | $10m, weights proportional to the signal, scaled to a 15% volatility target, max gross 2x |
| Costs (`lab`) | 0.5 bp fee + 1 bp half-spread + square-root impact (eta 0.5) |
| Cost shapes (phase 6b) | proportional / square-root / linear impact, each charging the same per unit on the benchmark's typical trade (0.04% of daily volume, 3.6 bps); plus a fee per order of 0, 0.1 or 0.5 bps of NAV |
| Execution | decision at close t, fill at close t+1 |

### 4b. Real data (the reality check)

| Setting | Value |
|---|---|
| Assets | BTC-USD, ETH-USD |
| Source | Yahoo Finance via `yfinance` (free, no key, reproducible); cached in `artifacts/cache/` |
| Period | 2017-11-09 to 2024-12-31 (2,610 days; Yahoo's crypto history starts Nov 2017) |
| Fields | daily close, daily volume (Yahoo reports crypto volume in USD; converted to coins once in `data.py`) |
| Calendar | 365 bars per year |
| Split | first half (2017-11-09 to 2021-06-05) picks each rule's setting; second half (2021-06-06 to 2024-12-31, 3.6 years) scores it |
| Fresh holdout | 2025-01-01 to 2026-10-10 (648 days): data from after the study's sample, scored with every choice frozen (Phase 5b). Not a pass/fail criterion, since it was added after the results were known |
| Signals | **Controlled** (future returns + noise, calibrated to Sharpe 1.0 - a measuring tool that peeks on purpose) and **Momentum(20)** (no look-ahead) |
| Costs (`crypto_retail`) | 2 bps fee + 2 bps half-spread + square-root impact (eta 0.5) |
| Book | $10m, long one coin / short the other, 15% volatility target |

## 5. Methodology

```
 signal (fixed, known quality)
        |
        v
 target portfolio  --->  ~77 rebalancing rules  --->  simulator (drift, costs, impact, 1-bar lag)
                          same prices for all              |
                          (common random numbers)          v
                                                    net Sharpe, turnover, drawdown per path
                                                           |
                 +-----------------------------------------+-----------------------------+
                 v                                         v                             v
   compare at EQUAL turnover               split gain: WHEN vs HOW FAR        pass/fail criteria C1-C5
   (calendar interpolated to match)        (random-timing placebo)            (scored automatically)
                                                           |
                                                           v
                                  every trigger x every move fraction (7b), and the
                                  same again for each cost shape x fee per order (6b):
                                  best rule against best rule; findings F1-F9, unscored
```

| Phase | Question | What it does |
|---|---|---|
| 1 | Is the laboratory honest? | Builds the simulated market; solves the signal strength so free trading earns Sharpe 1.00 on calibration paths, then checks it on held-out paths (1.05, 95% interval 0.97 to 1.13) |
| 2 | Which rule family is best? | Runs every rule on the same paths; draws net Sharpe vs turnover; compares closed vs open loop within each turnover budget and at exactly equal turnover |
| 3 | What does a trade really cost? | Slices orders through the day (TWAP, VWAP, POV, Almgren-Chriss) against simulated flow; measures implementation shortfall |
| 4 | Could real data even show it? | Compares the effect available with the smallest effect one price history can detect |
| 5 | Does it hold on real prices? | BTC/ETH, rule picked on the first half, scored on the second, block-bootstrap intervals |
| 5b | Does it still work in recent years? | The same picks, frozen, scored on 2025-26 data that did not exist when they were made |
| 6 | Where does it win, and why? | Grids over signal speed x cost, and burstiness x coupling - predictions that could fail; picking the moment's best grid cell rebuilt on 256 fresh paths |
| 6b | When does *when* matter? | Cost shape (proportional / square-root / linear impact, equal cost on a typical trade) x fee per order; every trigger x every move fraction in each cell, 192 paths |
| 7 | Does it beat the benchmarks? | Head to head vs AlwaysTrade and calendars; WHEN / HOW FAR split; 120-draw random-timing placebo |
| 7b | Is it the same for every rule? | Five triggers x three move fractions (141 rules) on the phase 2 lab; WHEN at fixed move, HOW FAR at fixed trigger |
| 8 | Did it pass? | Scores C1-C5 from the tables; lists the exploratory findings F1-F9 beside them, unscored |
| Bottom line | Should we use it? | Seven plain-language charts (scorecard, every budget, real BTC/ETH, gain split, when x how far, sensitivity, still working in 2025-26) and a generated recommendation |

**How the comparison is kept fair**

* **Same signal, same costs, same prices** for every rule, so any difference is the rule.
* **Trading less is never a free win.** Timing claims are tested against a calendar
  interpolated to trade exactly as much; the other comparisons either share a turnover
  budget or let both sides choose their best trading level.
* **No hindsight.** Settings are chosen on calibration paths (or the first half of the
  real sample) and scored on different ones.
* **A matched placebo** copies the rule's trade rate and move size and randomises only
  the timing.
* **Best against best** in the factorial (phases 6b, 7b): each design's setting is picked on
  calibration paths by its own Sharpe. (Picking the setting with the largest advantage *at
  equal turnover* finds the turnover where the reference is weakest, not a rule anybody
  would run; equal turnover remains the test for one rule against a calendar.)
* **Power first.** Phase 4 says in advance which experiments can detect the effect at all.
* **Invariant tests** (`tests.py`, 25 tests) pin down no look-ahead, weight drift, cost
  accounting, absorbing ruin, risk-parity correctness, volume units, the order fee, the
  cost shapes and the when / how-far axes.

## 6. Outputs

| Output | Where |
|---|---|
| The notebook: hypothesis, every phase, the bottom line, limitations | `research.ipynb` |
| Every table, as CSV | `artifacts/phase*_*.csv`, `artifacts/bottom_line_*.csv` |
| Every figure, as PNG | `artifacts/figures/` |
| The automatic verdict | `artifacts/verdict.txt` |

### Key charts

**At every trading budget, the feedback rule earns more**

![Every budget](artifacts/figures/00b_every_budget.png)

**Real BTC/ETH, out of sample** (both rules picked on 2017-2021; compare the Sharpe ratios
in the legend, since a line can end higher by taking more risk)

![Real BTC/ETH](artifacts/figures/00c_real_btc_eth.png)

**Where the gain comes from**

![Gain split](artifacts/figures/00d_gain_split.png)

**Not one rule: every trigger x every move size (phase 7b)**

![When vs how far](artifacts/figures/00f_when_vs_how_far.png)

**When picking the moment starts to matter: cost shape x fee per order (phase 6b)**

![Cost shape](artifacts/figures/07d_cost_shape.png)

**Why: at the same trading level, moving part of the way is less stale and pays less**

![Staleness vs cost](artifacts/figures/02b_tradeoff.png)

**When switching pays: best feedback rule minus best calendar, by signal speed and cost**

![Regime vs best calendar](artifacts/figures/07c_regime_vs_best_calendar.png)

**How sensitive the rule is to its one setting**

![Sensitivity](artifacts/figures/00e_sensitivity.png)

**Still working on data it never saw: the 2021-24 test half and the fresh 2025-26 holdout**

![Period consistency](artifacts/figures/06b_period_consistency.png)

**Fresh holdout, 2025-26: growth of $1 with every choice frozen since 2021**

![Fresh holdout](artifacts/figures/06a_holdout_growth.png)

The full set of 28 figures is in `artifacts/figures/`; the notebook's appendix maps each
one to the report section it supports.

## 7. Results and conclusion

| Finding | Result |
|---|---|
| Best rule vs. trade every change (simulated) | **0.89 vs 0.78** net Sharpe, 58% less trading, gain +0.11 [+0.08, +0.15] |
| Closed loop vs. open loop by turnover budget | Closed loop wins at **5 of 5** budgets (median +0.20 Sharpe) |
| Gain split | **HOW FAR (pacing) +0.111**, WHEN (picking the moment) +0.002 |
| Picking the moment alone, at equal turnover | best full-move rule (TargetCUSUM(0.8)) +0.006 [-0.025, +0.037]: no better than a calendar |
| Why it wins (at 25x/yr turnover) | Stale-book loss **0.075** vs 0.226 (calendar) and 0.214 (band, full move); cost loss **0.081** vs 0.146 and 0.156 |
| When switching pays (best feedback rule minus best calendar) | No gain at zero cost (-0.07 to 0.00); **+0.02 to +0.48** once trading costs anything; largest for fast signals (+0.43 at a 2-day half-life), fading for slow ones (+0.03 at 60 days) |
| Sensitivity to the setting (simulated) | Closing 25%-75% of the gap a day beats the benchmark significantly; 1%-5% is too slow and loses |
| vs. random timing (placebo) | p = 0.066 (7 of 120 random schedules did at least as well; standard +1 correction) |
| Picking the moment's best grid cell, fresh paths | +0.12 in the grid (20-day half-life), **+0.05 [-0.02, +0.12]** on 256 fresh paths: mostly selection noise |
| Every trigger x every move (7b) | WHEN, move held fixed: **-0.007 / -0.006 / -0.002**; HOW FAR, trigger held fixed: **+0.107 to +0.114** for all five triggers |
| The 2x2 (7b) | Calendar(2) 0.782; PartialAdjustment(0.25) 0.891; NoTradeBand(0.4)-full 0.775; BandPartial(0.2,0.25) 0.889 |
| Cost shape, no fee (6b) | HOW FAR worth +0.028 / +0.118 / +0.443 (proportional / square-root / linear impact); WHEN at most +0.016 |
| Cost shape, 0.5 bps per order (6b) | HOW FAR -0.033 / -0.001 / +0.262; WHEN up to +0.091 [+0.017, +0.164]; under proportional costs the best rule is a full-move band |
| Real BTC/ETH, controlled signal | **1.06** vs -0.72 (every change) vs 0.58 (calendar picked the same way) |
| Real BTC/ETH, momentum | **-0.35** vs -0.48 (every change) vs -0.42 (calendar picked the same way) |
| Real BTC/ETH, every setting | All 5 settings below 1.0 beat trading on every change out of sample, on both signals |
| **Fresh holdout 2025-26, controlled** | **0.98** vs -0.08 (every change; +1.06, 95% CI +0.04 to +2.29) vs 0.78 (calendar picked the same way; within noise) |
| **Fresh holdout 2025-26, momentum** | **0.92** vs 0.12 (every change; +0.79, 95% CI +0.23 to +1.40) vs 0.07 (calendar picked the same way; within noise) |
| Fresh holdout: risk and trading | Worst fall -6% / -19% (ours) vs -26% / -31% (every change); 63x and 53x a year vs 430x and 101x |
| Fresh holdout: caveats | Under two years; a fast calendar (every 2 days) did better on momentum with hindsight; slow settings that led in 2021-24 lost on momentum in 2025-26 |

**Criteria: 3 of 5 passed.** C1, C4 (post-hoc) and C5 pass. C2 fails narrowly
(p = 0.066) at its pre-registered 5% threshold, which is kept. It is a weak fail: with 120
random schedules, the share that did at least as well (7 of 120) has a 95% interval of 0.029
to 0.116, so the test cannot separate pass from fail, and it has little power for a rule
that trades on 98% of days.
C3 fails: the advantage did not grow with burstiness as predicted.

**Conclusion.** Closed-loop execution beats trading on every signal change, and beats
the best calendar at every trading budget whenever trading has a cost. The hypothesis is
right that feedback beats the clock, but the timing that works is not the one it proposed:
the value lies in **pacing** each rebalance - moving part of the way each day, so the trade
is spread over several days - not in **picking better moments**. That holds for every trigger
tested: holding the move fixed, no trigger beats a calendar; holding the trigger fixed,
moving part of the way wins by the same margin. It holds because costs grow faster than
trade size and acting itself is cheap: make costs more convex and the effect grows, add a
fixed fee per order and it fades while picking the moment starts to earn something.

The practical recommendation: do not trade a systematic strategy's signal blindly. Pace
each rebalance with partial adjustment, with the pace set from the strategy's costs (fees,
spread, market impact against volume) and how fast its signal fades - chosen on past data,
then frozen, after checking the desk's fee structure.

**Pros and cons of partial adjustment**

| Pros | Cons |
|---|---|
| More profit after costs than trading on every change, same signal | Does not pick moments: its timing is pacing, and it does not clearly beat random timing (C2) |
| Far less trading, so lower costs | Always lags the target; slow to catch up after a large signal jump |
| Beats the best calendar at every budget once trading has a cost | Worth little when trading is nearly free, or for slow signals |
| Cheaper per unit traded under square-root impact | One setting to choose; too slow loses, and the best value moves |
| Smaller worst fall in the simulated market | Trades almost daily: at 0.5 bps per order its edge vanishes (square-root) or reverses (proportional); minimum sizes not modelled |
| Robust across a wide band of settings; still ahead of trading on every change in 2025-26 | Real-data lead over a fairly picked calendar is within noise, in both unseen periods |
| One parameter, works on top of any signal; no trigger improves on it | Evidence comes mainly from a model market with modelled costs |

## 8. Constraints and limitations

**Scope**
* Real data covers **two coins on one price path**. It is a consistency check on the
  simulated result, not an independent proof, and says nothing about other asset classes.
  The fresh 2025-26 holdout adds a second unseen period, but it is under two years long and
  was added after the results were known, so it is evidence, not a criterion.
* Against a calendar picked the same way, the real-data lead is inside the noise (95%
  intervals include zero). With hindsight, some fixed calendars did better on this path.
* With two assets, momentum is just "long the stronger coin, short the weaker", and
  risk-parity sizing equals inverse-volatility.

**Model**
* The simulated market is conditionally Gaussian with clustered information arrival;
  real markets have fat tails, regime breaks and liquidity that vanishes under stress.
* Costs are modelled, not incurred: fee and half-spread are fixed numbers, not read from
  real bid/ask quotes, so spreads that widen in stress are missed. Impact uses published
  square-root-law coefficients.
* Daily bars, one-bar execution lag, one sizing rule. The intraday execution layer
  (Phase 3) is simulated, not driven by tick data.
* A fee per order is modelled only in phase 6b; minimum order sizes are not modelled.
* Shorting is free: no borrow fee or perpetual-futures funding.
* Yahoo's composite price is treated as tradable.

**Statistics**
* Phases 6b and 7b and the timing recheck were designed after the results were known;
  they explain the result and are reported as findings, not criteria.
* About a dozen comparisons are reported with no multiple-comparison correction. The
  headline effects survive any correction (all p < 1e-7); marginal ones (C2 at p = 0.066)
  should be read as suggestive.
* Phase 4 shows that BTC/ETH costs (~0.02-0.08 Sharpe) are far below what one price
  history can detect (~0.40-0.47 Sharpe). That is why the main test is simulated.

**Not claimed**
* Nothing here is a profitable strategy. The controlled signal reads the future by
  design; the momentum signal is deliberately simple. The project is about
  *implementation*, not alpha.
* The pace is tuned on past data, not derived from an explicit model of each trade's
  expected value. Price-move and volume *triggers* did not help: volume matters here
  through market impact (a trade small against daily volume costs less), not as a signal
  of when to trade.

## 9. How to run

```bash
pip install -r FYP/requirements.txt       # numpy, pandas, scipy, yfinance, matplotlib, jupyter

python -m FYP.tests                       # 25 invariant tests
python -m FYP.run_phases                  # full study, ~20-25 min -> FYP/artifacts/
python -m FYP.run_phases --quick          # smoke run -> artifacts_quick/, real results untouched
python -m FYP.run_phases --phase 5        # one phase only (5, 6, 7 include 5b, 6b, 7b)
python -m FYP.run_phases --phase 7b       # the when x how-far factorial on its own

jupyter notebook research.ipynb           # the full write-up, ~20-25 min to re-run
```

Run commands from the folder that *contains* `FYP/`, because the package is imported as
`FYP`. The BTC/ETH download is cached, so re-runs work offline.

## 10. Code map

```
AlphaProvider    -> target weights            alpha.py, generator.py
Scheduler        -> when to trade, how far    schedulers.py   (trigger x move_fraction)
Cost / Execution -> what it costs             costs.py, microstructure.py
Simulator        -> NAV, turnover, cost       core.py
Evaluator        -> metrics, CIs, power       evaluation.py
```

| File | Role |
|---|---|
| `core.py` | Vectorised drifting-book simulator, batched over paths |
| `schedulers.py` | The rules. Every rule states its two decisions: `trigger` (when) and `move_fraction` (how far); `default_zoo` is the 77-rule main comparison, `factorial_zoo` crosses every trigger with every move fraction |
| `generator.py` | Simulated market with the signal calibrated to Sharpe 1.0 |
| `alpha.py` | Real-data signals (controlled, momentum) and sizing |
| `data.py` | BTC/ETH download from Yahoo Finance; volume converted to coins |
| `costs.py` | Fee + half-spread + square-root impact + optional fee per order; `equal_cost_shapes` (proportional / square-root / linear impact at equal cost for a typical trade); `lab` and `crypto_retail` presets |
| `microstructure.py` | Intraday execution: TWAP, VWAP, POV, Almgren-Chriss |
| `evaluation.py` | Metrics, decomposition, paired intervals, power analysis |
| `portfolio.py` | Equal-risk-contribution sizing |
| `phases.py` | Phases 1-8 with 5b (2025-26 holdout), 6b (cost shape) and 7b (when x how far), and the bottom line. Two comparison helpers carry every test: `compare_at_equal_turnover` and `best_vs_best` |
| `plots.py` | Every figure |
| `run_phases.py` | One command for the whole study |
| `tests.py` | 25 invariant tests |
| `__init__.py` | Package docstring: question, architecture, module map |
| `research.ipynb` | The write-up |
| `OVERVIEW.md` | Plain-language guide |

## 11. References

**Event-based versus periodic sampling**
- Astrom, K. J. and B. Bernhardsson (2002). "Comparison of Riemann and Lebesgue sampling
  for first order stochastic systems." *Proc. 41st IEEE Conference on Decision and
  Control*, 2011-2016.
- Page, E. S. (1954). "Continuous inspection schemes." *Biometrika* 41, 100-115.
- Lopez de Prado, M. (2018). *Advances in Financial Machine Learning*, ch. 2 (CUSUM
  filter). Wiley.

**Rebalancing under transaction costs**
- Constantinides, G. M. (1986). "Capital market equilibrium with transaction costs."
  *Journal of Political Economy* 94(4), 842-862.
- Davis, M. H. A. and A. R. Norman (1990). "Portfolio selection with transaction costs."
  *Mathematics of Operations Research* 15(4), 676-713.
- Garleanu, N. and L. H. Pedersen (2013). "Dynamic trading with predictable returns and
  transaction costs." *Journal of Finance* 68(6), 2309-2340.

**Execution and market impact**
- Almgren, R. and N. Chriss (2000). "Optimal execution of portfolio transactions."
  *Journal of Risk* 3(2), 5-39.
- Perold, A. F. (1988). "The implementation shortfall: paper versus reality." *Journal of
  Portfolio Management* 14(3), 4-9.
- Toth, B. et al. (2011). "Anomalous price impact and the critical nature of liquidity."
  *Physical Review X* 1, 021006.
- Kyle, A. S. (1985). "Continuous auctions and insider trading." *Econometrica* 53(6),
  1315-1335.

**Time, volume and information arrival**
- Clark, P. K. (1973). "A subordinated stochastic process model with finite variance for
  speculative prices." *Econometrica* 41(1), 135-155.
- Ane, T. and H. Geman (2000). "Order flow, transaction clock and normality of asset
  returns." *Journal of Finance* 55(5), 2259-2284.
- Easley, D., M. Lopez de Prado and M. O'Hara (2012). "Flow toxicity and liquidity in a
  high-frequency world." *Review of Financial Studies* 25(5), 1457-1493.
- Cont, R. (2001). "Empirical properties of asset returns: stylized facts and statistical
  issues." *Quantitative Finance* 1(2), 223-236.

**Portfolio construction and inference**
- Grinold, R. C. (1989). "The fundamental law of active management." *Journal of
  Portfolio Management* 15(3), 30-37.
- Clarke, R., H. de Silva and S. Thorley (2002). "Portfolio constraints and the
  fundamental law of active management." *Financial Analysts Journal* 58(5), 48-66.
- Maillard, S., T. Roncalli and J. Teiletche (2010). "The properties of equally weighted
  risk contribution portfolios." *Journal of Portfolio Management* 36(4), 60-70.
- Lo, A. W. (2002). "The statistics of Sharpe ratios." *Financial Analysts Journal* 58(4),
  36-52.
- Kunsch, H. R. (1989). "The jackknife and the bootstrap for general stationary
  observations." *Annals of Statistics* 17(3), 1217-1241. (Moving-block bootstrap, Phase 5.)

**Data**
- Yahoo Finance daily BTC-USD and ETH-USD, accessed through the `yfinance` Python package.
