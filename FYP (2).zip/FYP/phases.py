"""Phases 1-8: the experiment, end to end.

The study answers one question - is the value of closed-loop rebalancing in
WHEN it trades or in HOW FAR it moves? - in four steps. The phase numbers are
the order things were built (and the prefix of every artifact); the questions
are the order the argument is read in.

  Q1  Does closed loop beat open loop?            phases 1, 2, 7 (head to head)
  Q2  Is the gain in when, or in how far?         phases 7 (split, placebo), 7b
  Q3  When does *when* start to matter?           phases 6, 6b
  Q4  Does it hold on real prices?                phases 4, 5, 5b
      Execution costs, measured not assumed       phase 3
      The registered criteria, scored             phase 8

    Phase 1  Synthetic laboratory, alpha calibrated to gross Sharpe 1.0
    Phase 2  Scheduler zoo -> turnover/Sharpe frontiers, chosen out-of-sample
    Phase 3  Execution layer -> costs measured, not assumed
    Phase 4  Statistical power -> where an execution effect is even visible
    Phase 5  Real data -> BTC and ETH, daily, out of sample
    Phase 5b Fresh holdout -> the same picks, scored on 2025-26 data
    Phase 6  Regime map -> where closed loop wins; timing's best case rechecked
    Phase 6b Cost shape -> how cost grows with trade size decides when vs how far
    Phase 7  Benchmarks and placebo -> the head-to-head claim, and the split
    Phase 7b When x how far -> every trigger crossed with every move fraction
    Phase 8  Success criteria (C4 post-hoc) -> an automatic, honest verdict,
             plus the exploratory findings of 6, 6b and 7b (reported, not scored)
    Bottom line  plain-language scorecard, real-data summary, recommendation

Phases 6b and 7b and the timing recheck in phase 6 were added after the
criteria were scored, to explain the result; they are never scored.

Two comparison helpers carry every test in the study:

  compare_at_equal_turnover  one rule family against a reference frontier
                             (usually the calendar) interpolated to the rule's
                             own turnover - phases 2, 6 and 7;
  best_vs_best               the best rule one design can build against the
                             best another can build - the when x how-far
                             factorial of phases 6b and 7b.

Both pick knobs on calibration paths and report the paired difference on
held-out paths.

Each phase returns a dict of pandas objects, writes CSVs to FYP/artifacts (the
package's own folder), and is importable on its own. `run_all` chains them and
hands phase 8 the evidence.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, replace

import numpy as np
import pandas as pd

from .alpha import (ControlledAlpha, MomentumAlpha, build_market,
                    calibrate_controlled_alpha)
from .core import SimConfig, paper_portfolio, simulate
from .costs import COST_PRESETS, CostModel, equal_cost_shapes
from .evaluation import (annualised_sharpe, arm_stats, decompose, dominance,
                         selection_score,
                         implementation_ratio, minimum_detectable_delta,
                         max_drawdown, moving_block_paired_ci, paired_diff,
                         select_by_budget, years_required)
from .generator import SyntheticParams, build_components, make_lab
from .microstructure import (IntradayParams, execution_curve,
                             fit_square_root_law, savings_vs_baseline)
from .schedulers import (CLOSED_LOOP, EVENT_TRIGGERS, OPEN_LOOP, TRIGGER_LABEL,
                         TRIGGER_ORDER, RandomPlacebo, default_zoo, factorial_zoo)

ARTIFACTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "artifacts")
FIGURES = os.path.join(ARTIFACTS, "figures")
CACHE = os.path.join(ARTIFACTS, "cache")


# --------------------------------------------------------------- settings


@dataclass
class PhaseConfig:
    """One place to set the size of every experiment."""

    # --- laboratory ---
    n_paths: int = 256
    n_bars: int = 1008
    n_assets: int = 6
    seed: int = 7
    ann: int = 252
    calib_frac: float = 0.40          # share of paths used to pick knobs
    cost_preset: str = "lab"
    aum: float = 10_000_000.0
    vol_target: float = 0.15

    # --- phase 6 grids (smaller: one lab per cell) ---
    grid_paths: int = 96
    grid_bars: int = 756
    grid_half_lives: tuple = (2.0, 5.0, 10.0, 20.0, 60.0)
    grid_cost_bps: tuple = (0.0, 1.0, 3.0, 10.0)
    grid_burstiness: tuple = (0.0, 0.35, 0.70, 0.95)
    grid_coupling: tuple = (0.0, 0.25, 0.50, 0.75)

    # --- phase 6b: cost shape x fixed fee per order ---
    shape_order_fees: tuple = (0.0, 0.1, 0.5)   # bps of NAV per order
    shape_paths: int = 192            # more than a grid cell: this is a headline
    # --- phase 6: timing's best case, rebuilt on fresh paths ---
    recheck_seed: int = 1007

    # --- phase 7 ---
    placebo_draws: int = 120
    # --- phase 7b: the move fractions crossed with every trigger ---
    factorial_lams: tuple = (1.0, 0.5, 0.25)

    # --- phase 5 (BTC and ETH; Yahoo's history starts 2017-11-09) ---
    real_start: str = "2015-01-01"
    real_end: str = "2025-01-01"          # exclusive: the study's last bar is 2024-12-31

    # --- phase 5b: fresh holdout, never used to choose anything ---
    holdout_start: str = "2025-01-01"     # first day after the study's sample
    holdout_end: str = "2026-10-11"       # exclusive: last bar 2026-10-10

    budgets: tuple = (2.0, 5.0, 10.0, 20.0, 40.0, 80.0)
    quick: bool = False

    def scaled(self) -> "PhaseConfig":
        """A smaller version for smoke tests."""
        if not self.quick:
            return self
        return replace(
            self, n_paths=64, n_bars=504, grid_paths=48, grid_bars=378,
            placebo_draws=24, grid_half_lives=(2.0, 10.0, 60.0),
            grid_cost_bps=(0.0, 3.0), grid_burstiness=(0.0, 0.95),
            grid_coupling=(0.0, 0.5), shape_order_fees=(0.0, 0.5),
            shape_paths=48,
        )

    @property
    def cost_model(self) -> CostModel:
        return COST_PRESETS[self.cost_preset]

    @property
    def sim_cfg(self) -> SimConfig:
        return SimConfig(exec_lag=1, ann_factor=self.ann, aum=self.aum)

    def split(self, n_paths: int):
        """Calibration / evaluation path split -- knobs are never chosen on the
        paths they are scored on."""
        n_cal = max(2, int(round(self.calib_frac * n_paths)))
        idx = np.arange(n_paths)
        return idx[:n_cal], idx[n_cal:]


def _ensure_dirs() -> None:
    for d in (ARTIFACTS, FIGURES, CACHE):
        os.makedirs(d, exist_ok=True)


def _save(tables: dict, prefix: str) -> None:
    _ensure_dirs()
    for key, obj in tables.items():
        if isinstance(obj, pd.DataFrame):
            obj.to_csv(os.path.join(ARTIFACTS, f"{prefix}_{key}.csv"), index=False)
        elif isinstance(obj, pd.Series):
            obj.to_csv(os.path.join(ARTIFACTS, f"{prefix}_{key}.csv"))


# ----------------------------------------------------------------- phase 1


def phase1_lab(cfg: PhaseConfig | None = None, params: SyntheticParams | None = None) -> dict:
    """Build and validate the controlled laboratory.

    Success here means one thing only: the paper portfolio -- holding the
    target exactly, every bar, free -- is solved to an annualised Sharpe of
    1.00 on calibration paths, and checked on paths that were NOT used to
    calibrate it (reported with its 95% interval). That ceiling is what makes
    every later number interpretable as a fraction of an achievable maximum.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    params = params or SyntheticParams(
        n_assets=cfg.n_assets, n_bars=cfg.n_bars, ann_factor=cfg.ann,
        vol_target=cfg.vol_target,
    )
    lab = make_lab(params, n_paths=cfg.n_paths, seed=cfg.seed,
                   sim_cfg=cfg.sim_cfg, target_sharpe=1.0)
    paper = paper_portfolio(lab.market, lab.targets, cfg.sim_cfg)
    s = annualised_sharpe(paper.net_returns, cfg.ann)
    _, eval_idx = cfg.split(cfg.n_paths)

    # Realised alpha half-life, as a check that the process is what we ordered.
    # Measured on the standardised alpha itself: the target weights are
    # normalised, vol-scaled and capped, which lowers their autocorrelation and
    # would understate the half-life.
    a = build_components(params, cfg.n_paths, cfg.seed)["a_std"]
    flat = a[:, params.vol_window:, :]
    ac = np.mean([
        np.corrcoef(flat[:, :-1, k].ravel(), flat[:, 1:, k].ravel())[0, 1]
        for k in range(flat.shape[2])
    ])
    realised_hl = np.log(0.5) / np.log(max(ac, 1e-9))

    table = pd.DataFrame([{
        "Paths": cfg.n_paths,
        "Bars": params.n_bars,
        "Assets": params.n_assets,
        "lambda_alpha (calibrated)": lab.lam_alpha,
        "Paper Sharpe achieved by the solver": lab.calibrated_sharpe,
        "Paper Sharpe (all paths)": float(s.mean()),
        "Paper Sharpe (eval paths)": float(s[eval_idx].mean()),
        # The interval belongs to the held-out figure above it, not to all paths.
        "Paper Sharpe 95% lo": float(s[eval_idx].mean()
                                     - 1.96 * s[eval_idx].std(ddof=1) / np.sqrt(eval_idx.size)),
        "Paper Sharpe 95% hi": float(s[eval_idx].mean()
                                     + 1.96 * s[eval_idx].std(ddof=1) / np.sqrt(eval_idx.size)),
        "Paper turnover/yr": float(paper.turnover.mean() * cfg.ann),
        "Target alpha half-life": params.half_life,
        "Realised alpha half-life": float(realised_hl),
        "Burstiness": params.burstiness,
        "Coupling": params.coupling,
    }])
    out = {"lab": lab, "paper": paper, "params": params, "validation": table}
    _save({"validation": table}, "phase1")
    return out


# ----------------------------------------------------------------- phase 2


def run_zoo(lab, cfg: PhaseConfig, cost_model: CostModel | None = None,
            zoo: list | None = None) -> list:
    """Run every scheduler on the identical market and alpha path."""
    cost_model = cost_model or cfg.cost_model
    zoo = zoo if zoo is not None else default_zoo(seed=cfg.seed)
    arms = []
    for sch in zoo:
        res = simulate(lab.market, lab.targets, sch, cost_model, cfg.sim_cfg)
        arms.append(arm_stats(res, cfg.ann))
    return arms


def phase2_frontiers(lab, cfg: PhaseConfig | None = None,
                     cost_model: CostModel | None = None) -> dict:
    """Trace each family's turnover/Sharpe frontier and test for dominance.

    Comparing frontiers rather than points is what makes the comparison mean
    something. Matching a single rebalance count can be won by luck or by a
    lucky knob; a family whose whole curve sits above another's is better at
    *every* trading budget, and the knob that gets it there is chosen on
    calibration paths and scored on held-out ones.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    cost_model = cost_model or cfg.cost_model
    arms = run_zoo(lab, cfg, cost_model)
    paper = arm_stats(paper_portfolio(lab.market, lab.targets, cfg.sim_cfg), cfg.ann)

    n_paths = lab.market.shape[0]
    calib_idx, eval_idx = cfg.split(n_paths)
    budgets = np.array(cfg.budgets, dtype=float)
    selected = select_by_budget(arms, budgets, calib_idx, eval_idx)

    arms_df = pd.DataFrame([a.mean() for a in arms]).sort_values(
        ["Family", "Turnover/yr"]).reset_index(drop=True)
    frontier_df = pd.DataFrame([
        {k: v for k, v in row.items() if not k.startswith("_")}
        for rows in selected.values() for row in rows
    ])

    # Dominance of each family over the clock benchmark, budget by budget.
    diffs = []
    for family in selected:
        if family in ("clock", "control"):
            continue
        diffs += dominance(selected, family, "clock")
    dominance_df = pd.DataFrame([d.as_row() for d in diffs])

    # Closed-loop as a group vs open-loop as a group, at each budget.
    group_rows, group_diffs = [], []
    for b in budgets:
        best_closed = _best_group(selected, CLOSED_LOOP, b, calib_idx, arms)
        best_open = _best_group(selected, OPEN_LOOP, b, calib_idx, arms)
        if best_closed is None or best_open is None:
            continue
        d = paired_diff(best_closed["_eval_sharpe"], best_open["_eval_sharpe"],
                        label=f"closed-loop - open-loop @ turnover<={b:g}")
        group_diffs.append(d)
        group_rows.append({
            "Budget": b,
            "Closed-loop pick": best_closed["Scheduler"],
            "Closed Sharpe": best_closed["Net Sharpe"],
            "Closed turnover": best_closed["Turnover/yr"],
            "Open-loop pick": best_open["Scheduler"],
            "Open Sharpe": best_open["Net Sharpe"],
            "Open turnover": best_open["Turnover/yr"],
            **d.as_row(),
        })
    group_df = pd.DataFrame(group_rows)

    # Exact equal-turnover test, family by family. Stricter than the budget
    # comparison above, and the one to quote when someone objects that the
    # winner simply traded less.
    matched_rows, matched_diffs = [], []
    for family in ("state-feedback", "price-event", "target-event", "activity"):
        row, d = matched_diff(arms, {family}, calib_idx, eval_idx,
                              label=f"{family} vs calendar at equal turnover")
        if row is not None:
            matched_rows.append({"Family": family, **row})
            matched_diffs.append(d)
    matched_df = pd.DataFrame(matched_rows)

    # Decomposition of a representative arm per family at a mid budget.
    mid = budgets[len(budgets) // 2]
    decomp_rows = []
    for family, rows in selected.items():
        row = next((r for r in rows if r["Budget"] == mid), None)
        if row is None:
            continue
        arm = next(a for a in arms if a.name == row["Scheduler"])
        decomp_rows.append(decompose(arm.subset(eval_idx), paper.subset(eval_idx)))
    decomp_df = pd.DataFrame(decomp_rows)

    out = {
        "arms": arms_df, "frontier": frontier_df, "dominance": dominance_df,
        "group": group_df, "decomposition": decomp_df,
        "equal_turnover": matched_df,
        "_arms": arms, "_selected": selected, "_paper": paper,
        "_group_diffs": group_diffs, "_diffs": diffs,
        "_matched_diffs": matched_diffs,
        "_calib_idx": calib_idx, "_eval_idx": eval_idx,
        "paper_sharpe": float(paper.net_sharpe[eval_idx].mean()),
        "budget_mid": float(mid),
    }
    _save({k: v for k, v in out.items() if isinstance(v, pd.DataFrame)}, "phase2")
    return out


def _placebo(lab, cfg: PhaseConfig, rate: float, lam: float,
             eval_idx: np.ndarray, seed0: int = 10_000):
    """Random-timing null: same trade rate and same move rule, random times.

    Returns (mean Sharpe per path across draws, per-draw evaluation means,
    per-draw turnover). Averaging over draws removes the luck of a single
    random schedule: a single-seed placebo tests one draw from the null, not
    the null itself.
    """
    per_path = np.zeros(lab.market.shape[0])
    means, turns = [], []
    for i in range(cfg.placebo_draws):
        res = simulate(lab.market, lab.targets,
                       RandomPlacebo(rate, seed=seed0 + i, lam=lam),
                       cfg.cost_model, cfg.sim_cfg)
        st = arm_stats(res, cfg.ann)
        per_path += st.net_sharpe
        means.append(float(st.net_sharpe[eval_idx].mean()))
        turns.append(float(st.turnover[eval_idx].mean()))
    return per_path / max(cfg.placebo_draws, 1), np.array(means), turns


def _frontier_interpolator(ref_arms: list):
    """Per-path Sharpe of a reference rule family at an arbitrary turnover.

    The counterfactual "what would rebalancing on a clock have earned, had it
    traded exactly this much?" is what makes a timing comparison
    turnover-matched rather than merely turnover-similar.

    Returns f(turnover) -> (S,) array, interpolating linearly in log turnover
    between the two bracketing reference knobs (and holding the end values flat
    outside the reference range, which is conservative for the challenger).
    The reference is the calendar in the original tests; phases 6b and 7b also
    use the calendar at a given move fraction, and a trigger moving all the way.
    """
    refs = sorted(ref_arms, key=lambda a: a.turnover.mean())
    refs = [a for a in refs if a.turnover.mean() > 1e-9]
    if len(refs) < 2:
        return None
    xs = np.log(np.array([a.turnover.mean() for a in refs]))
    ys = np.stack([a.net_sharpe for a in refs])            # (k, S)

    def f(x: float) -> np.ndarray:
        # Interpolate against LOG turnover. The calendar frontier is concave in
        # turnover, so a chord drawn in linear space passes below the true
        # curve and would hand the challenger a free advantage. In log space
        # the curve is far closer to straight, and the calendar grid is dense,
        # so what residual bias remains is small.
        if x <= 0:
            return ys[0]
        lx = np.log(x)
        if lx <= xs[0]:
            return ys[0]
        if lx >= xs[-1]:
            return ys[-1]
        j = int(np.searchsorted(xs, lx))
        lo, hi = j - 1, j
        w = (lx - xs[lo]) / max(xs[hi] - xs[lo], 1e-12)
        return (1.0 - w) * ys[lo] + w * ys[hi]

    return f


@dataclass
class EqualTurnover:
    """One equal-turnover comparison, as `compare_at_equal_turnover` returns it."""

    arm: object             # the candidate picked on calibration paths
    base: np.ndarray        # (S,) the reference, interpolated to its turnover
    diff: object            # PairedDiff, candidate minus reference, held-out paths
    cal_delta: float        # its advantage on calibration paths (what picked it)
    every: list             # held-out advantage of every candidate (the spread)


def compare_at_equal_turnover(cands: list, ref_arms: list, calib_idx, eval_idx,
                              label: str = "{name} vs reference at equal turnover",
                              min_turnover: float | None = None):
    """The study's one equal-turnover test.

    Each candidate is compared with the reference family interpolated to *its
    own* turnover, path by path; the candidate with the largest advantage on
    the calibration paths is picked, and its paired difference is reported on
    the held-out paths. Selecting on the paired difference rather than on the
    Sharpe level is what makes the answer stable: the level of any one arm
    carries the full Monte-Carlo noise of the path set, the difference between
    two arms on the same paths does not.

    `label` may contain {name}, filled with the picked candidate's name.
    Returns an EqualTurnover, or None if there is nothing to compare.
    """
    curve = _frontier_interpolator(ref_arms)
    if min_turnover is not None:
        cands = [a for a in cands if a.turnover.mean() > min_turnover]
    if curve is None:
        return None
    scored = []
    for a in cands:
        base = curve(float(a.turnover.mean()))
        scored.append((float((a.net_sharpe - base)[calib_idx].mean()), a, base))
    if not scored:
        return None
    every = [float((a.net_sharpe - base)[eval_idx].mean()) for _, a, base in scored]
    scored = [z for z in scored if np.isfinite(z[0])]
    if not scored:
        return None
    cal_delta, best, base = max(scored, key=lambda z: z[0])
    d = paired_diff(best.net_sharpe[eval_idx], base[eval_idx],
                    label=label.format(name=best.name))
    return EqualTurnover(best, base, d, cal_delta, every)


def _best_group(selected: dict, families: set, budget: float,
                calib_idx: np.ndarray, arms: list):
    """Best arm within a group of families at a turnover budget, chosen on the
    calibration paths only."""
    cands = []
    for family in families:
        for row in selected.get(family, []):
            if row["Budget"] == budget:
                cands.append(row)
    if not cands:
        return None
    by_name = {a.name: a for a in arms}
    return max(cands,
               key=lambda r: selection_score(by_name[r["Scheduler"]].net_sharpe[calib_idx]))


# ----------------------------------------------------------------- phase 3


def phase3_execution(cfg: PhaseConfig | None = None,
                     daily_vol: float = 0.02, n_sims: int = 4000) -> dict:
    """Measure what each execution algorithm actually costs.

    Every algorithm fills a parent order against simulated flow and is charged
    the shortfall it actually incurs, so the saving is an output rather than an
    input -- and the timing risk it buys with that saving is reported beside
    it.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    if cfg.quick:
        n_sims = 1200
    params = IntradayParams(daily_vol=daily_vol)
    curve = execution_curve(params=params, n_sims=n_sims, seed=cfg.seed)
    # Pin the intercept to the cost we know by construction, so the fitted
    # coefficient is the impact term and nothing else.
    fit = fit_square_root_law(curve, fixed_bps=params.half_spread_bps + params.fee_bps)
    savings = savings_vs_baseline(curve)

    best = (savings.sort_values("Saving bps", ascending=False)
            .drop_duplicates("participation"))
    out = {"curve": curve, "fit": fit, "savings": savings, "best_by_size": best}
    _save(out, "phase3")
    return out


# ----------------------------------------------------------------- phase 4


def phase4_power(cfg: PhaseConfig | None = None,
                 turnover_per_year: float = 30.0,
                 lab_effect: float | None = None) -> dict:
    """Prize vs resolution: where could execution research possibly succeed?

    Two numbers per market regime:
      * the implementation ratio -- Sharpe points per year destroyed by
        trading costs, i.e. the largest effect any scheduler could ever
        recover;
      * the minimum detectable difference at 80% power.
    If the prize is smaller than the resolution, the experiment is dead on
    arrival no matter how carefully it is coded.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    n_eval = len(cfg.split(cfg.n_paths)[1])      # lab inference uses held-out paths only
    regimes = [
        # label, ann vol, cost bps, turnover/yr, years, paths, corr between arms
        ("Crypto, study cost (4 bps), 3.6-year test half", 0.50, 4.0, 30.0, 3.58, 1, 0.95),
        ("Crypto, high cost (15 bps), 5 years", 0.60, 15.0, 30.0, 5.0, 1, 0.95),
        (f"This lab: Monte-Carlo, {n_eval} held-out paths", cfg.vol_target,
         COST_PRESETS[cfg.cost_preset].linear_bps, 30.0,
         cfg.n_bars / cfg.ann, n_eval, 0.95),
    ]
    rows = []
    for label, vol, bps, turn, years, paths, rho in regimes:
        ann = cfg.ann if paths > 1 else REAL_ANN
        prize = implementation_ratio(turn, bps, vol)
        source = "cost channel only"
        if paths > 1 and lab_effect is not None:
            # In the lab the achievable effect is measured, and it is larger
            # than the cost channel alone because closed-loop scheduling also
            # tracks the target better at equal turnover.
            prize, source = float(lab_effect), "measured: cost + tracking"
        mde = minimum_detectable_delta(years, ann, 1.0, rho, n_paths=paths)
        rows.append({
            "Regime": label,
            "Ann. vol": vol,
            "Cost (bps)": bps,
            "Turnover/yr": turn,
            "Years": years,
            "Paths": paths,
            "Effect available": prize,
            "Effect source": source,
            "Min detectable delta": mde,
            "Detectable": prize > mde,
            "Effect / resolution": prize / mde if mde else np.nan,
        })
    table = pd.DataFrame(rows)

    # How much history a single backtest would need to resolve the effect.
    need = []
    for vol, bps, turn, label in [
        (0.50, 4.0, 30.0, "Crypto, study cost 4 bps (cost channel)"),
        (0.60, 15.0, 30.0, "Crypto, high cost 15 bps (cost channel)"),
    ]:
        prize = implementation_ratio(turn, bps, vol)
        for rho in (0.90, 0.95, 0.99):
            need.append({"Setting": label, "Correlation between arms": rho,
                         "Effect (Sharpe)": prize,
                         "Years of data needed": years_required(prize, REAL_ANN, 1.0, rho)})
    need_df = pd.DataFrame(need)

    out = {"power": table, "data_required": need_df}
    _save(out, "phase4")
    return out


# ----------------------------------------------------------------- phase 6


def _grid_lab(cfg: PhaseConfig, n_paths: int | None = None, seed: int | None = None,
              **param_kw):
    """A grid-sized lab (one per grid cell), its alpha strength calibrated on a
    fixed seed so that the same parameters always give the same alpha.
    `n_paths` and `seed` default to the grid's; the timing recheck overrides
    them to rebuild a cell on fresh paths."""
    from .generator import calibrate_lam_alpha
    params = SyntheticParams(
        n_assets=cfg.n_assets, n_bars=cfg.grid_bars, ann_factor=cfg.ann,
        vol_target=cfg.vol_target, **param_kw,
    )
    sim_cfg = SimConfig(exec_lag=1, ann_factor=cfg.ann, aum=cfg.aum)
    lam = calibrate_lam_alpha(params, 1.0, n_paths=64, seed=9973,
                              sim_cfg=sim_cfg, tol=5e-3, max_iter=16)
    return make_lab(params, n_paths=n_paths or cfg.grid_paths,
                    seed=cfg.seed if seed is None else seed,
                    sim_cfg=sim_cfg, lam_alpha=lam)


def _grid_zoo(cfg: PhaseConfig) -> list:
    """A reduced but balanced zoo: every family spans the same turnover range."""
    return default_zoo(
        calendar_steps=(1, 2, 3, 5, 8, 13, 21, 34, 55, 90),
        volume_units=(1.0, 3.0, 10.0, 21.0, 60.0),
        cusum_thresholds=(0.5, 2.0, 5.0, 12.0, 24.0),
        target_thresholds=(0.05, 0.2, 0.8, 3.2, 8.0),
        bands=(0.02, 0.1, 0.4, 0.8, 1.4),
        lams=(0.02, 0.1, 0.25, 0.5, 1.0),
        placebo_rates=(0.02, 0.1, 0.3, 1.0),
        seed=cfg.seed,
    )


def _family_best(arms, families: set, calib_idx, eval_idx) -> tuple[float, str]:
    """Best achievable net Sharpe within a group, knob chosen on calib paths."""
    cands = [a for a in arms if a.family in families]
    if not cands:
        return np.nan, ""
    best = max(cands, key=lambda a: selection_score(a.net_sharpe[calib_idx]))
    return float(best.net_sharpe[eval_idx].mean()), best.name


def matched_diff(arms, families: set, calib_idx, eval_idx,
                 full_move_only: bool = False, label: str = ""):
    """Exact equal-turnover test against the calendar.

    For every rule in `families`, compare it with a calendar interpolated to
    *its own* turnover, pick the knob on the calibration paths, and report the
    held-out paired difference. This is stricter than comparing two rules that
    merely fall under the same turnover budget: here the two arms trade the
    same amount by construction, so "it traded less" cannot be the explanation.

    Returns (row dict, PairedDiff) or (None, None).
    """
    cands = [a for a in arms if a.family in families
             and (a.full_move or not full_move_only)]
    eq = compare_at_equal_turnover(
        cands, [a for a in arms if a.family == "clock"], calib_idx, eval_idx,
        label=label or "{name} vs calendar at equal turnover", min_turnover=1e-9)
    if eq is None:
        return None, None
    row = {
        "Scheduler": eq.arm.name,
        "Turnover/yr": float(eq.arm.turnover[eval_idx].mean()),
        "Net Sharpe": float(eq.arm.net_sharpe[eval_idx].mean()),
        "Calendar at same turnover": float(eq.base[eval_idx].mean()),
        "Median delta over all knobs": float(np.median(eq.every)),
        "Worst delta over all knobs": float(np.min(eq.every)),
        **eq.diff.as_row(),
    }
    return row, eq.diff


def matched_test(arms, families: set, calib_idx, eval_idx,
                 full_move_only: bool = False):
    """Advantage over a calendar rebalancer *trading exactly as much*, as a
    PairedDiff with its interval, plus the name of the rule picked.

    `full_move_only` restricts the comparison to rules that always trade all
    the way to the target, which makes it a test of *when* alone.
    """
    cands = [a for a in arms if a.family in families
             and (a.full_move or not full_move_only)]
    eq = compare_at_equal_turnover(cands, [a for a in arms if a.family == "clock"],
                                   calib_idx, eval_idx)
    return (None, "") if eq is None else (eq.diff, eq.arm.name)


def matched_advantage(arms, families: set, calib_idx, eval_idx,
                      full_move_only: bool = False) -> tuple[float, str]:
    """`matched_test`, reduced to (held-out advantage, rule name)."""
    d, name = matched_test(arms, families, calib_idx, eval_idx, full_move_only)
    return (np.nan, "") if d is None else (d.mean, name)


def phase6_regime_map(cfg: PhaseConfig | None = None) -> dict:
    """When does event-driven rebalancing win, and why?

    Two grids:
      A. alpha half-life x cost level -> the economic regime map. Fast alpha
         makes staleness expensive; high cost makes trading expensive; the
         closed-loop advantage should be largest where both bite.
      B. burstiness x coupling -> the mechanism test. Event timing should gain
         as information arrives in clusters, and the *price*-based detector
         specifically should gain with coupling, because coupling is what makes
         a price move informative about the target. If those two gradients do
         not appear, the story is wrong however good the headline number looks.

    Each grid-A cell carries a paired 95% interval (58 held-out paths), and
    the half-life row where timing alone did best is rebuilt on fresh paths
    (`timing_recheck`), because a best cell picked from 20 is the one most
    likely to be noise.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    zoo = _grid_zoo(cfg)
    calib_idx, eval_idx = cfg.split(cfg.grid_paths)

    def _ci(d):
        return (np.nan, np.nan) if d is None else (d.lo, d.hi)

    # ---- grid A: half-life x cost (one lab per half-life) ----
    rows_a = []
    for hl in cfg.grid_half_lives:
        lab = _grid_lab(cfg, half_life=hl, burstiness=0.5, coupling=0.4)
        for bps in cfg.grid_cost_bps:
            cm = _grid_cost(bps)
            arms = run_zoo(lab, replace(cfg, n_paths=cfg.grid_paths), cm, zoo)
            d_adv, pick = matched_test(arms, CLOSED_LOOP, calib_idx, eval_idx)
            d_tim, t_pick = matched_test(arms, CLOSED_LOOP, calib_idx,
                                         eval_idx, full_move_only=True)
            best_level, _ = _family_best(arms, CLOSED_LOOP, calib_idx, eval_idx)
            clock_level, clock_name = _family_best(arms, {"clock"}, calib_idx, eval_idx)
            rows_a.append({
                "Alpha half-life (bars)": hl, "Cost (bps)": bps,
                "Advantage": np.nan if d_adv is None else d_adv.mean,
                "Best scheduler": pick,
                "Timing-only advantage": np.nan if d_tim is None else d_tim.mean,
                "Best timing rule": t_pick,
                "Closed-loop Sharpe": best_level,
                "Best calendar Sharpe": clock_level, "Best calendar": clock_name,
                "Advantage 95% lo": _ci(d_adv)[0], "Advantage 95% hi": _ci(d_adv)[1],
                "Timing-only 95% lo": _ci(d_tim)[0], "Timing-only 95% hi": _ci(d_tim)[1],
            })
    grid_a = pd.DataFrame(rows_a)
    recheck = _timing_recheck(cfg, grid_a, zoo)

    # ---- grid B: burstiness x coupling (mechanism) ----
    rows_b = []
    for b in cfg.grid_burstiness:
        for k in cfg.grid_coupling:
            lab = _grid_lab(cfg, half_life=10.0, burstiness=b, coupling=k)
            cm = CostModel(fee_bps=0.0, half_spread_bps=3.0, enable_impact=True)
            arms = run_zoo(lab, replace(cfg, n_paths=cfg.grid_paths), cm, zoo)
            closed, _ = matched_advantage(arms, CLOSED_LOOP, calib_idx, eval_idx)
            timing, _ = matched_advantage(arms, CLOSED_LOOP, calib_idx, eval_idx,
                                          full_move_only=True)
            price, _ = matched_advantage(arms, {"price-event"}, calib_idx,
                                         eval_idx, full_move_only=True)
            target, _ = matched_advantage(arms, {"target-event"}, calib_idx,
                                          eval_idx, full_move_only=True)
            rows_b.append({
                "Burstiness": b, "Coupling": k,
                "Closed-loop advantage": closed,
                "Timing-only advantage": timing,
                "Price-CUSUM - clock": price,
                "Target-CUSUM - clock": target,
            })
    grid_b = pd.DataFrame(rows_b)

    out = {"regime_half_life_cost": grid_a, "mechanism_burst_coupling": grid_b,
           "timing_recheck": recheck}
    _save(out, "phase6")
    return out


def _grid_cost(bps: float) -> CostModel:
    """Grid A's cost at a given level: half-spread plus impact, no fee."""
    return CostModel(fee_bps=0.0, half_spread_bps=bps, enable_impact=bps > 0)


def _timing_recheck(cfg: PhaseConfig, grid_a: pd.DataFrame, zoo: list) -> pd.DataFrame:
    """Timing's best case, rebuilt on fresh paths.

    Take the half-life row of grid A where full-move timing did best on
    average, freeze the timing rule each cell picked, and score it against a
    calendar trading as much on `n_paths` new paths from an independent seed.
    Nothing is re-chosen, so every new path is a held-out path. If the edge was
    selection noise it shrinks towards zero here; if it is real it survives.
    """
    if grid_a.empty or grid_a["Timing-only advantage"].isna().all():
        return pd.DataFrame()
    by_hl = grid_a.groupby("Alpha half-life (bars)")["Timing-only advantage"].mean()
    hl = float(by_hl.idxmax())
    # Same parameters and alpha strength as the grid cell; only the paths are new.
    lab = _grid_lab(cfg, n_paths=cfg.n_paths, seed=cfg.recheck_seed,
                    half_life=hl, burstiness=0.5, coupling=0.4)
    every = np.arange(cfg.n_paths)
    clocks = [s for s in zoo if s.family == "clock"]
    by_name = {s.name: s for s in zoo}
    rows = []
    for _, r in grid_a[grid_a["Alpha half-life (bars)"] == hl].iterrows():
        cm = _grid_cost(r["Cost (bps)"])
        rule = by_name[r["Best timing rule"]]
        arms = [arm_stats(simulate(lab.market, lab.targets, s, cm, cfg.sim_cfg), cfg.ann)
                for s in clocks + [rule]]
        curve = _frontier_interpolator(arms[:-1])
        base = curve(float(arms[-1].turnover.mean()))
        d = paired_diff(arms[-1].net_sharpe, base,
                        label=f"{rule.name} vs calendar at equal turnover, fresh paths")
        rows.append({
            "Alpha half-life (bars)": hl, "Cost (bps)": r["Cost (bps)"],
            "Timing rule (frozen)": rule.name,
            "Grid estimate": r["Timing-only advantage"],
            "Grid 95% lo": r["Timing-only 95% lo"], "Grid 95% hi": r["Timing-only 95% hi"],
            "Grid paths (held out)": int(len(cfg.split(cfg.grid_paths)[1])),
            "Fresh estimate": d.mean, "Fresh 95% lo": d.lo, "Fresh 95% hi": d.hi,
            "Fresh paths": int(every.size),
            "Survives": bool(d.lo > 0),
        })
    return pd.DataFrame(rows)


# --------------------------------------------- when x how far (phases 6b, 7b)
# Every trigger crossed with every move fraction. Within one fraction the arms
# differ only in WHEN; within one trigger, only in HOW FAR.
#
# These comparisons are best rule against best rule: each side's knob is
# picked on calibration paths by its own net Sharpe, and the paired difference
# is scored on held-out paths. Equal turnover is the right test of one rule
# against a calendar (phases 2 and 7), but picking the knob with the largest
# advantage *at equal turnover* finds the turnover where the reference is
# weakest - for rules moving a quarter of the way, a calendar trading every few
# months - rather than a rule anybody would run. Best against best has no such
# blind spot, and "it traded less" cannot explain a win: both sides were free
# to trade less.

CELL_WHEN = {"Calendar": {"clock"}, "Event trigger": EVENT_TRIGGERS}
CELL_HOW_FAR = {"All the way": True, "Part of the way": False}

# margin -> (challenger cell, reference cell, what is compared)
MARGINS = {
    "WHEN, moving all the way": (
        ("Event trigger", "All the way"), ("Calendar", "All the way"),
        "best event-trigger rule vs best calendar, both moving all the way"),
    "WHEN, moving part of the way": (
        ("Event trigger", "Part of the way"), ("Calendar", "Part of the way"),
        "best event-trigger rule vs best calendar, both moving part of the way"),
    "HOW FAR, calendar timing": (
        ("Calendar", "Part of the way"), ("Calendar", "All the way"),
        "best calendar moving part of the way vs best calendar moving all the way"),
    "HOW FAR, event-trigger timing": (
        ("Event trigger", "Part of the way"), ("Event trigger", "All the way"),
        "best event-trigger rule moving part of the way vs the best moving all the way"),
}


@dataclass
class BestVsBest:
    """One factorial comparison, as `best_vs_best` returns it."""

    arm: object             # the best challenger, picked on calibration paths
    ref: object             # the best reference, picked the same way
    diff: object            # PairedDiff, challenger minus reference, held-out paths


def _is_full(a) -> bool:
    return a.move_fraction is not None and a.move_fraction >= 1.0


def _best(arms: list, calib_idx):
    """The arm with the best net Sharpe on calibration paths (None if none)."""
    return max(arms, key=lambda a: selection_score(a.net_sharpe[calib_idx])) if arms else None


def best_vs_best(cands: list, refs: list, calib_idx, eval_idx,
                 label: str = "{name} vs {ref}"):
    """The best challenger against the best reference, each picked on the
    calibration paths, scored as a paired difference on the held-out paths.
    `label` may contain {name} and {ref}."""
    a, b = _best(cands, calib_idx), _best(refs, calib_idx)
    if a is None or b is None:
        return None
    d = paired_diff(a.net_sharpe[eval_idx], b.net_sharpe[eval_idx],
                    label=label.format(name=a.name, ref=b.name))
    return BestVsBest(a, b, d)


def _factorial_tests(arms: list, calib_idx, eval_idx, lams=(1.0, 0.5, 0.25),
                     detail: bool = True) -> dict:
    """The 2x2 and its four margins, from the arms of a factorial zoo.

    cells   : (when, how far) -> the best arm in that cell.
    margins : MARGINS key -> BestVsBest. WHEN holds how far fixed and changes
              the trigger; HOW FAR holds the trigger fixed and changes the move.
    when    : (detail) per move fraction, each event trigger vs the calendar.
    how_far : (detail) per trigger, each partial fraction vs moving all the way.
    """
    def in_cell(when, how):
        return [a for a in arms if a.trigger in CELL_WHEN[when]
                and _is_full(a) == CELL_HOW_FAR[how]]

    def where(triggers, fractions):
        return [a for a in arms if a.trigger in triggers and a.move_fraction in fractions]

    cells = {(w, h): _best(in_cell(w, h), calib_idx)
             for w in CELL_WHEN for h in CELL_HOW_FAR}
    margins = {key: best_vs_best(in_cell(*ch), in_cell(*rf), calib_idx, eval_idx,
                                 label=f"{key}: {{name}} vs {{ref}}")
               for key, (ch, rf, _) in MARGINS.items()}
    out = {"cells": cells, "margins": margins}
    if not detail:
        return out

    when_rows, how_rows = [], []
    for lam in lams:
        for trig in [t for t in TRIGGER_ORDER if t in EVENT_TRIGGERS] + ["any"]:
            keep = EVENT_TRIGGERS if trig == "any" else {trig}
            bvb = best_vs_best(where(keep, [lam]), where({"clock"}, [lam]),
                               calib_idx, eval_idx,
                               label=f"WHEN at fraction {lam:g}: {{name}} vs {{ref}}")
            when_rows.append((lam, trig, bvb))
    partial = [l for l in lams if l < 1.0]
    for trig in TRIGGER_ORDER:
        for lam in partial + ["best"]:
            keep = partial if lam == "best" else [lam]
            bvb = best_vs_best(where({trig}, keep), where({trig}, [1.0]),
                               calib_idx, eval_idx,
                               label=f"HOW FAR, {TRIGGER_LABEL[trig].lower()}: {{name}} vs {{ref}}")
            how_rows.append((trig, lam, bvb))
    out.update(when=when_rows, how_far=how_rows)
    return out


def _bvb_row(bvb, eval_idx, prefix: str = "") -> dict:
    """A BestVsBest as table columns (empty if there was no comparison)."""
    keys = ("Rule", "Reference", "Rule Sharpe", "Reference Sharpe", "Rule turnover/yr",
            "Reference turnover/yr", "Delta Sharpe", "95% lo", "95% hi")
    if bvb is None:
        return {**{prefix + k: np.nan for k in keys}, prefix + "Significant": False}
    a, b, d = bvb.arm, bvb.ref, bvb.diff
    vals = (a.name, b.name, float(a.net_sharpe[eval_idx].mean()),
            float(b.net_sharpe[eval_idx].mean()), float(a.turnover[eval_idx].mean()),
            float(b.turnover[eval_idx].mean()), d.mean, d.lo, d.hi)
    return {**{prefix + k: v for k, v in zip(keys, vals)},
            prefix + "Significant": bool(d.significant)}


def _grid_factorial_zoo(cfg: PhaseConfig) -> list:
    """The factorial at grid size: the grid zoo's knobs, every move fraction."""
    return factorial_zoo(
        lams=cfg.factorial_lams,
        calendar_steps=(1, 2, 3, 5, 8, 13, 21, 34, 55, 90),
        volume_units=(1.0, 3.0, 10.0, 21.0, 60.0),
        cusum_thresholds=(0.5, 2.0, 5.0, 12.0, 24.0),
        target_thresholds=(0.05, 0.2, 0.8, 3.2, 8.0),
        bands=(0.02, 0.1, 0.4, 0.8, 1.4),
    )


def typical_trade(lab, aum: float) -> tuple[float, float]:
    """The benchmark's typical trade: median participation (share of daily
    volume) and median per-bar volatility over the bars where the target moves.

    Trading on every change moves the book by the target's daily change, so
    that change, in dollars over daily volume, is its order size (up to drift).
    """
    dw = np.abs(np.diff(lab.targets, axis=1))
    live = dw > 1e-9
    part = dw * aum / np.maximum(lab.market.adv[:, 1:, :], 1e-12)
    return float(np.median(part[live])), float(np.median(lab.market.vol[:, 1:, :][live]))


def phase6b_cost_shape(cfg: PhaseConfig | None = None) -> dict:
    """When does *when* start to matter? How cost grows with trade size.

    The explanation the study gives for its result is that cost grows faster
    than trade size (square-root impact makes total cost ~ size^1.5), so one
    large correction costs more than several small ones and timing a jump
    cannot beat moving gradually. This phase tests that explanation by
    changing only the shape of the cost:

      shape     proportional (flat rate) / square-root impact (the lab) /
                linear impact (total cost ~ size^2), all three charging the
                same per unit on the benchmark's typical trade;
      order fee a fixed charge per order, 0 / 0.1 / 0.5 bps of NAV (on a
                $100k book: $0 / $1 / $5 a ticket).

    Theory predicts the ordering: convex costs favour moving part of the way
    (Garleanu & Pedersen 2013); proportional costs favour a no-trade band
    (Constantinides 1986); a fixed cost of acting favours trading rarely and
    in full, which is where an event trigger should finally earn its keep.

    Same lab settings as phase 2 (half-life 10, burstiness 0.6, coupling 0.4)
    on `shape_paths` paths of grid length. Every comparison is best rule against best rule (see the
    note above `CELL_WHEN`), knobs picked on calibration paths and scored on
    held-out ones.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    lab = _grid_lab(cfg, n_paths=cfg.shape_paths, half_life=10.0, burstiness=0.6,
                    coupling=0.4)
    calib_idx, eval_idx = cfg.split(cfg.shape_paths)
    zoo = _grid_factorial_zoo(cfg)
    grid_cfg = replace(cfg, n_paths=cfg.shape_paths)
    p_typ, sig_typ = typical_trade(lab, cfg.aum)
    shapes = equal_cost_shapes(cfg.cost_model, p_typ, sig_typ)

    rows = []
    for shape, model in shapes.items():
        for fee in cfg.shape_order_fees:
            cm = replace(model, order_fee_bps=float(fee))
            arms = run_zoo(lab, grid_cfg, cm, zoo)
            ft = _factorial_tests(arms, calib_idx, eval_idx, cfg.factorial_lams,
                                  detail=False)
            best = _best(arms, calib_idx)
            by_name = {a.name: a for a in arms}
            row = {"Cost shape": shape, "Order fee (bps)": float(fee)}
            for key, bvb in ft["margins"].items():
                row.update(_bvb_row(bvb, eval_idx, prefix=f"{key} | "))
            row.update({
                "Best rule": best.name,
                "Best rule trigger": best.trigger,
                "Best rule move fraction": best.move_fraction,
                "Best rule Sharpe": float(best.net_sharpe[eval_idx].mean()),
                "AlwaysTrade Sharpe": float(by_name["AlwaysTrade"].net_sharpe[eval_idx].mean()),
            })
            rows.append(row)
    table = pd.DataFrame(rows)
    setting = pd.DataFrame([{
        "Typical trade (% of daily volume)": 100 * p_typ,
        "Typical daily vol (%)": 100 * sig_typ,
        "Cost per unit at the typical trade (bps)":
            cfg.cost_model.effective_bps(p_typ, sig_typ),
        **{f"{k}: cost per unit at 1/4 of the typical trade (bps)":
           m.effective_bps(p_typ / 4, sig_typ) for k, m in shapes.items()},
        "Paths (held out)": int(eval_idx.size),
    }])
    out = {"cost_shape": table, "setting": setting}
    _save(out, "phase6b")
    return out


# ----------------------------------------------------------------- phase 7


def phase7_benchmarks(lab, cfg: PhaseConfig | None = None, phase2: dict | None = None) -> dict:
    """The head-to-head claim, against the benchmarks a practitioner would use.

    The benchmark that matters is `AlwaysTrade`: follow the signal agnostically,
    trade whenever it changes, ignore volume, price action and the size of the
    move. Everything the project adds is an argument that *when* and *how far*
    should be decided rather than assumed.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    phase2 = phase2 or phase2_frontiers(lab, cfg)
    arms = phase2["_arms"]
    calib_idx, eval_idx = phase2["_calib_idx"], phase2["_eval_idx"]
    by_name = {a.name: a for a in arms}

    benchmark = by_name["AlwaysTrade"]
    bench_turnover = float(benchmark.turnover[calib_idx].mean())

    # "Ours": the best closed-loop arm that trades no MORE than the benchmark,
    # with the knob chosen on calibration paths only.
    closed = [a for a in arms if a.family in CLOSED_LOOP
              and a.turnover[calib_idx].mean() <= bench_turnover]
    ours = max(closed, key=lambda a: selection_score(a.net_sharpe[calib_idx]))

    # The placebo copies our scheduler's *how far* rule and its trade rate, and
    # randomises only *when*. That isolates the timing claim: if random times
    # do as well, the value was never in the trigger.
    sch_by_name = {s.name: s for s in default_zoo(seed=cfg.seed)}
    ours_sch = sch_by_name.get(ours.name)
    if ours_sch is None or ours_sch.move_fraction is None:
        raise ValueError(f"the placebo cannot copy the move rule of {ours.name}")
    ours_lam = float(ours_sch.move_fraction)
    rate = float(ours.trade_rate[calib_idx].mean())

    placebo_per_path, placebo_means, placebo_turnover = _placebo(
        lab, cfg, rate, ours_lam, eval_idx, seed0=10_000)
    ours_mean = float(ours.net_sharpe[eval_idx].mean())
    # Monte-Carlo p-value with the standard +1 correction (North, Curtis & Sham
    # 2002): it counts the observed rule as one of the draws, so it can never be
    # exactly zero and is not anti-conservative.
    n_ge = int((placebo_means >= ours_mean).sum())
    placebo_p = float((1 + n_ge) / (1 + placebo_means.size))

    wanted = ["AlwaysTrade", "Calendar(5)", "Calendar(21)", "BuyAndHold"]
    rows = [{
        "Label": "Paper portfolio (ceiling, free)",
        "Net Sharpe": phase2["paper_sharpe"],
        "Turnover/yr": float(phase2["_paper"].turnover[eval_idx].mean()),
        "Max DD": float(phase2["_paper"].max_dd[eval_idx].mean()),
        "Family": "ceiling", "Focus": False,
    }]
    for name in wanted:
        if name not in by_name:
            continue
        a = by_name[name]
        rows.append({
            "Label": name, "Net Sharpe": float(a.net_sharpe[eval_idx].mean()),
            "Turnover/yr": float(a.turnover[eval_idx].mean()),
            "Max DD": float(a.max_dd[eval_idx].mean()),
            "Family": a.family, "Focus": False,
        })
    # Best of each non-control family under the benchmark's turnover.
    for family in ("activity", "price-event", "target-event", "state-feedback"):
        cands = [a for a in arms if a.family == family
                 and a.turnover[calib_idx].mean() <= bench_turnover]
        if not cands:
            continue
        a = max(cands, key=lambda z: selection_score(z.net_sharpe[calib_idx]))
        rows.append({
            "Label": f"{family}: {a.name}", "Net Sharpe": float(a.net_sharpe[eval_idx].mean()),
            "Turnover/yr": float(a.turnover[eval_idx].mean()),
            "Max DD": float(a.max_dd[eval_idx].mean()),
            "Family": family, "Focus": a.name == ours.name,
        })
    rows.append({
        "Label": f"Placebo: random times, same move rule ({cfg.placebo_draws} draws)",
        "Net Sharpe": float(placebo_means.mean()),
        "Turnover/yr": float(np.mean(placebo_turnover)),
        "Max DD": float(np.nan),
        "Family": "control", "Focus": False,
    })
    bench_df = pd.DataFrame(rows)

    head_to_head = [
        paired_diff(ours.net_sharpe[eval_idx], by_name[n].net_sharpe[eval_idx],
                    label=f"{ours.name} - {n}")
        for n in wanted if n in by_name
    ]
    h2h_df = pd.DataFrame([d.as_row() for d in head_to_head])

    # --- attribution: how much of the gain is *when*, how much is *how far* ---
    # total  = ours - agnostic benchmark
    # when   = ours - (same move rule, same trade rate, random times)
    # howfar = (that placebo) - agnostic benchmark
    # The two components add up to the total by construction.
    d_total = paired_diff(ours.net_sharpe[eval_idx], benchmark.net_sharpe[eval_idx],
                          label="Total: ours - trade-every-signal benchmark")
    d_when = paired_diff(ours.net_sharpe[eval_idx], placebo_per_path[eval_idx],
                         label="WHEN to trade (vs random times, same move rule)")
    d_howfar = paired_diff(placebo_per_path[eval_idx], benchmark.net_sharpe[eval_idx],
                           label="HOW FAR to move (vs moving all the way)")
    attribution = pd.DataFrame([d.as_row() for d in (d_when, d_howfar, d_total)])

    # --- pure timing test -------------------------------------------------
    # Restrict to schedulers that always trade ALL the way to the target, so
    # "how far" is held fixed at 100% and only "when" differs. This is the
    # original hypothesis of the project, tested in isolation and at matched
    # turnover.
    # Each event rule is compared with the calendar that trades *exactly as
    # much as it does*, obtained by interpolating the clock family between its
    # two bracketing knobs, path by path. That is turnover matching done
    # properly: no argmax over a noisy level, and the paired difference is far
    # better determined than either Sharpe on its own -- which is what the knob
    # is then selected on.
    clocks = [a for a in arms if a.family == "clock"]
    timing_rows, timing_diffs = [], []
    for family in ("activity", "price-event", "target-event", "state-feedback"):
        eq = compare_at_equal_turnover(
            [a for a in arms if a.full_move and a.family == family], clocks,
            calib_idx, eval_idx, label=f"{family}: {{name}} vs calendar at equal turnover")
        if eq is None:
            continue
        timing_diffs.append(eq.diff)
        timing_rows.append({
            "Family": family, "Scheduler": eq.arm.name,
            "Net Sharpe": float(eq.arm.net_sharpe[eval_idx].mean()),
            "Turnover/yr": float(eq.arm.turnover[eval_idx].mean()),
            "Clock benchmark": "calendar interpolated to equal turnover",
            "Clock Sharpe": float(eq.base[eval_idx].mean()),
            **eq.diff.as_row(),
            "_cal_delta": eq.cal_delta,
        })

    # The same winner against random times at its own trade rate, moving fully:
    # this separates "the trigger is informative" from "trading less is good".
    if timing_rows:
        # Chosen on calibration paths, like every other pick in the study.
        best_family = max(timing_rows, key=lambda r: r["_cal_delta"])["Family"]
        best_timing = next(a for a in arms
                           if a.name == next(r["Scheduler"] for r in timing_rows
                                             if r["Family"] == best_family))
        t_rate = float(best_timing.trade_rate[calib_idx].mean())
        t_pp, t_means, _ = _placebo(lab, cfg, t_rate, 1.0, eval_idx, seed0=50_000)
        d = paired_diff(best_timing.net_sharpe[eval_idx], t_pp[eval_idx],
                        label=f"{best_timing.name} vs random times at the same rate")
        timing_diffs.append(d)
        timing_rows.append({
            "Family": "vs random-time placebo", "Scheduler": best_timing.name,
            "Net Sharpe": float(best_timing.net_sharpe[eval_idx].mean()),
            "Turnover/yr": float(best_timing.turnover[eval_idx].mean()),
            "Clock benchmark": "random times, matched trade rate",
            "Clock Sharpe": float(t_means.mean()),
            **d.as_row(),
        })
    timing_df = pd.DataFrame([{k: v for k, v in r.items() if not k.startswith("_")}
                              for r in timing_rows])

    out = {
        "benchmarks": bench_df, "head_to_head": h2h_df, "attribution": attribution,
        "timing_test": timing_df,
        "_ours": ours, "_benchmark": benchmark, "_h2h": head_to_head,
        "_attribution": [d_when, d_howfar, d_total], "_timing_diffs": timing_diffs,
        "_placebo_dist": placebo_means, "placebo_p": placebo_p,
        "ours_sharpe": ours_mean, "ours_lam": ours_lam,
        "summary": pd.DataFrame([{
            "Our scheduler": ours.name,
            "Our net Sharpe": ours_mean,
            "Our turnover/yr": float(ours.turnover[eval_idx].mean()),
            "Benchmark (AlwaysTrade) Sharpe": float(benchmark.net_sharpe[eval_idx].mean()),
            "Benchmark turnover/yr": float(benchmark.turnover[eval_idx].mean()),
            "Delta Sharpe": ours_mean - float(benchmark.net_sharpe[eval_idx].mean()),
            "Turnover saved (%)": 100 * (1 - float(ours.turnover[eval_idx].mean())
                                         / max(float(benchmark.turnover[eval_idx].mean()), 1e-9)),
            "of which WHEN to trade": d_when.mean,
            "of which HOW FAR to move": d_howfar.mean,
            "Placebo p-value": placebo_p,
        }]),
    }
    _save({k: v for k, v in out.items() if isinstance(v, pd.DataFrame)}, "phase7")
    return out


# ---------------------------------------------------------------- phase 7b


def phase7b_factorial(lab, cfg: PhaseConfig | None = None,
                      phase2: dict | None = None) -> dict:
    """When x how far: every trigger crossed with every move fraction.

    Phase 7 splits *one* rule's gain into when and how far. This phase asks
    the general question. Five triggers (calendar, volume clock, price CUSUM,
    target CUSUM, band) each move all the way, half the way and a quarter of
    the way, on the phase 2 lab and paths. Then:

      WHEN    hold the move fixed, change the trigger: the best event-trigger
              rule against the best calendar moving the same way;
      HOW FAR hold the trigger fixed, change the move: the best rule moving
              part of the way against the best moving all the way.

    The 2x2 (calendar / event trigger x all the way / part of the way) holds
    the best rule of each cell; its four margins are the four tests above.
    Every pick is made on calibration paths by net Sharpe and scored on
    held-out paths (best against best: see the note above `CELL_WHEN`). Rules
    already run in phase 2 are reused, not re-run, so their numbers are the
    phase 2 numbers exactly.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    phase2 = phase2 or phase2_frontiers(lab, cfg)
    calib_idx, eval_idx = phase2["_calib_idx"], phase2["_eval_idx"]
    have = {a.name: a for a in phase2["_arms"]}
    zoo = factorial_zoo(lams=cfg.factorial_lams)
    arms = [have[s.name] if s.name in have
            else arm_stats(simulate(lab.market, lab.targets, s, cfg.cost_model,
                                    cfg.sim_cfg), cfg.ann)
            for s in zoo]
    ft = _factorial_tests(arms, calib_idx, eval_idx, cfg.factorial_lams)
    paper = phase2["_paper"].subset(eval_idx)

    cell_rows = []
    for (when, how), a in ft["cells"].items():
        d = decompose(a.subset(eval_idx), paper)
        cell_rows.append({
            "When": when, "How far": how, "Rule": a.name, "Trigger": a.trigger,
            "Move fraction": a.move_fraction, "Net Sharpe": d["Net Sharpe"],
            "Turnover/yr": d["Turnover/yr"], "Tracking loss": d["Tracking loss"],
            "Cost drag": d["Cost drag"],
        })
    cells = pd.DataFrame(cell_rows)

    margins = pd.DataFrame([
        {"Test": key, "What is compared": MARGINS[key][2], **_bvb_row(bvb, eval_idx)}
        for key, bvb in ft["margins"].items()])
    when = pd.DataFrame([
        {"Move fraction": lam,
         "Trigger": "any event trigger" if trig == "any" else TRIGGER_LABEL[trig],
         **_bvb_row(bvb, eval_idx)} for lam, trig, bvb in ft["when"]])
    best_of = "best of " + "/".join(f"{l:g}" for l in cfg.factorial_lams if l < 1)
    how_far = pd.DataFrame([
        {"Trigger": TRIGGER_LABEL[trig],
         "Move fraction": best_of if lam == "best" else lam,
         **_bvb_row(bvb, eval_idx)} for trig, lam, bvb in ft["how_far"]])
    arms_df = pd.DataFrame([a.subset(eval_idx).mean() for a in arms])

    out = {
        "cells": cells, "margins": margins, "when": when, "how_far": how_far,
        "arms": arms_df,
        "_margins": {k: b.diff for k, b in ft["margins"].items() if b is not None},
        "_when": [b.diff for lam, trig, b in ft["when"] if trig == "any" and b],
        "_how_far": [b.diff for trig, lam, b in ft["how_far"] if lam == "best" and b],
    }
    _save({k: v for k, v in out.items() if isinstance(v, pd.DataFrame)}, "phase7b")
    return out


# ----------------------------------------------------------------- phase 5


UNIVERSE = "crypto"
TICKERS = ["BTC-USD", "ETH-USD"]
REAL_COST = "crypto_retail"
REAL_ANN = 365                     # crypto trades every calendar day


def load_crypto(start: str, end: str, use_cache: bool = True):
    """Download (and cache) BTC and ETH daily closes and volumes.

    The cache keeps Yahoo's numbers untouched; volumes are returned in coins
    traded, because Yahoo reports crypto volume in dollars (see data.py).
    """
    from .data import dollar_volume_to_units
    _ensure_dirs()
    path = os.path.join(CACHE, f"{UNIVERSE}_{start}_{end}.csv")
    if use_cache and os.path.exists(path):
        df = pd.read_csv(path, index_col=0, parse_dates=True, header=[0, 1])
        closes = df["close"].astype(float)
        dollar_volumes = df["volume"].astype(float)
    else:
        from .data import align_panel, download_ohlcv
        closes, dollar_volumes = align_panel(download_ohlcv(TICKERS, start, end, "1d"))
        pd.concat({"close": closes, "volume": dollar_volumes}, axis=1).to_csv(path)
    return closes, dollar_volume_to_units(dollar_volumes, closes)


def _real_zoo(cfg: PhaseConfig) -> list:
    return default_zoo(
        calendar_steps=(1, 2, 3, 5, 8, 13, 21, 34, 63, 126),
        volume_units=(1.0, 2.0, 5.0, 10.0, 21.0, 60.0),
        cusum_thresholds=(0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 30.0),
        target_thresholds=(0.05, 0.1, 0.3, 0.8, 1.6, 4.0, 10.0),
        bands=(0.02, 0.05, 0.15, 0.4, 0.8, 1.4),
        lams=(0.02, 0.05, 0.15, 0.4, 0.7, 1.0),
        placebo_rates=(0.01, 0.05, 0.15, 0.4, 1.0),
        seed=cfg.seed,
    )


def phase5_real(cfg: PhaseConfig | None = None) -> dict:
    """Does the lab's ranking survive on real prices?

    Two alphas on BTC and ETH:
      * ControlledAlpha -- look-ahead by construction, calibrated to a gross
        Sharpe of 1.0, so the scheduler comparison is clean on real price
        dynamics. It is an instrument, never a strategy claim.
      * Momentum -- honest and dull, to confirm the ordering is not an artefact
        of the instrument.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    zoo = _real_zoo(cfg)
    per_universe, summary_rows, nav_store, liquidity_rows = {}, [], {}, []

    uni = UNIVERSE
    try:
        closes, volumes = load_crypto(cfg.real_start, cfg.real_end)
    except Exception as exc:                           # offline / download error
        return {"summary": pd.DataFrame([{"Universe": uni, "Error": str(exc)[:120]}]),
                "arms": pd.DataFrame(), "liquidity": pd.DataFrame(),
                "_per_universe": {}, "_navs": {}}

    # Liquidity context. Impact scales with the square root of how much of
    # an asset's daily dollar volume a trade consumes, so this table says how
    # large the impact term can be for a $10m book in BTC and ETH.
    dv = (closes * volumes).median()
    liquidity_rows.append({
        "Universe": uni,
        "Assets": int(len(dv)),
        "Book size ($m)": cfg.aum / 1e6,
        "Deepest asset": str(dv.idxmax()),
        "Deepest median ADV ($m)": float(dv.max() / 1e6),
        "Thinnest asset": str(dv.idxmin()),
        "Thinnest median ADV ($m)": float(dv.min() / 1e6),
        "A 25%-of-NAV trade in it, as % of its ADV":
            float(100 * 0.25 * cfg.aum / max(dv.min(), 1.0)),
    })

    ann = REAL_ANN
    sim_cfg = SimConfig(exec_lag=1, ann_factor=ann, aum=cfg.aum)
    cm = COST_PRESETS[REAL_COST]
    market = build_market(closes, volumes)

    # One equal-risk-contribution cache: the sizing solution depends only on
    # the price history, so both alphas and every calibration pass reuse it.
    rp_cache: dict = {}
    size_kw = dict(vol_target=cfg.vol_target, sizing="risk_parity",
                   long_only=False, max_gross=2.0)

    alphas = {}
    ic, tgt_ctrl = calibrate_controlled_alpha(
        closes, volumes, target_sharpe=1.0, seed=cfg.seed, ann=ann,
        sim_cfg=sim_cfg, rp_cache=rp_cache, **size_kw,
    )
    alphas["Controlled (IC=%.2f)" % ic] = tgt_ctrl
    mom = MomentumAlpha(lookback=20, long_only=False)
    alphas["Momentum(20)"] = mom.targets(
        closes, volumes, ann=ann, rp_cache=rp_cache, **size_kw,
    )

    # Walk-forward split: the knob is chosen on the first half of the
    # sample and scored on the second, the single-path analogue of the
    # lab's calibration/evaluation split. Picking the best knob in sample
    # would guarantee a flattering answer and prove nothing.
    n_bars = closes.shape[0]
    split = n_bars // 2

    for alpha_name, targets in alphas.items():
        paper = paper_portfolio(market, targets, sim_cfg)
        paper_sharpe = float(annualised_sharpe(paper.net_returns[:, split:], ann)[0])
        arms, results, halves = [], {}, {}
        for sch in zoo:
            res = simulate(market, targets, sch, cm, sim_cfg)
            results[res.name] = res
            a = arm_stats(res, ann)
            arms.append(a)
            halves[a.name] = {
                "in": float(annualised_sharpe(res.net_returns[:, :split], ann)[0]),
                "out": float(annualised_sharpe(res.net_returns[:, split:], ann)[0]),
                "turn_in": float(res.turnover[:, :split].mean() * ann),
                "turn_out": float(res.turnover[:, split:].mean() * ann),
            }
        by_name = {a.name: a for a in arms}

        bench = by_name["AlwaysTrade"]
        closed = [a for a in arms if a.family in CLOSED_LOOP
                  and halves[a.name]["turn_in"] <= halves["AlwaysTrade"]["turn_in"]]
        ours = (max(closed, key=lambda a: halves[a.name]["in"]
                    if np.isfinite(halves[a.name]["in"]) else -np.inf)
                if closed else bench)

        table = pd.DataFrame([a.mean() for a in arms])
        table.insert(0, "Universe", uni)
        table.insert(1, "Alpha", alpha_name)
        table["Sharpe (in-sample half)"] = [halves[a.name]["in"] for a in arms]
        table["Sharpe (out-of-sample half)"] = [halves[a.name]["out"] for a in arms]

        ci = moving_block_paired_ci(
            results[ours.name].net_returns[:, split:],
            results[bench.name].net_returns[:, split:],
            iters=2000, block=20, ann=ann, seed=cfg.seed,
        )
        per_universe[(uni, alpha_name)] = {
            "table": table, "arms": arms, "results": results,
            "paper_sharpe": paper_sharpe, "ours": ours, "bench": bench, "ci": ci,
        }
        # Trade-level artefacts, one file per alpha: NAV, turnover
        # and the held book for the arms the argument is about.
        keep = [ours.name, "AlwaysTrade", "Calendar(21)", "BuyAndHold"]
        keep = list(dict.fromkeys(k for k in keep if k in results))
        tag = (f"{uni}_{alpha_name}".replace(" ", "").replace("(", "")
               .replace(")", "").replace("=", "").replace(".", "p")
               .replace("|", "_"))
        nav_df = pd.DataFrame(
            {k: np.cumprod(1 + results[k].net_returns[0]) for k in keep},
            index=closes.index)
        nav_df.insert(0, "Paper", np.cumprod(1 + paper.net_returns[0]))
        nav_df.to_csv(os.path.join(ARTIFACTS, f"phase5_nav_{tag}.csv"))
        pd.DataFrame({k: results[k].turnover[0] for k in keep},
                     index=closes.index).to_csv(
            os.path.join(ARTIFACTS, f"phase5_turnover_{tag}.csv"))

        nav_store[f"{uni} | {alpha_name}"] = {
            "Paper (free)": np.cumprod(1 + paper.net_returns[0]),
            ours.name: np.cumprod(1 + results[ours.name].net_returns[0]),
            "AlwaysTrade": np.cumprod(1 + results["AlwaysTrade"].net_returns[0]),
            "Calendar(21)": np.cumprod(1 + results["Calendar(21)"].net_returns[0]),
            "BuyAndHold": np.cumprod(1 + results["BuyAndHold"].net_returns[0]),
            "_index": closes.index,
            "_split": split,
        }
        summary_rows.append({
            "Universe": uni, "Assets": closes.shape[1], "Bars": n_bars,
            "Alpha": alpha_name,
            "Paper Sharpe (OOS half)": paper_sharpe,
            "Our scheduler (picked in-sample)": ours.name,
            "Our Sharpe (OOS)": halves[ours.name]["out"],
            "Our turnover/yr (OOS)": halves[ours.name]["turn_out"],
            "AlwaysTrade Sharpe (OOS)": halves["AlwaysTrade"]["out"],
            "AlwaysTrade turnover/yr (OOS)": halves["AlwaysTrade"]["turn_out"],
            "Delta Sharpe (OOS)": halves[ours.name]["out"] - halves["AlwaysTrade"]["out"],
            "Delta 95% lo": ci.lo, "Delta 95% hi": ci.hi,
            "Turnover saved (%)": 100 * (1 - halves[ours.name]["turn_out"]
                                         / max(halves["AlwaysTrade"]["turn_out"], 1e-9)),
            "Beats benchmark": bool(halves[ours.name]["out"]
                                    > halves["AlwaysTrade"]["out"]),
        })

    summary = pd.DataFrame(summary_rows)
    liquidity = pd.DataFrame(liquidity_rows)
    tables = [v["table"] for v in per_universe.values()]
    all_arms = pd.concat(tables, ignore_index=True) if tables else pd.DataFrame()
    out = {"summary": summary, "arms": all_arms, "liquidity": liquidity,
           "_per_universe": per_universe, "_navs": nav_store, "_ic": ic}
    _save({"summary": summary, "arms": all_arms, "liquidity": liquidity}, "phase5")
    return out


def picked_calendar(table: pd.DataFrame) -> str:
    """The calendar a desk would have chosen on the first half: the clock rule
    (other than trading on every change) with the best in-sample Sharpe. It is
    picked exactly the way our rule is, so neither side gets hindsight."""
    clocks = table[(table["Family"] == "clock") & (table["Scheduler"] != "AlwaysTrade")]
    return str(clocks.loc[clocks["Sharpe (in-sample half)"].idxmax(), "Scheduler"])


# ------------------------------------------------------------- phase 5b


def phase5_holdout(cfg: PhaseConfig | None = None, p5: dict | None = None) -> dict:
    """Fresh holdout: the rules picked in phase 5, scored on data that did not
    exist when they were picked.

    Nothing is re-chosen. Our rule and the comparison calendar are the ones
    phase 5 picked on 2017-11 -> 2021-06; the controlled alpha keeps the
    information coefficient calibrated on the study's sample. Every rule is run
    over the whole history (so positions carry into the holdout as they would in
    practice) and scored only on bars from `holdout_start`.

    Not a pass/fail criterion: it was added after the study's results were
    known, so it is reported as additional evidence, never scored.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    p5 = p5 if p5 is not None else phase5_real(cfg)
    empty = {"summary": pd.DataFrame(), "sensitivity": pd.DataFrame(),
             "consistency": pd.DataFrame(), "period": {}, "_navs": {}}
    if not p5.get("_per_universe"):
        return empty
    start = pd.Timestamp(cfg.holdout_start)
    try:
        closes, volumes = load_crypto(cfg.real_start, cfg.holdout_end)
        study_closes, _ = load_crypto(cfg.real_start, cfg.real_end)
    except Exception as exc:                           # offline / download error
        return {**empty, "summary": pd.DataFrame([{"Error": str(exc)[:120]}])}
    if start <= study_closes.index[-1]:
        raise ValueError("the holdout must start after the study's last bar")

    # Yahoo can revise history; report how much the overlap moved.
    overlap = study_closes.index.intersection(closes.index)
    revision = float((closes.loc[overlap] - study_closes.loc[overlap]).abs().max().max()
                     / study_closes.abs().max().max())
    hold = np.asarray(closes.index >= start)
    if hold.sum() < 60:
        return {**empty, "summary": pd.DataFrame([{"Error": "holdout too short"}])}

    ann = REAL_ANN
    sim_cfg = SimConfig(exec_lag=1, ann_factor=ann, aum=cfg.aum)
    cm = COST_PRESETS[REAL_COST]
    market = build_market(closes, volumes)
    size_kw = dict(vol_target=cfg.vol_target, sizing="risk_parity",
                   long_only=False, max_gross=2.0)
    rp_cache: dict = {}
    zoo = _real_zoo(cfg)

    rows, sens_rows, cons_rows, navs = [], [], [], {}
    for (uni, alpha_name), d in p5["_per_universe"].items():
        if alpha_name.startswith("Controlled"):
            provider = ControlledAlpha(ic=p5["_ic"], horizon=5, seed=cfg.seed)
        else:
            provider = MomentumAlpha(lookback=20, long_only=False)
        targets = provider.targets(closes, volumes, ann=ann, rp_cache=rp_cache, **size_kw)
        paper = paper_portfolio(market, targets, sim_cfg)
        res = {s.name: simulate(market, targets, s, cm, sim_cfg) for s in zoo}

        def sharpe(name):
            return float(annualised_sharpe(res[name].net_returns[:, hold], ann)[0])

        ours, cal = d["ours"].name, picked_calendar(d["table"])
        clocks = [s.name for s in zoo if s.family == "clock" and s.name != "AlwaysTrade"]
        best_cal = max(clocks, key=sharpe)
        ci_every = moving_block_paired_ci(res[ours].net_returns[:, hold],
                                          res["AlwaysTrade"].net_returns[:, hold],
                                          iters=2000, block=20, ann=ann, seed=cfg.seed)
        ci_cal = moving_block_paired_ci(res[ours].net_returns[:, hold],
                                        res[cal].net_returns[:, hold],
                                        iters=2000, block=20, ann=ann, seed=cfg.seed)
        trio = {"ours": ours, "every": "AlwaysTrade", "cal": cal}
        stat = {k: {"sharpe": sharpe(v),
                    "turn": float(res[v].turnover[0, hold].mean() * ann),
                    "dd": float(max_drawdown(res[v].net_returns[:, hold])[0]),
                    "growth": float(np.prod(1 + res[v].net_returns[0, hold]))}
                for k, v in trio.items()}
        rows.append({
            "Signal": alpha_name,
            "Paper Sharpe (free trading)": float(annualised_sharpe(paper.net_returns[:, hold], ann)[0]),
            "Our rule (picked 2017-21)": ours,
            "Our Sharpe": stat["ours"]["sharpe"],
            "Every change Sharpe": stat["every"]["sharpe"],
            "Calendar (picked 2017-21)": cal,
            "Calendar Sharpe": stat["cal"]["sharpe"],
            "Ours minus every change": ci_every.mean,
            "vs every change 95% lo": ci_every.lo, "vs every change 95% hi": ci_every.hi,
            "Ours minus calendar": ci_cal.mean,
            "vs calendar 95% lo": ci_cal.lo, "vs calendar 95% hi": ci_cal.hi,
            "Our turnover/yr": stat["ours"]["turn"],
            "Every change turnover/yr": stat["every"]["turn"],
            "Calendar turnover/yr": stat["cal"]["turn"],
            "Our worst fall": stat["ours"]["dd"],
            "Every change worst fall": stat["every"]["dd"],
            "Calendar worst fall": stat["cal"]["dd"],
            "Growth of $1, ours": stat["ours"]["growth"],
            "Growth of $1, every change": stat["every"]["growth"],
            "Growth of $1, calendar": stat["cal"]["growth"],
            "Best calendar with hindsight": best_cal,
            "Its Sharpe": sharpe(best_cal),
        })

        # Growth of $1 over the holdout only, rebased on its first day.
        first = int(np.flatnonzero(hold)[0])
        lines = {
            f"Our rule: {ours}  (Sharpe {stat['ours']['sharpe']:.2f})": ours,
            f"Trade on every signal change (benchmark)  (Sharpe {stat['every']['sharpe']:.2f})": "AlwaysTrade",
            f"Calendar picked on 2017-21: {cal}  (Sharpe {stat['cal']['sharpe']:.2f})": cal,
        }
        navs[alpha_name] = {"_index": closes.index[hold]}
        for label, name in lines.items():
            nav = np.cumprod(1 + res[name].net_returns[0])
            navs[alpha_name][label] = nav[hold] / nav[first - 1]

        # The same setting family in both unseen periods, for the sensitivity chart.
        oos = d["table"].set_index("Scheduler")["Sharpe (out-of-sample half)"]
        for name in [s.name for s in zoo if s.name.startswith("PartialAdjustment(")]:
            sens_rows.append({
                "Signal": alpha_name, "Scheduler": name,
                "Setting": float(name.split("(")[1].rstrip(")")),
                "Sharpe 2021-24": float(oos[name]), "Sharpe 2025-26": sharpe(name),
                "Benchmark 2021-24": float(oos["AlwaysTrade"]),
                "Benchmark 2025-26": stat["every"]["sharpe"],
                "Picked": name == ours,
            })

        # Ours minus each benchmark, in both unseen periods, same bootstrap.
        split = p5["_navs"][f"{uni} | {alpha_name}"]["_split"]
        old = d["results"]
        for bench_label, bench in (("vs trading on every change", "AlwaysTrade"),
                                   ("vs calendar picked the same way", cal)):
            ci_old = moving_block_paired_ci(old[ours].net_returns[:, split:],
                                            old[bench].net_returns[:, split:],
                                            iters=2000, block=20, ann=ann, seed=cfg.seed)
            ci_new = ci_every if bench == "AlwaysTrade" else ci_cal
            for period, ci in (("2021-24 test half", ci_old), ("2025-26 fresh holdout", ci_new)):
                cons_rows.append({"Signal": alpha_name, "Benchmark": bench_label,
                                  "Period": period, "Delta Sharpe": ci.mean,
                                  "95% lo": ci.lo, "95% hi": ci.hi,
                                  "Significant": bool(ci.lo > 0 or ci.hi < 0)})

    idx = closes.index[hold]
    period = {"start": str(idx[0].date()), "end": str(idx[-1].date()),
              "days": int(hold.sum()), "years": float(hold.sum() / ann),
              "overlap revision": revision}
    out = {"summary": pd.DataFrame(rows), "sensitivity": pd.DataFrame(sens_rows),
           "consistency": pd.DataFrame(cons_rows), "period": period, "_navs": navs}
    _save({k: v for k, v in out.items() if isinstance(v, pd.DataFrame)}, "phase5b")
    return out


# ----------------------------------------------------------------- phase 8


def phase8_verdict(p2: dict, p3: dict, p5: dict, p6: dict, p7: dict,
                   cfg: PhaseConfig | None = None, p6b: dict | None = None,
                   p7b: dict | None = None) -> dict:
    """Score the study's criteria. C1-C3 and C5 were fixed before the
    experiment; C4 was reworded post hoc (see below).

    The exploratory findings (phases 6b, 7b, the timing recheck and the
    timing tests of phase 7) are tabulated beside the criteria but never
    scored: they were designed after the criteria were known, to explain the
    result rather than to test it.

    Criteria:
      C1 closed-loop dominates open-loop at >= 3 of the tested turnover budgets,
         with a paired 95% CI excluding zero;
      C2 the chosen scheduler beats a matched random-timing placebo, p < 0.05;
      C3 the mechanism behaves as predicted: the closed-loop advantage grows
         with burstiness, and the price detector's edge grows with coupling;
      C4 the ordering survives on real BTC/ETH prices, out of sample, for
         both alphas (POST-HOC: replaced ">= 2 asset classes" after the study
         was narrowed to crypto only, when crypto results were already known);
      C5 execution algorithms deliver a measured saving over the naive fill,
         with the timing-risk trade-off quantified.
    """
    cfg = (cfg or PhaseConfig()).scaled()
    rows = []

    # ---- C1 ----
    g = p2["group"]
    n_sig = int((g["Significant"] & (g["Delta Sharpe"] > 0)).sum()) if len(g) else 0
    n_tested = len(g)
    # The registered criterion is the budget test; the exact equal-turnover
    # test is reported alongside it because it is the stricter statement and
    # the one that answers "did it just trade less?".
    eq = p2.get("equal_turnover")
    eq_note = ""
    if eq is not None and len(eq):
        best = eq.iloc[eq["Delta Sharpe"].argmax()]
        eq_note = (f"; at exactly equal turnover the best rule ({best['Scheduler']}) "
                   f"gives {best['Delta Sharpe']:+.3f} "
                   f"[{best['95% lo']:+.3f}, {best['95% hi']:+.3f}]")
    rows.append({
        "Criterion": "C1  Closed-loop dominates open-loop across turnover budgets",
        "Passed": n_sig >= 3,
        "Evidence": (f"significant positive at {n_sig}/{n_tested} budgets; "
                     f"median delta {g['Delta Sharpe'].median():+.3f}{eq_note}"
                     if n_tested else "not run"),
    })

    # ---- C2 ----
    p = p7["placebo_p"]
    rows.append({
        "Criterion": "C2  Beats a trade-count-matched random-timing placebo",
        "Passed": bool(p < 0.05),
        "Evidence": (f"our net Sharpe {p7['ours_sharpe']:.3f} vs "
                     f"{cfg.placebo_draws} placebo draws, p = {p:.3f}"),
    })

    # ---- C3 ----
    b = p6["mechanism_burst_coupling"]
    burst = b.groupby("Burstiness")["Closed-loop advantage"].mean()
    coup = b.groupby("Coupling")["Price-CUSUM - clock"].mean()
    burst_slope = float(np.polyfit(burst.index.astype(float), burst.values, 1)[0])
    coup_slope = float(np.polyfit(coup.index.astype(float), coup.values, 1)[0])
    rows.append({
        "Criterion": "C3  Mechanism: advantage grows with burstiness and coupling",
        "Passed": bool(burst_slope > 0 and coup_slope > 0),
        "Evidence": (f"d(advantage)/d(burstiness) = {burst_slope:+.3f}; "
                     f"d(price-CUSUM edge)/d(coupling) = {coup_slope:+.3f}"),
    })

    # ---- C4 ----
    s = p5["summary"]
    n_won = int(s["Beats benchmark"].sum()) if "Beats benchmark" in s else 0
    rows.append({
        "Criterion": "C4  Ordering survives on real BTC/ETH prices, both alphas",
        "Passed": n_won == len(s) == 2,
        "Evidence": (f"beats the agnostic benchmark out of sample for {n_won} of "
                     f"{len(s)} alphas" if len(s) else "not run"),
    })

    # ---- C5 ----
    sv = p3["savings"]
    best = sv.loc[sv["Saving bps"].idxmax()] if len(sv) else None
    rows.append({
        "Criterion": "C5  Execution saving measured, with timing risk quantified",
        "Passed": bool(best is not None and best["Saving bps"] > 0),
        "Evidence": (f"{best['label']} saves {best['Saving bps']:.1f} bps at "
                     f"{best['participation']*100:.1f}% of ADV, timing risk "
                     f"{best['Timing risk bps']:.0f} vs {best['Baseline timing risk bps']:.0f} bps"
                     if best is not None else "not run"),
    })

    table = pd.DataFrame(rows)
    findings = exploratory_findings(p6, p7, p6b, p7b)
    verdict = _write_verdict(table, p2, p5, p7, findings, p6b)
    out = {"criteria": table, "findings": findings,
           "verdict": pd.DataFrame([{"Verdict": verdict}])}
    _save(out, "phase8")
    return {**out, "text": verdict}


def _fmt(d: float, lo: float, hi: float) -> str:
    return f"{d:+.3f} [{lo:+.3f}, {hi:+.3f}]"


def exploratory_findings(p6: dict, p7: dict, p6b: dict | None = None,
                         p7b: dict | None = None) -> pd.DataFrame:
    """What the comparisons add beyond "partial adjustment wins". One row per
    finding: what was compared, what came out, and whether it holds (a paired
    95% interval on the right side of zero). Post hoc by design; never scored."""
    rows = []
    tt = p7["timing_test"].set_index("Family")
    fam = [f for f in ("activity", "price-event", "target-event", "state-feedback")
           if f in tt.index]
    if fam:
        best = max(fam, key=lambda f: tt.loc[f, "Delta Sharpe"])
        r = tt.loc[best]
        rows.append({
            "Finding": "F1  Picking the moment alone does not beat a calendar at equal turnover",
            "Phase": "7",
            "Holds": not any(bool(tt.loc[f, "Significant"]) and tt.loc[f, "Delta Sharpe"] > 0
                             for f in fam),
            "Evidence": (f"best of {len(fam)} trigger families moving all the way: "
                         f"{r['Scheduler']} {_fmt(r['Delta Sharpe'], r['95% lo'], r['95% hi'])}"),
        })
    if "vs random-time placebo" in tt.index and "state-feedback" in tt.index:
        rnd, cal = tt.loc["vs random-time placebo"], tt.loc["state-feedback"]
        rows.append({
            "Finding": "F2  A trigger beats random times but not a calendar",
            "Phase": "7",
            "Holds": bool(rnd["Significant"] and rnd["Delta Sharpe"] > 0
                          and not cal["Significant"]),
            "Evidence": (f"{rnd['Scheduler']}: vs random times at its own rate "
                         f"{_fmt(rnd['Delta Sharpe'], rnd['95% lo'], rnd['95% hi'])}; "
                         f"vs a calendar trading as much "
                         f"{_fmt(cal['Delta Sharpe'], cal['95% lo'], cal['95% hi'])}. "
                         f"What a trigger gains over random timing, regular spacing "
                         f"already gives"),
        })
    a = p7["attribution"].reset_index(drop=True)
    if len(a) == 3 and abs(a.loc[2, "Delta Sharpe"]) > 1e-12:
        share = a.loc[1, "Delta Sharpe"] / a.loc[2, "Delta Sharpe"]
        rows.append({
            "Finding": "F3  The recommended rule's gain is in pacing (how far), not when",
            "Phase": "7",
            "Holds": bool(share > 0.5),
            "Evidence": (f"HOW FAR {_fmt(a.loc[1, 'Delta Sharpe'], a.loc[1, '95% lo'], a.loc[1, '95% hi'])}"
                         f" ({100 * share:.0f}% of the gain); WHEN "
                         f"{_fmt(a.loc[0, 'Delta Sharpe'], a.loc[0, '95% lo'], a.loc[0, '95% hi'])}"),
        })
    if p7b is not None:
        w = p7b["when"]
        w = w[w["Trigger"] == "any event trigger"]
        rows.append({
            "Finding": "F4  Holding how far fixed, no trigger beats the calendar",
            "Phase": "7b",
            "Holds": not bool((w["Significant"] & (w["Delta Sharpe"] > 0)).any()),
            "Evidence": "; ".join(
                f"fraction {r['Move fraction']:g}: {r['Rule']} "
                f"{_fmt(r['Delta Sharpe'], r['95% lo'], r['95% hi'])}"
                for _, r in w.iterrows()),
        })
        h = p7b["how_far"]
        h = h[h["Move fraction"].astype(str).str.startswith("best")]
        n_win = int((h["Significant"] & (h["Delta Sharpe"] > 0)).sum())
        arms = p7b["arms"].set_index("Scheduler")
        rates = {r["Trigger"]: float(arms.loc[r["Rule"], "Trade rate"])
                 for _, r in h.iterrows() if r["Rule"] in arms.index}
        full = p7b["cells"].set_index(["When", "How far"])
        rows.append({
            "Finding": "F9  Moving part of the way, every trigger's best setting fires on most days",
            "Phase": "7b",
            "Holds": bool(rates) and min(rates.values()) >= 0.5,
            "Evidence": ("share of days traded by each trigger's best partial rule: " + "; ".join(
                f"{k} {v:.0%}" for k, v in rates.items())
                + f". Best full-move rules: calendar "
                f"{arms.loc[full.loc[('Calendar', 'All the way'), 'Rule'], 'Trade rate']:.0%}, "
                f"event trigger "
                f"{arms.loc[full.loc[('Event trigger', 'All the way'), 'Rule'], 'Trade rate']:.0%}. "
                f"Once the move is small, the best 'when' is 'nearly always'"),
        })
        rows.append({
            "Finding": "F5  Holding when fixed, moving part of the way wins for every trigger",
            "Phase": "7b",
            "Holds": n_win == len(h) and len(h) > 0,
            "Evidence": f"{n_win} of {len(h)} triggers significantly better part way; " + "; ".join(
                f"{r['Trigger']}: {_fmt(r['Delta Sharpe'], r['95% lo'], r['95% hi'])}"
                for _, r in h.iterrows()),
        })
    rc = p6.get("timing_recheck")
    if rc is not None and len(rc):
        top = rc.loc[rc["Grid estimate"].idxmax()]
        rows.append({
            "Finding": "F6  Picking the moment's best grid cell survives on fresh paths",
            "Phase": "6",
            "Holds": bool(rc["Survives"].any()),
            "Evidence": (f"half-life {top['Alpha half-life (bars)']:g}, {top['Cost (bps)']:g} bps, "
                         f"{top['Timing rule (frozen)']}: grid "
                         f"{_fmt(top['Grid estimate'], top['Grid 95% lo'], top['Grid 95% hi'])}, "
                         f"fresh {_fmt(top['Fresh estimate'], top['Fresh 95% lo'], top['Fresh 95% hi'])}; "
                         f"{int(rc['Survives'].sum())} of {len(rc)} cells in that row survive"),
        })
    if p6b is not None and len(p6b.get("cost_shape", [])):
        t = p6b["cost_shape"]
        free, fee = t[t["Order fee (bps)"] == 0], t[t["Order fee (bps)"] > 0]
        rows.append({
            "Finding": "F7  Picking the moment earns something only once acting has a fixed cost",
            "Phase": "6b",
            "Holds": (not any(_material_win(r, k) for _, r in free.iterrows() for k in WHEN_KEYS)
                      and any(_material_win(r, k) for _, r in fee.iterrows() for k in WHEN_KEYS)),
            "Evidence": cost_shape_summary(t),
        })
        far = free.set_index("Cost shape")[f"{HOW_FAR_KEY} | Delta Sharpe"]
        order = [k for k in ("proportional", "square-root", "linear impact") if k in far.index]
        rows.append({
            "Finding": "F8  The more convex the cost, the more moving part of the way is worth",
            "Phase": "6b",
            "Holds": len(order) == 3 and bool(far[order].is_monotonic_increasing),
            "Evidence": "HOW FAR on a calendar, no fee per order: " + "; ".join(
                f"{k} {far[k]:+.3f}" for k in order),
        })
    rows.sort(key=lambda r: int(r["Finding"].split()[0][1:]))
    return pd.DataFrame(rows)


WHEN_KEYS = ("WHEN, moving all the way", "WHEN, moving part of the way")
HOW_FAR_KEY = "HOW FAR, calendar timing"
# A difference smaller than this is immaterial however significant: two nearly
# identical rules can differ by +0.003 Sharpe with a tight interval. At the
# study's 15% volatility, 0.01 Sharpe is 15 bps a year.
MATERIAL = 0.01


def _sig_pos(row, key: str) -> bool:
    return bool(row[f"{key} | Significant"]) and row[f"{key} | Delta Sharpe"] > 0


def _material_win(row, key: str) -> bool:
    return _sig_pos(row, key) and row[f"{key} | Delta Sharpe"] >= MATERIAL


def cost_shape_summary(t: pd.DataFrame) -> str:
    """Phase 6b in two sentences, generated from the table: the most timing
    was worth with and without a fee per order, and what moving part of the
    way was worth under each cost shape."""
    def best_when(rows):
        cands = [(r[f"{k} | Delta Sharpe"], r, k) for _, r in rows.iterrows() for k in WHEN_KEYS
                 if np.isfinite(r[f"{k} | Delta Sharpe"])]
        return max(cands, key=lambda z: z[0]) if cands else None

    free, fee = t[t["Order fee (bps)"] == 0], t[t["Order fee (bps)"] > 0]
    parts = []
    w0 = best_when(free)
    if w0 is not None:
        parts.append(f"Without a fee per order, the best event trigger beat the best calendar "
                     f"moving the same way by at most {w0[0]:+.3f} Sharpe in any cost shape")
    w1 = best_when(fee)
    if w1 is not None:
        d, r, k = w1
        parts.append(f"with a fee of {fee['Order fee (bps)'].min():g}-{fee['Order fee (bps)'].max():g} "
                     f"bps per order, by up to {_fmt(d, r[f'{k} | 95% lo'], r[f'{k} | 95% hi'])} "
                     f"({r['Cost shape']} + {r['Order fee (bps)']:g} bps/order: "
                     f"{r[f'{k} | Rule']} vs {r[f'{k} | Reference']})")
    col = f"{HOW_FAR_KEY} | Delta Sharpe"
    top_fee = t["Order fee (bps)"].max()
    shapes = list(dict.fromkeys(t["Cost shape"]))

    def far_at(f):
        sub = t[t["Order fee (bps)"] == f].set_index("Cost shape")[col]
        return " / ".join(f"{sub[k]:+.3f}" for k in shapes if k in sub.index)

    far = (f"Moving part of the way (on a calendar) was worth {far_at(0.0)} under "
           f"{' / '.join(shapes)} costs without a fee, and {far_at(top_fee)} with "
           f"{top_fee:g} bps per order")
    return "; ".join(parts) + ". " + far


def _write_verdict(table: pd.DataFrame, p2: dict, p5: dict, p7: dict,
                   findings: pd.DataFrame | None = None, p6b: dict | None = None) -> str:
    """Generate the conclusion from the numbers, so re-runs stay honest."""
    n_pass = int(table["Passed"].sum())
    s = p7["summary"].iloc[0]
    g = p2["group"]
    lines = [
        f"{n_pass} of {len(table)} criteria passed (C4 is post-hoc).",
        "",
        f"Headline: {s['Our scheduler']} reaches a net Sharpe of "
        f"{s['Our net Sharpe']:.3f} against {s['Benchmark (AlwaysTrade) Sharpe']:.3f} "
        f"for the agnostic benchmark that trades on every signal change "
        f"({s['Delta Sharpe']:+.3f}), while trading "
        f"{s['Turnover saved (%)']:.0f}% less. Placebo p = {s['Placebo p-value']:.3f}.",
    ]
    if len(g):
        sig = g[g["Significant"] & (g["Delta Sharpe"] > 0)]
        lines.append(
            f"Closed-loop scheduling beat open-loop scheduling at "
            f"{len(sig)} of {len(g)} turnover budgets with a 95% CI excluding zero "
            f"(median {g['Delta Sharpe'].median():+.3f} Sharpe)."
        )
    if len(p5.get("summary", [])) and "Beats benchmark" in p5["summary"]:
        won = p5["summary"]["Beats benchmark"].sum()
        lines.append(
            f"On real data the same ordering held in {int(won)} of "
            f"{len(p5['summary'])} BTC/ETH alphas tested."
        )
    a = p7["attribution"].reset_index(drop=True)
    share = (a.loc[1, "Delta Sharpe"] / a.loc[2, "Delta Sharpe"]
             if len(a) == 3 and abs(a.loc[2, "Delta Sharpe"]) > 1e-12 else np.nan)
    lines += ["", "Main finding: " + (
        f"feedback beats the clock through pacing (HOW FAR each day: moving part "
        f"of the way spreads every rebalance over several days), not through "
        f"picking the moment (WHEN to trade). Of the "
        f"{a.loc[2, 'Delta Sharpe']:+.3f} gain over trading on every change, "
        f"{a.loc[1, 'Delta Sharpe']:+.3f} ({100 * share:.0f}%) comes from pacing "
        f"and {a.loc[0, 'Delta Sharpe']:+.3f} from picking the moment."
        if np.isfinite(share) and share > 0.5 else
        "the gain is not mainly in how far the rule moves; see the attribution."
    )]
    if p6b is not None and len(p6b.get("cost_shape", [])):
        lines.append("Where picking the moment matters (phase 6b): "
                     + cost_shape_summary(p6b["cost_shape"]) + ".")
    if findings is not None and len(findings):
        lines += ["", "Exploratory findings (added after the criteria were scored; "
                      "reported, not scored):"]
        for _, r in findings.iterrows():
            lines.append(f"  {r['Finding']} [{'holds' if r['Holds'] else 'does not hold'}]: "
                         f"{r['Evidence']}")
    lines += ["", "Reading: " + (
        "the decision of *when* to trade and *how far* to move is measurable, "
        "separable from the alpha, and worth more than the turnover it costs."
        if n_pass >= 4 else
        "the registered evidence is partial -- treat the criteria that failed as "
        "open questions, not as details. C2 and C3 test the picking-the-moment "
        "story, and the exploratory findings say why they fail: the timing that "
        "pays is pacing, with the pace set by costs and by how fast the signal fades."
    )]
    return "\n".join(lines)


# ------------------------------------------------------ report analytics
# Three tables that explain the result rather than restate it. Each re-reads
# arms already simulated (or re-runs a handful on one path) on the same
# held-out paths, so nothing here can disagree with phases 2, 5 and 7.

TRADEOFF_GROUPS = {
    ("clock", True): "Calendar (clock)",
    ("activity", True): "Volume clock",
    ("price-event", True): "Price-move trigger",
    ("target-event", True): "Target-move trigger",
    ("state-feedback", True): "Band trigger, full move",
    ("state-feedback", False): "Band, move part way",
}


def example_path(lab, cfg: PhaseConfig, names: list, path: int,
                 asset: int = 0, start: int = 300, length: int = 126) -> dict:
    """Target weight against the weight each rule actually holds, for one
    asset on one held-out path. Illustration only: every number the argument
    rests on comes from the full path set."""
    by_name = {sch.name: sch for sch in default_zoo(seed=cfg.seed)}
    market = lab.market.slice_paths(np.array([path]))
    targets = lab.targets[[path]]
    sim_cfg = replace(cfg.sim_cfg, store_weights=True)
    window = slice(start, start + length)
    out = {"bar": np.arange(start, start + length),
           "Target": targets[0, window, asset]}
    for name in names:
        res = simulate(market, targets, by_name[name], cfg.cost_model, sim_cfg)
        out[name] = {
            "held": res.weights[0, window, asset],
            "turnover_yr": float(res.turnover[0].mean() * cfg.ann),
            "gap": float(np.abs(res.weights[0, window, asset]
                                - targets[0, window, asset]).mean()),
        }
    return out


def tradeoff_table(p2: dict) -> pd.DataFrame:
    """Every non-control arm decomposed on the held-out paths: how much Sharpe
    it loses to staleness and how much to costs, against its turnover."""
    eval_idx = p2["_eval_idx"]
    paper = p2["_paper"].subset(eval_idx)
    rows = []
    for arm in p2["_arms"]:
        group = TRADEOFF_GROUPS.get((arm.family, arm.full_move))
        if group is None or arm.name == "PartialAdjustment(1)":
            continue                  # closing the whole gap daily IS the benchmark
        if arm.name.startswith("PartialAdjustment("):
            group = "Partial adjustment"   # its own line, so the curve is one rule
        d = decompose(arm.subset(eval_idx), paper)
        if d["Turnover/yr"] <= 1e-9:
            continue
        rows.append({"Group": group, **d})
    return pd.DataFrame(rows)


def robustness_table(p2: dict, p5: dict, p7: dict, rule: str = "PartialAdjustment") -> dict:
    """Net Sharpe of every setting of the recommended rule family, against the
    trade-every-change benchmark: simulated (held-out paths, with a paired
    95% interval per setting) and real BTC/ETH (out-of-sample half)."""
    eval_idx = p2["_eval_idx"]
    by_name = {a.name: a for a in p2["_arms"]}
    bench = by_name["AlwaysTrade"]
    rows = []
    for arm in p2["_arms"]:
        if not arm.name.startswith(rule + "("):
            continue
        d = paired_diff(arm.net_sharpe[eval_idx], bench.net_sharpe[eval_idx], label=arm.name)
        rows.append({"Setting": float(arm.knob), "Scheduler": arm.name,
                     "Net Sharpe": float(arm.net_sharpe[eval_idx].mean()),
                     "Turnover/yr": float(arm.turnover[eval_idx].mean()),
                     "vs benchmark": d.mean, "95% lo": d.lo, "95% hi": d.hi,
                     "Significant": bool(d.lo > 0 or d.hi < 0)})
    lab = pd.DataFrame(rows).sort_values("Setting").reset_index(drop=True)
    real = {}
    for (_, alpha), d in p5.get("_per_universe", {}).items():
        tbl = d["table"].set_index("Scheduler")
        fam = tbl[tbl.index.str.startswith(rule + "(")]
        real[alpha] = pd.DataFrame({
            "Setting": fam["Knob"].astype(float),
            "OOS Sharpe": fam["Sharpe (out-of-sample half)"],
        }).sort_values("Setting").reset_index().rename(columns={"index": "Scheduler"})
        real[alpha].attrs["benchmark"] = float(tbl.loc["AlwaysTrade", "Sharpe (out-of-sample half)"])
        real[alpha].attrs["picked"] = d["ours"].name
    return {"lab": lab, "lab_benchmark": float(bench.net_sharpe[eval_idx].mean()),
            "lab_picked": p7["_ours"].name, "real": real}


# ----------------------------------------------------------- bottom line


PLAIN_NAMES = {
    "AlwaysTrade": "Trade on every signal change (benchmark)",
    "Calendar(5)": "Rebalance every week",
    "Calendar(21)": "Rebalance every month",
}


def bottom_line(p2: dict, p5: dict, p7: dict, seed: int = 7,
                p7b: dict | None = None) -> dict:
    """The comparison an analyst needs, in plain words.

    Every simulated number is re-read from phases 2 and 7, on the same
    held-out paths, so the summary cannot drift from the evidence; our rule is
    the one phase 7 picked on calibration paths. The real-data section adds
    one new estimate: ours minus the calendar picked on the first half, with
    its own moving-block bootstrap interval.
    """
    eval_idx = p2["_eval_idx"]
    by_name = {a.name: a for a in p2["_arms"]}
    ours = p7["_ours"]
    paper = p2["_paper"].subset(eval_idx)

    rows = []
    for name in ("AlwaysTrade", "Calendar(5)", "Calendar(21)", ours.name):
        arm = by_name[name].subset(eval_idx)
        d = decompose(arm, paper)
        rows.append({
            "Rule": PLAIN_NAMES.get(name, f"Our rule: {name}"),
            "Scheduler": name,
            "Ours": name == ours.name,
            "Profit after costs (net Sharpe)": d["Net Sharpe"],
            "Trading per year (x NAV)": d["Turnover/yr"],
            "Worst fall (max drawdown)": float(arm.max_dd.mean()),
            "Lost to trading costs": d["Cost drag"],
            "Lost to holding a stale book": d["Tracking loss"],
        })
    scorecard = pd.DataFrame(rows)

    total = p7["attribution"].iloc[2]
    bench = scorecard.iloc[0]
    mine = scorecard[scorecard["Ours"]].iloc[0]
    headline = {
        "Our rule": ours.name,
        "Our net Sharpe": mine["Profit after costs (net Sharpe)"],
        "Benchmark net Sharpe": bench["Profit after costs (net Sharpe)"],
        "Gain (Sharpe)": float(total["Delta Sharpe"]),
        "Gain 95% lo": float(total["95% lo"]),
        "Gain 95% hi": float(total["95% hi"]),
        "Less trading (%)": 100 * (1 - mine["Trading per year (x NAV)"]
                                   / bench["Trading per year (x NAV)"]),
        "Paper Sharpe (free trading)": float(paper.net_sharpe.mean()),
    }

    # Real BTC/ETH: the out-of-sample half only, every line rebased to $1 on
    # the first out-of-sample day. The calendar shown is picked exactly as our
    # rule was -- best Sharpe on the first half -- so neither side gets
    # hindsight. (With hindsight some fixed calendars do better on this one
    # path; the notebook says so.)
    real, real_rows = {}, []
    for (uni, alpha), d in p5.get("_per_universe", {}).items():
        navs = p5["_navs"][f"{uni} | {alpha}"]
        split, idx = navs["_split"], navs["_index"]
        tbl, results = d["table"], d["results"]
        clocks = tbl[(tbl["Family"] == "clock") & (tbl["Scheduler"] != "AlwaysTrade")]
        mine_name, cal_name = d["ours"].name, picked_calendar(tbl)
        oos = tbl.set_index("Scheduler")["Sharpe (out-of-sample half)"]
        ci = moving_block_paired_ci(results[mine_name].net_returns[:, split:],
                                    results[cal_name].net_returns[:, split:],
                                    iters=2000, block=20, ann=REAL_ANN, seed=seed)
        real_rows.append({
            "Signal": alpha,
            "Our rule (picked 2017-21)": mine_name,
            "Our Sharpe 2021-24": float(oos[mine_name]),
            "Trade every change, Sharpe 2021-24": float(oos["AlwaysTrade"]),
            "Calendar (picked 2017-21)": cal_name,
            "Calendar Sharpe 2021-24": float(oos[cal_name]),
            "Ours minus calendar": float(oos[mine_name] - oos[cal_name]),
            "95% lo": ci.lo, "95% hi": ci.hi,
            "Best calendar with hindsight": str(oos[clocks["Scheduler"]].idxmax()),
            "Its Sharpe 2021-24": float(oos[clocks["Scheduler"]].max()),
        })
        # Sharpe goes in the label: growth of $1 alone rewards whichever line
        # took the most risk, and the chart must not hide that.
        lines = {
            f"Our rule: {mine_name}  (Sharpe {oos[mine_name]:.2f})": results[mine_name],
            f"{PLAIN_NAMES['AlwaysTrade']}  (Sharpe {oos['AlwaysTrade']:.2f})":
                results["AlwaysTrade"],
            f"Best calendar picked on 2017-21: {cal_name}  (Sharpe {oos[cal_name]:.2f})":
                results[cal_name],
        }
        real[alpha] = {"_index": idx[split:]}
        for label, res in lines.items():
            nav = np.cumprod(1 + res.net_returns[0])
            real[alpha][label] = nav[split:] / nav[split - 1]

    out = {"scorecard": scorecard, "headline": pd.DataFrame([headline]),
           "budgets": p2["group"], "attribution": p7["attribution"],
           "two_by_two": None if p7b is None else p7b["cells"],
           "real": pd.DataFrame(real_rows), "_real": real}
    _save({"scorecard": scorecard, "headline": out["headline"], "real": out["real"]},
          "bottom_line")
    return out


# ------------------------------------------------------------------- all


def run_all(cfg: PhaseConfig | None = None, verbose: bool = True) -> dict:
    """Every phase, in order. This is what `python -m FYP.run_phases` calls."""
    import time as _time
    cfg = (cfg or PhaseConfig()).scaled()
    _ensure_dirs()
    _t0 = _time.time()

    def say(msg):
        if verbose:
            print(f"[{_time.time() - _t0:6.1f}s] {msg}", flush=True)

    say("Phase 1  building calibrated laboratory ...")
    p1 = phase1_lab(cfg)
    say(f"         paper Sharpe = {p1['validation']['Paper Sharpe (eval paths)'][0]:.3f}")

    say("Phase 2  scheduler zoo and frontiers ...")
    p2 = phase2_frontiers(p1["lab"], cfg)

    say("Phase 3  measuring execution algorithms ...")
    p3 = phase3_execution(cfg)

    say("Phase 4  statistical power ...")
    lab_effect = float(p2["group"]["Delta Sharpe"].median()) if len(p2["group"]) else None
    p4 = phase4_power(cfg, lab_effect=lab_effect)

    say("Phase 5  real data ...")
    p5 = phase5_real(cfg)
    say("Phase 5b fresh holdout (2025-26) ...")
    p5h = phase5_holdout(cfg, p5)

    say("Phase 6  regime map, mechanism, timing recheck ...")
    p6 = phase6_regime_map(cfg)
    say("Phase 6b cost shape x fixed fee: when does timing matter? ...")
    p6b = phase6b_cost_shape(cfg)

    say("Phase 7  benchmarks and placebo ...")
    p7 = phase7_benchmarks(p1["lab"], cfg, p2)
    say("Phase 7b when x how far factorial ...")
    p7b = phase7b_factorial(p1["lab"], cfg, p2)

    say("Phase 8  verdict ...")
    p8 = phase8_verdict(p2, p3, p5, p6, p7, cfg, p6b=p6b, p7b=p7b)
    say("")
    say(p8["text"])
    ex_names = ["AlwaysTrade", "Calendar(21)", "NoTradeBand(0.4)-full", p7["_ours"].name]
    analytics = {
        "example": example_path(p1["lab"], cfg, ex_names,
                                path=int(p2["_eval_idx"][0])),
        "labels": {"AlwaysTrade": "Trade on every signal change (benchmark)",
                   "Calendar(21)": "Rebalance every month",
                   "NoTradeBand(0.4)-full": "Trade when far off, then move all the way",
                   p7["_ours"].name: f"Our rule: {p7['_ours'].name}"},
        "highlight": p7["_ours"].name,
        "tradeoff": tradeoff_table(p2),
        "robustness": robustness_table(p2, p5, p7),
    }
    return {"cfg": cfg, "p1": p1, "p2": p2, "p3": p3, "p4": p4,
            "p5": p5, "p5h": p5h, "p6": p6, "p6b": p6b, "p7": p7, "p7b": p7b,
            "p8": p8, "bottom": bottom_line(p2, p5, p7, cfg.seed, p7b=p7b),
            "analytics": analytics}
