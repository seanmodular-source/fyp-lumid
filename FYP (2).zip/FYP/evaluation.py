"""Metrics, attribution, frontier selection and statistical power.

Three ideas do most of the work here.

1. **The decomposition is exact and additive.** For any scheduler::

       Sharpe_net = Sharpe_paper - tracking_loss - cost_drag

   where the paper portfolio holds the target exactly at zero cost under the
   same execution lag. Tracking loss is what you give up by not being at the
   target; cost drag is what you pay to get there. Every scheduler is a choice
   about how to split that budget, and this is the sentence the project set out
   to fill in.

2. **Knobs are chosen out-of-sample.** Monte-Carlo paths are split into a
   calibration set (used to pick each family's knob at a given turnover budget)
   and an evaluation set (used to report). A family cannot win by having its
   best parameter picked with hindsight.

3. **Power is computed before the experiment, not after.** An effect smaller
   than the minimum detectable difference cannot be found no matter how the
   backtest is written, and a null result in that regime says nothing at all
   about the hypothesis.

    Lo (2002), "The statistics of Sharpe ratios", Financial Analysts Journal
        58(4), 36-52.
    Kunsch (1989), "The jackknife and the bootstrap for general
        stationary observations", Annals of Statistics 17(3), 1217-1241.
    Clarke, de Silva & Thorley (2002), "Portfolio constraints and the
        fundamental law of active management", FAJ 58(5), 48-66.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

try:                                   # scipy is available, but keep a fallback
    from scipy import stats as _stats
except Exception:                      # pragma: no cover
    _stats = None


# --------------------------------------------------------------- primitives


def _as2d(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return x[None, :] if x.ndim == 1 else x


def annualised_sharpe(returns: np.ndarray, ann: int = 252) -> np.ndarray:
    """Per-path annualised Sharpe of a (S,T) return array.

    A constant return series has no Sharpe ratio, so this returns NaN rather
    than 0.0. The difference matters: a rule that never trades produces exactly
    zero returns, and scoring it 0.0 would rank it *above* every rule that
    genuinely lost money, letting a do-nothing arm be selected as a family's
    best representative at low turnover.
    """
    r = _as2d(returns)
    sd = r.std(axis=1, ddof=1)
    mu = r.mean(axis=1)
    return np.where(sd > 0, mu / np.where(sd > 0, sd, 1.0) * np.sqrt(ann), np.nan)


def annualised_return(returns: np.ndarray, ann: int = 252) -> np.ndarray:
    r = _as2d(returns)
    n = r.shape[1]
    growth = np.exp(np.log1p(np.clip(r, -0.999999, None)).sum(axis=1))
    return growth ** (ann / max(n, 1)) - 1.0


def annualised_vol(returns: np.ndarray, ann: int = 252) -> np.ndarray:
    return _as2d(returns).std(axis=1, ddof=1) * np.sqrt(ann)


def max_drawdown(returns: np.ndarray) -> np.ndarray:
    r = _as2d(returns)
    nav = np.cumprod(1.0 + np.clip(r, -0.999999, None), axis=1)
    # The running peak starts at the opening NAV of 1.0, so a loss on the very
    # first bar counts as a drawdown too.
    peak = np.maximum(np.maximum.accumulate(nav, axis=1), 1.0)
    return (nav / peak - 1.0).min(axis=1)


def selection_score(values: np.ndarray) -> float:
    """Score used when picking a knob. An arm whose statistic is undefined (a
    rule that never trades, so its Sharpe is NaN) can never win a selection."""
    m = float(np.mean(values))
    return m if np.isfinite(m) else -np.inf


def turnover_per_year(turnover: np.ndarray, ann: int = 252) -> np.ndarray:
    return _as2d(turnover).mean(axis=1) * ann


def cost_per_year(cost: np.ndarray, ann: int = 252) -> np.ndarray:
    return _as2d(cost).mean(axis=1) * ann


# ------------------------------------------------------------------- arms


@dataclass
class ArmStats:
    """Per-path statistics for one (alpha x scheduler) arm."""

    name: str
    family: str
    knob: float | None
    net_sharpe: np.ndarray
    gross_sharpe: np.ndarray
    ann_return: np.ndarray
    ann_vol: np.ndarray
    max_dd: np.ndarray
    turnover: np.ndarray          # one-way, per year, as a fraction of NAV
    cost: np.ndarray              # per year, as a fraction of NAV
    trade_rate: np.ndarray        # fraction of bars on which the arm traded
    full_move: bool = True        # trades all the way to the target when it acts
    trigger: str = "unknown"      # WHEN axis (see schedulers.py)
    move_fraction: float | None = 1.0   # HOW FAR axis; None = not a fixed fraction

    def mean(self) -> dict:
        return {
            "Scheduler": self.name,
            "Family": self.family,
            "Knob": self.knob,
            "Full move": self.full_move,
            "Trigger": self.trigger,
            "Move fraction": self.move_fraction,
            "Net Sharpe": float(self.net_sharpe.mean()),
            "Gross Sharpe": float(self.gross_sharpe.mean()),
            "Ann. Return": float(self.ann_return.mean()),
            "Ann. Vol": float(self.ann_vol.mean()),
            "Max DD": float(self.max_dd.mean()),
            "Turnover/yr": float(self.turnover.mean()),
            "Cost/yr": float(self.cost.mean()),
            "Trade rate": float(self.trade_rate.mean()),
        }

    def subset(self, idx: np.ndarray) -> "ArmStats":
        return ArmStats(
            self.name, self.family, self.knob,
            self.net_sharpe[idx], self.gross_sharpe[idx], self.ann_return[idx],
            self.ann_vol[idx], self.max_dd[idx], self.turnover[idx],
            self.cost[idx], self.trade_rate[idx], self.full_move,
            self.trigger, self.move_fraction,
        )


def arm_stats(result, ann: int | None = None) -> ArmStats:
    """Collapse a SimResult into per-path statistics.

    `ann` defaults to the annualisation the simulation was actually run with,
    rather than to 252: a caller who forgets the argument on a 365-bar crypto
    run would otherwise mis-annualise everything with no error.
    """
    ann = int(result.meta.get("ann_factor", 252)) if ann is None else ann
    return ArmStats(
        name=result.name,
        family=result.meta.get("family", "unknown"),
        knob=result.meta.get("knob"),
        net_sharpe=annualised_sharpe(result.net_returns, ann),
        gross_sharpe=annualised_sharpe(result.gross_returns, ann),
        ann_return=annualised_return(result.net_returns, ann),
        ann_vol=annualised_vol(result.net_returns, ann),
        max_dd=max_drawdown(result.net_returns),
        turnover=turnover_per_year(result.turnover, ann),
        cost=cost_per_year(result.cost, ann),
        trade_rate=result.trades.mean(axis=1),
        full_move=bool(result.meta.get("full_move", True)),
        trigger=result.meta.get("trigger", "unknown"),
        move_fraction=result.meta.get("move_fraction", 1.0),
    )


# ----------------------------------------------------------- decomposition


def decompose(arm: ArmStats, paper: ArmStats) -> dict:
    """Exact additive attribution of the gap to the paper portfolio.

        paper - tracking_loss - cost_drag = net
    """
    paper_s = float(paper.net_sharpe.mean())
    gross_s = float(arm.gross_sharpe.mean())
    net_s = float(arm.net_sharpe.mean())
    return {
        "Scheduler": arm.name,
        "Family": arm.family,
        "Paper Sharpe": paper_s,
        "Tracking loss": paper_s - gross_s,
        "Cost drag": gross_s - net_s,
        "Net Sharpe": net_s,
        "Transfer coefficient": gross_s / paper_s if paper_s != 0 else np.nan,
        "Turnover/yr": float(arm.turnover.mean()),
    }


# ------------------------------------------------------- paired inference


@dataclass
class PairedDiff:
    label: str
    mean: float
    se: float
    lo: float
    hi: float
    t_stat: float
    p_value: float
    n: int

    @property
    def significant(self) -> bool:
        return self.lo > 0 or self.hi < 0

    def as_row(self) -> dict:
        return {
            "Comparison": self.label,
            "Delta Sharpe": self.mean,
            "95% lo": self.lo,
            "95% hi": self.hi,
            "t": self.t_stat,
            "p": self.p_value,
            "Significant": self.significant,
            "n paths": self.n,
        }


def paired_diff(a: np.ndarray, b: np.ndarray, label: str = "", alpha: float = 0.05) -> PairedDiff:
    """Paired comparison of two per-path statistics (common random numbers).

    Because both arms saw identical prices and identical alpha, the difference
    is far less noisy than either level -- this is the variance reduction that
    makes a 0.05 Sharpe effect resolvable.
    """
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    mean = float(d.mean())
    se = float(d.std(ddof=1) / np.sqrt(n)) if n > 1 else 0.0
    if se == 0 or n < 2:
        # Identical or single observation: the difference is not measurable,
        # so report it as such rather than as an infinitely strong result.
        return PairedDiff(label, mean, 0.0, np.nan, np.nan, np.nan, np.nan, n)
    t_stat = mean / se
    if _stats is not None:
        crit = _stats.t.ppf(1 - alpha / 2, df=n - 1)
        p = float(2 * _stats.t.sf(abs(t_stat), df=n - 1))   # sf: no underflow to 0
    else:                                              # pragma: no cover
        crit, p = 1.96, float("nan")
    return PairedDiff(label, mean, se, mean - crit * se, mean + crit * se, t_stat, p, n)


def moving_block_paired_ci(
    r_a: np.ndarray, r_b: np.ndarray, iters: int = 2000, block: int = 20,
    ann: int = 252, seed: int = 42, alpha: float = 0.05,
) -> PairedDiff:
    """Sharpe(A) - Sharpe(B) for a single realised path, via a moving-block
    bootstrap that resamples *the same blocks* from both series."""
    ra = np.asarray(r_a, float).ravel()
    rb = np.asarray(r_b, float).ravel()
    n = min(ra.size, rb.size)
    ra, rb = ra[:n], rb[:n]
    point = float(annualised_sharpe(ra, ann)[0] - annualised_sharpe(rb, ann)[0])
    if n < 2 * block:
        return PairedDiff("", point, np.nan, np.nan, np.nan, np.nan, np.nan, n)
    rng = np.random.default_rng(seed)
    n_blocks = int(np.ceil(n / block))
    starts = rng.integers(0, n - block + 1, size=(iters, n_blocks))
    offs = np.arange(block)
    idx = (starts[:, :, None] + offs[None, None, :]).reshape(iters, -1)[:, :n]
    ba, bb = ra[idx], rb[idx]
    sa = ba.mean(axis=1) / np.where(ba.std(axis=1, ddof=1) > 0, ba.std(axis=1, ddof=1), 1) * np.sqrt(ann)
    sb = bb.mean(axis=1) / np.where(bb.std(axis=1, ddof=1) > 0, bb.std(axis=1, ddof=1), 1) * np.sqrt(ann)
    d = sa - sb
    lo, hi = np.percentile(d, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    se = float(d.std(ddof=1))
    return PairedDiff("", point, se, float(lo), float(hi),
                      point / se if se else np.nan, np.nan, n)


def block_bootstrap_sharpe(
    returns: np.ndarray, iters: int = 2000, block: int = 20,
    ann: int = 252, seed: int = 42, alpha: float = 0.05,
) -> tuple[float, float, float]:
    """(median, lo, hi) Sharpe for one realised path."""
    r = np.asarray(returns, float).ravel()
    n = r.size
    if n < 2 * block:
        s = float(annualised_sharpe(r, ann)[0])
        return s, s, s
    rng = np.random.default_rng(seed)
    n_blocks = int(np.ceil(n / block))
    starts = rng.integers(0, n - block + 1, size=(iters, n_blocks))
    offs = np.arange(block)
    idx = (starts[:, :, None] + offs[None, None, :]).reshape(iters, -1)[:, :n]
    b = r[idx]
    sd = b.std(axis=1, ddof=1)
    s = b.mean(axis=1) / np.where(sd > 0, sd, 1.0) * np.sqrt(ann)
    lo, hi = np.percentile(s, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(np.median(s)), float(lo), float(hi)


# --------------------------------------------------------------- frontiers


def frontier_points(arms: list[ArmStats], families: list[str] | None = None) -> list[dict]:
    """Every (turnover, net Sharpe) point, tagged by family -- the raw frontier."""
    rows = []
    for a in arms:
        if families and a.family not in families:
            continue
        row = a.mean()
        rows.append(row)
    return rows


def select_by_budget(
    arms: list[ArmStats],
    budgets: np.ndarray,
    calib_idx: np.ndarray,
    eval_idx: np.ndarray,
) -> dict[str, list[dict]]:
    """For each family and each turnover budget, pick the knob that maximises
    net Sharpe **on the calibration paths** subject to
    turnover <= budget, then report its performance on the evaluation paths.

    Returns {family: [row per budget]}, each row carrying the selected arm's
    per-path evaluation Sharpes so that paired CIs can be formed downstream.
    """
    out: dict[str, list[dict]] = {}
    for arm in arms:
        out.setdefault(arm.family, [])
    for family in out:
        fam_arms = [a for a in arms if a.family == family]
        for b in budgets:
            eligible = [a for a in fam_arms
                        if a.turnover[calib_idx].mean() <= b
                        and np.isfinite(a.net_sharpe[calib_idx].mean())]
            if not eligible:
                continue
            best = max(eligible, key=lambda a: selection_score(a.net_sharpe[calib_idx]))
            out[family].append({
                "Family": family,
                "Budget": float(b),
                "Scheduler": best.name,
                "Knob": best.knob,
                "Turnover/yr": float(best.turnover[eval_idx].mean()),
                "Net Sharpe": float(best.net_sharpe[eval_idx].mean()),
                "Gross Sharpe": float(best.gross_sharpe[eval_idx].mean()),
                "Cost/yr": float(best.cost[eval_idx].mean()),
                "Max DD": float(best.max_dd[eval_idx].mean()),
                "_eval_sharpe": best.net_sharpe[eval_idx],
            })
    return out


def dominance(
    selected: dict[str, list[dict]],
    challenger: str,
    reference: str,
) -> list[PairedDiff]:
    """Paired challenger-minus-reference at every shared turnover budget."""
    ref = {r["Budget"]: r for r in selected.get(reference, [])}
    out = []
    for row in selected.get(challenger, []):
        b = row["Budget"]
        if b not in ref:
            continue
        d = paired_diff(row["_eval_sharpe"], ref[b]["_eval_sharpe"],
                        label=f"{challenger} - {reference} @ turnover<={b:g}")
        out.append(d)
    return out


# ------------------------------------------------------------------ power


def sharpe_se(sharpe_ann: float, n_obs: int, ann: int = 252) -> float:
    """Standard error of an *annualised* Sharpe estimate (Lo 2002, i.i.d.).

    Lo's asymptotic result is for the per-period Sharpe:
        SE(SR_period) = sqrt((1 + SR_period^2 / 2) / n).
    Annualising multiplies the estimate -- and its standard error -- by
    sqrt(ann), with SR_period = SR_ann / sqrt(ann), so

        SE(SR_ann) = sqrt((ann + SR_ann^2 / 2) / n).

    A useful sanity check falls straight out: for any realistic Sharpe this is
    approximately 1/sqrt(years). Three years of daily data therefore carries a
    standard error near 0.58 on an annualised Sharpe, so a single backtest over
    a short sample cannot resolve small differences: its 95% interval is about
    +/-1.1 wide before anything else goes wrong.
    """
    return float(np.sqrt((ann + 0.5 * sharpe_ann ** 2) / max(n_obs, 1)))


def paired_sharpe_se(sharpe_ann: float, n_obs: int, rho: float, ann: int = 252) -> float:
    """SE of the *difference* of two annualised Sharpes on correlated series.

    Two schedulers trading the same alpha are highly correlated (rho ~ 0.9-0.99),
    and the paired SE carries a factor sqrt(2(1-rho)). At rho = 0.95 that is a
    3.2x reduction versus comparing two independent backtests -- the entire
    reason this study runs every arm on common random numbers.
    """
    return float(np.sqrt(2.0 * (1.0 - rho)) * sharpe_se(sharpe_ann, n_obs, ann))


def minimum_detectable_delta(
    n_years: float, ann: int = 252, sharpe: float = 1.0, rho: float = 0.95,
    alpha: float = 0.05, power: float = 0.8, n_paths: int = 1,
) -> float:
    """Smallest Sharpe difference detectable at the given power.

    n_paths > 1 models the Monte-Carlo design: independent paths divide the
    variance, which is how the lab resolves effects that a single historical
    sample never could.
    """
    n_obs = max(n_years * ann, 1)
    se = paired_sharpe_se(sharpe, int(n_obs), rho, ann) / np.sqrt(max(n_paths, 1))
    if _stats is not None:
        z = _stats.norm.ppf(1 - alpha / 2) + _stats.norm.ppf(power)
    else:                                                # pragma: no cover
        z = 1.959964 + 0.841621
    return float(z * se)


def years_required(
    effect: float, ann: int = 252, sharpe: float = 1.0, rho: float = 0.95,
    alpha: float = 0.05, power: float = 0.8,
) -> float:
    """Years of a single historical sample needed to resolve `effect`."""
    if effect <= 0:
        return np.inf
    if _stats is not None:
        z = _stats.norm.ppf(1 - alpha / 2) + _stats.norm.ppf(power)
    else:                                                # pragma: no cover
        z = 1.959964 + 0.841621
    n_obs = (z / effect) ** 2 * 2.0 * (1 - rho) * (ann + 0.5 * sharpe ** 2)
    return float(n_obs / ann)


def implementation_ratio(turnover_pa: float, cost_bps: float, ann_vol: float) -> float:
    """Sharpe points destroyed per year by trading costs.

        implementation ratio = turnover x cost / volatility

    This is the entire prize on the table for execution research. If it is
    smaller than the minimum detectable delta, no amount of backtesting care
    can reveal an execution effect -- the experiment is under-powered by
    construction.
    """
    return float(turnover_pa * cost_bps * 1e-4 / max(ann_vol, 1e-12))
