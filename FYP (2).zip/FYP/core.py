"""Vectorised portfolio simulator -- the single engine every experiment uses.

Three design decisions carry the whole study:

1. **Weight drift is modelled.** Holding weights constant between rebalances
   silently grants free daily rebalancing and makes turnover - the quantity
   this project is about - meaningless. Here positions drift with prices and
   turnover is measured against the *drifted* book.

2. **One engine, batched over Monte-Carlo paths.** Arrays are (S, T, N):
   S paths, T bars, N assets. Every scheduler sees the identical price and
   alpha paths -- common random numbers -- so paired differences have a much
   smaller standard error than independent runs.

3. **Targets are computed outside the engine.** The alpha path is an input, so
   swapping the scheduler changes nothing else. That is what makes the
   comparison causal.

Timing convention (fix once, obey everywhere)::

    r[t]        return of bar t, i.e. close_{t-1} -> close_t
    w[t]        weights held *during* bar t, so they earn r[t]
    target[t]   target computed from information up to and including close_t
    decision    taken at close_t, filled at close_{t+exec_lag}

With the default exec_lag = 1, a decision taken at close_t is filled at
close_{t+1} and first earns r[t+2]. Nothing in the engine ever reads a price,
volume or alpha value dated later than the bar being processed.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .costs import CostModel


# ---------------------------------------------------------------- market data


@dataclass
class MarketData:
    """Everything the engine and the schedulers may look at.

    All fields are strictly backward-looking at each bar t.

    returns       : (S,T,N) simple returns per bar.
    z_returns     : (S,T,N) log returns standardised by trailing volatility,
                    the input to the price-CUSUM detector.
    dollar_volume : (S,T,N) traded notional per bar.
    adv           : (S,T,N) trailing average dollar volume (liquidity).
    vol           : (S,T,N) trailing per-bar volatility estimate (impact input).
    """

    returns: np.ndarray
    z_returns: np.ndarray
    dollar_volume: np.ndarray
    adv: np.ndarray
    vol: np.ndarray

    def __post_init__(self) -> None:
        shapes = {
            "returns": self.returns.shape,
            "z_returns": self.z_returns.shape,
            "dollar_volume": self.dollar_volume.shape,
            "adv": self.adv.shape,
            "vol": self.vol.shape,
        }
        if len(set(shapes.values())) != 1:
            raise ValueError(f"MarketData fields must share one shape, got {shapes}")
        if self.returns.ndim != 3:
            raise ValueError("MarketData arrays must be 3-D (paths, bars, assets)")

    @property
    def shape(self) -> tuple[int, int, int]:
        return self.returns.shape

    def slice_paths(self, idx: np.ndarray) -> "MarketData":
        return MarketData(
            returns=self.returns[idx],
            z_returns=self.z_returns[idx],
            dollar_volume=self.dollar_volume[idx],
            adv=self.adv[idx],
            vol=self.vol[idx],
        )


# ---------------------------------------------------------------- simulation


_RUIN_LEVEL = 1e-6        # NAV below this fraction of the start counts as ruin


def _clamp_gross(w: np.ndarray, max_gross: float) -> np.ndarray:
    """Scale any path whose gross exposure exceeds the sanity clamp."""
    gross = np.abs(w).sum(axis=-1)
    over = gross > max_gross
    if not over.any():
        return w
    scale = np.where(over, max_gross / np.maximum(gross, 1e-12), 1.0)
    return w * scale[..., None]


@dataclass
class SimConfig:
    """Execution and accounting conventions shared by every arm."""

    exec_lag: int = 1          # bars between decision and fill
    ann_factor: int = 252      # bars per year, for annualising
    aum: float = 10_000_000.0  # notional used for the impact term
    aum_mode: str = "fixed"    # 'fixed' keeps the cost regime identical across
                               # arms; 'nav' lets impact scale with performance
    store_weights: bool = False
    max_gross: float = 10.0    # sanity clamp, not a strategy constraint


@dataclass
class SimResult:
    """Per-path, per-bar output of one (alpha x scheduler) run."""

    name: str
    gross_returns: np.ndarray   # (S,T) return of the held book, before costs
    net_returns: np.ndarray     # (S,T) after fees, spread and impact
    turnover: np.ndarray        # (S,T) one-way L1 turnover, fraction of NAV
    cost: np.ndarray            # (S,T) cost, fraction of NAV
    trades: np.ndarray          # (S,T) bool, did the scheduler act
    nav: np.ndarray             # (S,T) net asset value, starts at 1.0
    weights: np.ndarray | None = None  # (S,T,N) if store_weights; weights[t]
                                       # is the book held FROM close t, so it
                                       # earns returns[t+1]. The book that
                                       # earned returns[t] is weights[t-1].
    meta: dict = field(default_factory=dict)

    @property
    def n_paths(self) -> int:
        return self.net_returns.shape[0]

    @property
    def n_bars(self) -> int:
        return self.net_returns.shape[1]


def simulate(
    market: MarketData,
    targets: np.ndarray,
    scheduler,
    cost_model: CostModel,
    cfg: SimConfig | None = None,
    name: str | None = None,
) -> SimResult:
    """Run one scheduler over a batch of paths.

    market    : MarketData with (S,T,N) arrays.
    targets   : (S,T,N) target weights known at close of each bar.
    scheduler : object exposing reset(S, N) and
                decide(t, w_now, target, market) -> (desired (S,N), mask (S,)).
    """
    cfg = cfg or SimConfig()
    S, T, N = market.shape
    if targets.shape != (S, T, N):
        raise ValueError(f"targets shape {targets.shape} != market shape {(S, T, N)}")
    if cfg.exec_lag < 0:
        raise ValueError("exec_lag must be >= 0")

    scheduler.reset(S, N)

    w = np.zeros((S, N))                    # weights held during the current bar
    nav = np.ones(S)
    ruined = np.zeros(S, dtype=bool)        # wiped out: no book, no more trading

    gross = np.zeros((S, T))
    net = np.zeros((S, T))
    turnover = np.zeros((S, T))
    cost_arr = np.zeros((S, T))
    traded = np.zeros((S, T), dtype=bool)
    nav_path = np.zeros((S, T))
    weights_path = np.zeros((S, T, N)) if cfg.store_weights else None

    # Orders decided at close_t are due at close_{t+exec_lag}. With the
    # default lag of 1 at most one order per path is ever in flight, because
    # the fill happens earlier in the same bar than the next decision; with a
    # longer lag several absolute-level orders can overlap, and the later one
    # simply supersedes the earlier at its own fill bar.
    pending: list[tuple[int, np.ndarray, np.ndarray]] = []

    for t in range(T):
        r_t = market.returns[:, t, :]
        was_ruined = ruined.copy()          # ruined before this bar began

        # --- 1. realise the return of bar t on the book held during bar t ----
        g_t = (w * r_t).sum(axis=1)
        gross[:, t] = g_t

        # --- 2. let the book drift with prices -------------------------------
        # A path that loses everything in a single bar has no book to drift.
        # Clamping the denominator instead would manufacture a position ~1/eps
        # times too large, and the turnover and cost measured against it would
        # be nonsense while the truncated return still looked sane.
        wiped = (1.0 + g_t) <= _RUIN_LEVEL
        denom = np.where(wiped, 1.0, 1.0 + g_t)
        w_drift = w * (1.0 + r_t) / denom[:, None]
        if wiped.any():
            w_drift = np.where(wiped[:, None], 0.0, w_drift)
            ruined |= wiped

        c_t = np.zeros(S)
        tn_t = np.zeros(S)
        notional = cfg.aum * nav if cfg.aum_mode == "nav" else cfg.aum

        # --- 3. fill orders that are due at this close -----------------------
        while pending and pending[0][0] == t:
            _, desired, mask = pending.pop(0)
            # An order placed before the path was wiped out must not fill:
            # otherwise a ruined path re-acquires a full-size book on a NAV of
            # zero and goes on reporting returns (and a Sharpe) forever.
            mask = mask & ~ruined
            if mask.any():
                dw = np.where(mask[:, None], desired - w_drift, 0.0)
                tn_t = tn_t + np.abs(dw).sum(axis=1)
                c_t = c_t + cost_model.trade_cost(
                    dw, notional, market.adv[:, t, :], market.vol[:, t, :]
                )
                w_drift = w_drift + dw
                traded[:, t] |= mask & (np.abs(dw).sum(axis=1) > 0)

        # --- 4. decide at close_t, on the book we actually hold --------------
        # Information used: prices, volumes and targets dated <= t. Never later.
        desired, mask = scheduler.decide(t, w_drift, targets[:, t, :], market)
        desired = _clamp_gross(desired, cfg.max_gross)
        if ruined.any():                    # a wiped-out path cannot trade
            mask = mask & ~ruined
        if cfg.exec_lag == 0:
            # Same-close fill: decide and trade on the same bar.
            if mask.any():
                dw = np.where(mask[:, None], desired - w_drift, 0.0)
                tn_t = tn_t + np.abs(dw).sum(axis=1)
                c_t = c_t + cost_model.trade_cost(
                    dw, notional, market.adv[:, t, :], market.vol[:, t, :]
                )
                w_drift = w_drift + dw
                traded[:, t] |= mask & (np.abs(dw).sum(axis=1) > 0)
        else:
            pending.append((t + cfg.exec_lag, desired, mask))

        turnover[:, t] = tn_t
        cost_arr[:, t] = c_t

        # --- 5. net return, NAV, and ruin ------------------------------------
        # A leveraged or short book that moves far enough against you is wiped
        # out. Without this the NAV goes through zero, the drift ratio flips
        # sign and the path silently produces nonsense. An unrebalanced
        # long/short book held for years does exactly that -- which is itself a
        # result worth reporting: some rebalancing is not optional.
        # Cost is a fraction of NAV at the fill and is subtracted from the
        # bar's return as is; the exact base would be c_t * (1 + g_t), a
        # second-order difference of order c x g (~1e-6 per bar).
        net[:, t] = np.maximum(g_t - c_t, -1.0)
        nav = nav * np.clip(1.0 + net[:, t], 0.0, None)
        newly_ruined = (nav <= _RUIN_LEVEL) & ~ruined
        ruined |= newly_ruined
        if ruined.any():
            nav = np.where(ruined, 0.0, nav)
            w_drift = np.where(ruined[:, None], 0.0, w_drift)
            # Ruin is absorbing: no book, no trades, and no further returns.
            # Leaving the post-ruin returns in place would let a dead path
            # contribute a Sharpe ratio computed on a NAV of zero.
            # Only paths ruined BEFORE this bar are zeroed: the bar that wipes a
            # path out keeps its -100% return, or the Sharpe would never see it.
            already = was_ruined
            if already.any():
                net[already, t] = 0.0
                gross[already, t] = 0.0
                turnover[already, t] = 0.0
                cost_arr[already, t] = 0.0
        nav_path[:, t] = nav

        w = w_drift
        if weights_path is not None:
            weights_path[:, t, :] = w

    return SimResult(
        name=name or getattr(scheduler, "name", "unnamed"),
        gross_returns=gross,
        net_returns=net,
        turnover=turnover,
        cost=cost_arr,
        trades=traded,
        nav=nav_path,
        weights=weights_path,
        meta={
            "scheduler": getattr(scheduler, "name", "unnamed"),
            "family": getattr(scheduler, "family", "unknown"),
            "knob": getattr(scheduler, "knob", None),
            "full_move": bool(getattr(scheduler, "moves_fully", True)),
            "trigger": getattr(scheduler, "trigger", "unknown"),
            "move_fraction": getattr(scheduler, "move_fraction", 1.0),
            "exec_lag": cfg.exec_lag,
            "ann_factor": cfg.ann_factor,
            "linear_bps": cost_model.linear_bps,
            "ruined_fraction": float(ruined.mean()),
        },
    )


def paper_portfolio(
    market: MarketData,
    targets: np.ndarray,
    cfg: SimConfig | None = None,
) -> SimResult:
    """The ceiling: hold the target exactly, every bar, at zero cost.

    It obeys the same execution lag as every other arm, so the gap between it
    and a scheduler is entirely attributable to *when and how far* that
    scheduler trades -- never to an unfair latency advantage.
    """
    from .schedulers import AlwaysTrade
    from .costs import CostModel as _CM

    return simulate(
        market,
        targets,
        AlwaysTrade(),
        _CM(fee_bps=0.0, half_spread_bps=0.0, enable_impact=False),
        cfg,
        name="Paper (no cost)",
    )
