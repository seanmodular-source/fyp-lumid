"""Alpha providers: turn a price panel into a target-weight path.

The architectural point of this module is separation. A provider answers "what
book do I want to hold at close_t?" and nothing else. Schedulers answer "when
do I move toward it, and how far?". Because the target path is computed once
and handed unchanged to every scheduler, any difference between arms is
attributable to the scheduler alone. Fusing the two - deciding the target and
deciding when to move toward it in the same function - makes timing, signal and
sizing move together, and nothing can then be attributed to any of them.

Two providers:

    ControlledAlpha : a signal with a *known* information coefficient, built by
                      blending future returns with noise, then calibrated so
                      the paper portfolio's gross Sharpe is exactly 1.0. It
                      uses look-ahead ON PURPOSE -- it is a laboratory
                      instrument for comparing schedulers on real prices, not a
                      tradable strategy, and is never used to claim profit.
    MomentumAlpha   : an honest, no-look-ahead cross-sectional signal. With
                      two assets (BTC, ETH) it reduces to the sign of the
                      BTC-minus-ETH trailing return.

Sizing (equal / inverse-vol / risk-parity) is applied here, on the alpha
scores, so it can be varied as its own axis rather than being tangled into the
rebalancing question.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .core import MarketData
from .portfolio import risk_parity_cov


# --------------------------------------------------------------- market data


def build_market(
    closes: pd.DataFrame,
    volumes: pd.DataFrame,
    vol_window: int = 20,
) -> MarketData:
    """Wrap a real price/volume panel in the same (1, T, N) container the
    synthetic lab uses, so one engine serves both.

    Every derived series is strictly backward-looking: the volatility estimate
    at bar t uses bars [t-window, t-1] and never bar t itself. Early bars use
    whatever history exists (min_periods); bars with no history at all get a
    fixed 2% daily volatility and their own day's dollar volume. Nothing is
    back-filled from later dates, and no position exists before the 60-bar
    sizing warm-up, so these defaults never reach a trade.
    """
    px = closes.astype(float)
    ret = px.pct_change().fillna(0.0)
    log_r = np.log1p(ret.clip(lower=-0.999999))

    default_vol = 0.02                     # only for bars with no history

    vol_prev = log_r.rolling(vol_window, min_periods=2).std().shift(1)
    vol_prev = vol_prev.replace(0.0, np.nan).fillna(default_vol)

    z = (log_r / vol_prev).fillna(0.0)
    z.iloc[:vol_window] = 0.0

    ret_vol_prev = ret.rolling(vol_window, min_periods=2).std().shift(1)
    ret_vol_prev = ret_vol_prev.replace(0.0, np.nan).fillna(default_vol)

    dollar_volume = (volumes.astype(float) * px).fillna(0.0)
    adv = dollar_volume.rolling(vol_window, min_periods=1).mean().shift(1)
    adv = adv.replace(0.0, np.nan).fillna(dollar_volume.replace(0.0, np.nan))
    adv = adv.fillna(1.0)

    def arr(df):
        return df.to_numpy(dtype=float)[None, :, :]

    return MarketData(
        returns=arr(ret),
        z_returns=arr(z),
        dollar_volume=arr(dollar_volume),
        adv=arr(adv),
        vol=arr(ret_vol_prev),
    )


# ------------------------------------------------------------------- sizing


def scores_to_targets(
    scores: np.ndarray,
    returns: np.ndarray,
    vol_target: float = 0.15,
    ann: int = 252,
    long_only: bool = False,
    max_gross: float = 2.0,
    cov_window: int = 60,
    sizing: str = "equal",
    warmup: int = 60,
    rp_cache: dict | None = None,
) -> np.ndarray:
    """Map (T,N) alpha scores to a (1,T,N) target-weight path.

    sizing:
        'equal'       weights proportional to the score itself
        'inv_vol'     score / trailing volatility (equal volatility budget)
        'risk_parity' equal risk contribution, respecting correlations

    The covariance used for both sizing and the volatility target is estimated
    on a trailing window ending at t-1, so no future information enters.
    """
    T, N = scores.shape
    w = np.zeros((T, N))
    ret = np.asarray(returns, float)

    for t in range(T):
        if t < warmup:
            continue
        s = scores[t]
        if not np.isfinite(s).all() or np.abs(s).sum() <= 1e-12:
            continue
        lo = max(0, t - cov_window)
        window = ret[lo:t]                       # strictly past
        if window.shape[0] < 5:
            continue
        cov = np.cov(window, rowvar=False)
        cov = np.atleast_2d(cov)
        if not np.isfinite(cov).all():
            continue
        vol = np.sqrt(np.maximum(np.diag(cov), 1e-24))

        if long_only:
            s = np.maximum(s, 0.0)
            if s.sum() <= 1e-12:
                continue

        if sizing == "equal":
            raw = s
        elif sizing == "inv_vol":
            raw = s / vol
        elif sizing == "risk_parity":
            active = np.abs(s) > 1e-12
            raw = np.zeros(N)
            if active.sum() == 1:
                raw[active] = np.sign(s[active])
            elif active.sum() > 1:
                # The equal-risk solution depends only on the covariance and
                # the active set, never on the scores' magnitudes, so it can be
                # reused across calibration passes over the same price history.
                key = (t, active.tobytes())
                sub = rp_cache.get(key) if rp_cache is not None else None
                if sub is None:
                    sub = risk_parity_cov(cov[np.ix_(active, active)])
                    if rp_cache is not None:
                        rp_cache[key] = sub
                raw[active] = np.sign(s[active]) * sub
        else:
            raise ValueError(f"unknown sizing '{sizing}'")

        gross = np.abs(raw).sum()
        if gross <= 1e-12:
            continue
        unit = raw / gross
        ex_ante = np.sqrt(max(unit @ cov @ unit, 1e-24) * ann)
        scaled = unit * (vol_target / max(ex_ante, 1e-12))
        g = np.abs(scaled).sum()
        if g > max_gross:
            scaled = scaled * (max_gross / g)
        w[t] = scaled

    return w[None, :, :]


# ---------------------------------------------------------------- providers


class AlphaProvider:
    """Interface: scores(closes, volumes) -> (T,N) array of alpha scores."""

    name = "alpha"
    uses_lookahead = False

    def scores(self, closes: pd.DataFrame, volumes: pd.DataFrame) -> np.ndarray:
        raise NotImplementedError

    def targets(self, closes, volumes, **kw) -> np.ndarray:
        s = self.scores(closes, volumes)
        ret = closes.pct_change().fillna(0.0).to_numpy(float)
        return scores_to_targets(s, ret, **kw)


@dataclass
class MomentumAlpha(AlphaProvider):
    """Cross-sectional momentum: trailing return, z-scored across assets.

    Deliberately simple and deliberately honest -- no look-ahead, no fitting,
    nothing to overfit. Holding the signal fixed and dull is what lets the
    scheduler comparison mean something.
    """

    lookback: int = 20
    long_only: bool = False
    name: str = "Momentum"
    uses_lookahead: bool = False

    def scores(self, closes: pd.DataFrame, volumes: pd.DataFrame) -> np.ndarray:
        px = closes.astype(float)
        mom = np.log(px).diff(self.lookback)
        if px.shape[1] > 1 and not self.long_only:
            mom = mom.sub(mom.mean(axis=1), axis=0)      # dollar-neutral tilt
        sd = mom.std(axis=1).replace(0.0, np.nan)
        z = mom.div(sd, axis=0) if px.shape[1] > 1 else mom
        return z.fillna(0.0).to_numpy(float)


@dataclass
class ControlledAlpha(AlphaProvider):
    """A signal with a known information coefficient.

    score_t = ic * z(forward return over `horizon`) + sqrt(1-ic^2) * noise

    **This provider reads future returns on purpose.** It is the real-price
    analogue of the synthetic lab: it fixes the quality of the alpha so that
    the only thing varying across arms is the scheduler. Results produced with
    it are statements about *execution*, never about profitability, and the
    notebook labels them as such everywhere they appear.
    """

    ic: float = 0.10
    horizon: int = 5
    seed: int = 42
    name: str = "ControlledAlpha"
    uses_lookahead: bool = True

    def scores(self, closes: pd.DataFrame, volumes: pd.DataFrame) -> np.ndarray:
        px = closes.astype(float)
        fwd = np.log(px).diff(self.horizon).shift(-self.horizon)
        sd = fwd.std(axis=0).replace(0.0, np.nan)
        zf = (fwd / sd).fillna(0.0).to_numpy(float)
        rng = np.random.default_rng(self.seed)
        noise = rng.standard_normal(zf.shape)
        ic = float(np.clip(self.ic, -0.999, 0.999))
        s = ic * zf + np.sqrt(1 - ic ** 2) * noise
        if px.shape[1] > 1:
            s = s - s.mean(axis=1, keepdims=True)
        return s


# ------------------------------------------------------------- calibration


def calibrate_controlled_alpha(
    closes: pd.DataFrame,
    volumes: pd.DataFrame,
    target_sharpe: float = 1.0,
    horizon: int = 5,
    seed: int = 42,
    ann: int = 252,
    sim_cfg=None,
    tol: float = 5e-3,
    max_iter: int = 30,
    rp_cache: dict | None = None,
    **target_kw,
):
    """Find the information coefficient that gives a paper Sharpe of
    `target_sharpe` on this particular price path.

    Returns (ic, targets). Paper Sharpe is close to proportional to ic, so a
    secant iteration converges in a few passes.
    """
    from .core import SimConfig, paper_portfolio
    from .evaluation import annualised_sharpe

    sim_cfg = sim_cfg or SimConfig(ann_factor=ann)
    market = build_market(closes, volumes)
    rp_cache = {} if rp_cache is None else rp_cache   # reused across passes

    def sharpe_for(ic: float):
        provider = ControlledAlpha(ic=ic, horizon=horizon, seed=seed)
        tgt = provider.targets(closes, volumes, ann=ann, rp_cache=rp_cache, **target_kw)
        res = paper_portfolio(market, tgt, sim_cfg)
        return float(annualised_sharpe(res.net_returns, ann)[0]), tgt

    # Secant iteration: the paper Sharpe is close to proportional to the
    # information coefficient, so this lands in a handful of passes where
    # bisection needs thirty -- and each pass rebuilds a full target path.
    ic0 = 0.10
    s0, t0 = sharpe_for(ic0)
    if s0 <= 0:
        return ic0, t0
    ic1 = float(np.clip(ic0 * target_sharpe / s0, 1e-3, 0.95))
    s1, t1 = sharpe_for(ic1)
    best = (ic1, t1)
    for _ in range(max_iter):
        if abs(s1 - target_sharpe) < tol:
            return best
        denom = s1 - s0
        if abs(denom) < 1e-12:
            break
        ic2 = float(np.clip(ic1 + (target_sharpe - s1) * (ic1 - ic0) / denom, 1e-3, 0.95))
        if abs(ic2 - ic1) < 1e-5:
            break
        ic0, s0 = ic1, s1
        s1, t1 = sharpe_for(ic2)
        ic1, best = ic2, (ic2, t1)
    return best
