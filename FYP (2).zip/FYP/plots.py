"""Figures. Every chart here is built to answer one question at a glance.

House rules (applied consistently so the deck reads as one system):
  * one y-axis per chart -- never two scales in one frame; two measures become
    two panels;
  * categorical hues assigned in a fixed slot order, never cycled, so a family
    keeps its colour across every figure in the notebook;
  * diverging blue<->red with a neutral grey midpoint for signed quantities,
    a single-hue blue ramp for magnitudes, and reserved status colours for
    pass/fail only;
  * recessive grid and axes, direct labels on the series that matter, and the
    underlying table printed next to the chart so nothing depends on colour
    alone.
"""
from __future__ import annotations

import numpy as np

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ---------------------------------------------------------------- palette

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300",
          "#4a3aa7", "#e34948"]
INK = "#0b0b0b"
INK_2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
SURFACE = "#fcfcfb"
GOOD = "#0ca30c"
CRITICAL = "#d03b3b"
WARNING = "#fab219"

# Families keep the same colour in every figure.
FAMILY_COLOR = {
    "clock": SERIES[0],
    "activity": SERIES[1],
    "price-event": SERIES[2],
    "target-event": SERIES[3],
    "state-feedback": SERIES[5],
    "control": MUTED,
}
FAMILY_MARKER = {
    "clock": "o",
    "activity": "s",
    "price-event": "^",
    "target-event": "D",
    "state-feedback": "P",
    "control": "x",
}

SEQ_BLUE = LinearSegmentedColormap.from_list(
    "seq_blue", ["#cde2fb", "#86b6ef", "#3987e5", "#256abf", "#104281"]
)
# Diverging scale for signed quantities. Every signed quantity in this study is
# an *advantage*, so the poles are oriented to that meaning: blue above zero,
# red below, neutral grey at zero. Orienting the ramp to the reading rather than
# to the number line is what keeps "red" from silently meaning "good".
DIVERGING = LinearSegmentedColormap.from_list(
    "div_advantage", ["#d03b3b", "#ec835a", "#f0efec", "#86b6ef", "#184f95"]
)


def use_style() -> None:
    """Apply the house style to every subsequent figure."""
    mpl.rcParams.update({
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "font.family": ["Segoe UI", "DejaVu Sans", "sans-serif"],
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.titleweight": "semibold",
        "axes.titlecolor": INK,
        "axes.labelcolor": INK_2,
        "axes.labelsize": 10,
        "axes.edgecolor": AXIS,
        "axes.linewidth": 0.8,
        "axes.grid": True,
        "axes.axisbelow": True,
        "grid.color": GRID,
        "grid.linewidth": 0.8,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "xtick.labelcolor": INK_2,
        "ytick.labelcolor": INK_2,
        "legend.frameon": False,
        "legend.fontsize": 9,
        "lines.linewidth": 2.0,
        "figure.dpi": 110,
    })


def _despine(ax):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    return ax


def _plain_log(ax, axis: str = "x") -> None:
    """Label a log axis with plain numbers (0.1, 1, 10) instead of 10^-1."""
    fmt = mpl.ticker.FuncFormatter(lambda v, _: f"{v:g}")
    target = ax.xaxis if axis == "x" else ax.yaxis
    target.set_major_formatter(fmt)


def _signed(v: float, digits: int = 2) -> str:
    """A signed number that never prints as -0.00."""
    r = round(float(v), digits) + 0.0
    return f"{r:+.{digits}f}"


# Plain-language names for the rule families, used in legends.
FAMILY_LABEL = {
    "clock": "Calendar (every k days)",
    "activity": "Volume clock",
    "price-event": "Price-move trigger",
    "target-event": "Target-move trigger",
    "state-feedback": "Feedback: band / part-way moves",
    "control": "Controls (random timing, buy-and-hold)",
}


def _caption(fig, text: str) -> None:
    """One line under the chart stating what the reader should take away."""
    fig.text(0.01, -0.02, text, ha="left", va="top", fontsize=9, color=INK_2, wrap=True)


# ------------------------------------------------------------- phase 1/2


def fig_frontier(selected: dict, paper_sharpe: float, title: str,
                 caption: str = "", annotate: bool = False):
    """Net Sharpe vs turnover, one line per scheduler family.

    The headline chart: a family that sits above another *at every turnover
    level* is better for any trading budget, which is a far stronger claim than
    winning at one hand-picked rebalance frequency.
    """
    fig, ax = plt.subplots(figsize=(10, 5.6), constrained_layout=True)
    ax.axhline(paper_sharpe, color=INK, lw=1.2, ls=(0, (4, 3)), zorder=1)

    ends = []
    for family, rows in selected.items():
        # A rule that never trades has no place on a turnover axis (and no
        # logarithm). It stays in the tables, where "the best available rule at
        # this budget does nothing" is a meaningful row.
        rows = [r for r in rows if r["Turnover/yr"] > 1e-9]
        if not rows:
            continue
        rows = sorted(rows, key=lambda r: r["Turnover/yr"])
        x = [r["Turnover/yr"] for r in rows]
        y = [r["Net Sharpe"] for r in rows]
        color = FAMILY_COLOR.get(family, MUTED)
        ax.plot(x, y, marker=FAMILY_MARKER.get(family, "o"), markersize=7,
                color=color, label=FAMILY_LABEL.get(family, family),
                markeredgecolor=SURFACE, markeredgewidth=1.2, zorder=3)
        if x:
            ends.append([y[-1], x[-1], family, color])

    ax.set_xscale("log")
    _plain_log(ax)
    ax.margins(x=0.22)

    if annotate and ends:
        # Label ladder: families whose curves end close together would otherwise
        # print on top of each other, so nudge each label up to a minimum gap.
        span = max(e[0] for e in ends) - min(e[0] for e in ends)
        gap = max(span * 0.07, 0.02)
        ends.sort(key=lambda e: e[0])
        placed = -np.inf
        for y_end, x_end, family, color in ends:
            y_label = max(y_end, placed + gap)
            ax.annotate(family, (x_end, y_label), textcoords="offset points",
                        xytext=(9, 0), fontsize=9, color=color, va="center",
                        annotation_clip=False)
            placed = y_label

    ax.annotate(f"best possible (trading free): {paper_sharpe:.2f}",
                (ax.get_xlim()[0], paper_sharpe), textcoords="offset points",
                xytext=(6, 4), va="bottom", ha="left", fontsize=9, color=INK)
    ax.set_xlabel("Annual one-way turnover (x NAV, log scale)")
    ax.set_ylabel("Net Sharpe ratio")
    ax.set_title(title)
    ax.legend(title="Rule family", loc="lower right", ncols=1, fontsize=9)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def fig_decomposition(rows: list[dict], title: str, caption: str = ""):
    """Where each scheduler's Sharpe went: net + cost drag + tracking loss.

    The three segments sum to the paper portfolio's Sharpe by construction, so
    the chart is a budget, not a ranking: every arm spends the same ceiling on
    some mix of staleness and trading cost.
    """
    rows = sorted(rows, key=lambda r: r["Net Sharpe"])
    names = [r["Scheduler"] for r in rows]
    net = np.array([r["Net Sharpe"] for r in rows])
    cost = np.array([r["Cost drag"] for r in rows])
    track = np.array([r["Tracking loss"] for r in rows])
    y = np.arange(len(rows))

    fig, ax = plt.subplots(figsize=(10, 0.46 * len(rows) + 2.2), constrained_layout=True)
    ax.barh(y, net, color=SERIES[0], height=0.62, label="Net Sharpe (kept)")
    ax.barh(y, cost, left=net, color=SERIES[1], height=0.62, label="Cost drag (paid)")
    ax.barh(y, track, left=net + cost, color=AXIS, height=0.62,
            label="Tracking loss (staleness)")
    for i, r in enumerate(rows):
        ax.text(net[i] / 2, i, f"{net[i]:.2f}", va="center", ha="center",
                fontsize=9, color="white", fontweight="semibold")
    ax.set_yticks(y, names, fontsize=9)
    ax.set_xlabel("Sharpe ratio")
    ax.set_title(title)
    # Reserve an empty strip below the last bar so the legend never lands on
    # top of the data.
    ax.set_ylim(-1.45, len(rows) - 0.4)
    ax.legend(loc="lower center", ncols=3)
    ax.grid(axis="y", visible=False)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def fig_forest(diffs: list, title: str, caption: str = "",
               xlabel: str = "Difference in profit after costs (Sharpe ratio), 95% interval"):
    """Effect sizes with confidence intervals -- significant ones marked.

    A forest plot rather than a bar chart because the interval, not the point,
    is the finding.
    """
    labels = [d.label for d in diffs]
    mids = np.array([d.mean for d in diffs])
    los = np.array([d.lo for d in diffs])
    his = np.array([d.hi for d in diffs])
    y = np.arange(len(diffs))[::-1]

    fig, ax = plt.subplots(figsize=(10, 0.44 * len(diffs) + 2.2), constrained_layout=True)
    ax.axvline(0.0, color=INK, lw=1.0, zorder=1)
    for i, d in enumerate(diffs):
        color = GOOD if (d.lo > 0) else (CRITICAL if d.hi < 0 else MUTED)
        ax.plot([los[i], his[i]], [y[i], y[i]], color=color, lw=2.4,
                solid_capstyle="round", zorder=2)
        ax.plot([mids[i]], [y[i]], marker="o", markersize=8, color=color,
                markeredgecolor=SURFACE, markeredgewidth=1.2, zorder=3)
        tag = "significant" if (d.lo > 0 or d.hi < 0) else "n.s."
        ax.annotate(f"{mids[i]:+.3f}  ({tag})", (his[i], y[i]),
                    textcoords="offset points", xytext=(8, 0),
                    fontsize=9, color=INK_2, va="center")
    ax.set_yticks(y, labels, fontsize=9)
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    ax.grid(axis="y", visible=False)
    pad = 0.35 * (his.max() - los.min() + 1e-9)
    ax.set_xlim(los.min() - pad * 0.2, his.max() + pad)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


# --------------------------------------------------------------- phase 3


def fig_execution(curve, title: str, caption: str = ""):
    """Cost and timing risk, side by side -- never on one pair of axes.

    Two panels because they are two different measures: bps of shortfall and
    bps of dispersion. Sharing an axis would imply a comparability that does
    not exist.
    """
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), constrained_layout=True)
    algos = list(dict.fromkeys(curve["algo"]))
    for i, algo in enumerate(algos):
        g = curve[curve["algo"] == algo].sort_values("participation")
        color = SERIES[i % len(SERIES)]
        x = g["participation"] * 100
        axes[0].plot(x, g["is_bps_mean"], marker="o", markersize=6, color=color,
                     label=g["label"].iloc[0], markeredgecolor=SURFACE)
        axes[1].plot(x, g["is_bps_std"], marker="o", markersize=6, color=color,
                     markeredgecolor=SURFACE)
    axes[0].set_title("Cost: implementation shortfall")
    axes[0].set_ylabel("bps vs arrival price")
    axes[1].set_title("Risk: dispersion of the shortfall")
    axes[1].set_ylabel("bps, standard deviation")
    for ax in axes:
        ax.set_xscale("log")
        _plain_log(ax)
        ax.set_xlabel("Order size (% of average daily volume)")
        _despine(ax)
    axes[0].legend(loc="upper left", fontsize=8)
    fig.suptitle(title, fontsize=12, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


# --------------------------------------------------------------- phase 4


def fig_power(df, title: str, caption: str = ""):
    """What is on the table vs what can be seen: prize against resolution."""
    labels = df["Regime"].tolist()
    prize = df["Effect available"].to_numpy(float)
    mde = df["Min detectable delta"].to_numpy(float)
    y = np.arange(len(labels))[::-1]
    h = 0.36

    fig, ax = plt.subplots(figsize=(10, 0.55 * len(labels) + 2.4), constrained_layout=True)
    ax.barh(y + h / 2 + 0.02, prize, height=h, color=SERIES[0],
            label="Effect available (Sharpe per year)")
    ax.barh(y - h / 2 - 0.02, mde, height=h, color=SERIES[1],
            label="Resolution: smallest detectable difference")
    for i in range(len(labels)):
        verdict = "detectable" if prize[i] > mde[i] else "invisible"
        color = GOOD if prize[i] > mde[i] else CRITICAL
        ax.annotate(verdict, (max(prize[i], mde[i]), y[i]),
                    textcoords="offset points", xytext=(8, 0),
                    fontsize=9, color=color, va="center", fontweight="semibold")
    ax.set_yticks(y, labels, fontsize=9)
    ax.set_xlabel("Sharpe points")
    ax.set_title(title)
    ax.legend(loc="lower right")
    ax.grid(axis="y", visible=False)
    ax.set_xlim(0, max(prize.max(), mde.max()) * 1.45)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


# --------------------------------------------------------------- phase 6


def fig_heatmap(pivot, title: str, cbar_label: str, caption: str = "",
                diverging: bool = True, fmt: str = "{:+.2f}", sig=None,
                row_fmt=None, col_fmt=None, xlabel: str | None = None,
                ylabel: str | None = None):
    """Regime map: where does the closed-loop advantage live?"""
    data = pivot.to_numpy(float)
    vmax = np.nanmax(np.abs(data)) if diverging else np.nanmax(data)
    kw = dict(cmap=DIVERGING, vmin=-vmax, vmax=vmax) if diverging else dict(
        cmap=SEQ_BLUE, vmin=0, vmax=vmax)

    fig, ax = plt.subplots(figsize=(1.15 * data.shape[1] + 4.2,
                                    0.72 * data.shape[0] + 2.6),
                           constrained_layout=True)
    im = ax.imshow(data, aspect="auto", **kw)
    cols = [col_fmt(c) if col_fmt else str(c) for c in pivot.columns]
    rows = [row_fmt(i) if row_fmt else str(i) for i in pivot.index]
    ax.set_xticks(range(data.shape[1]), cols, fontsize=9)
    ax.set_yticks(range(data.shape[0]), rows, fontsize=9)
    ax.set_xlabel(xlabel if xlabel is not None else (pivot.columns.name or ""))
    ax.set_ylabel(ylabel if ylabel is not None else (pivot.index.name or ""))
    sig_arr = None if sig is None else sig.reindex(index=pivot.index,
                                                   columns=pivot.columns).to_numpy()
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            v = data[i, j]
            if np.isnan(v):
                continue
            shade = abs(v) / (vmax + 1e-12)
            txt = _signed(v) if fmt == "{:+.2f}" else fmt.format(v)
            if sig_arr is not None and not bool(sig_arr[i, j]):
                txt += "\nn.s."
            ax.text(j, i, txt, ha="center", va="center", fontsize=9,
                    color="white" if shade > 0.55 else INK)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label(cbar_label, color=INK_2)
    cb.outline.set_visible(False)
    ax.set_title(title)
    if caption:
        _caption(fig, caption)
    return fig


# Mechanism series keep the colour of the family they measure.
MECHANISM_COLOR = {
    "Price CUSUM": FAMILY_COLOR["price-event"],
    "Target CUSUM": FAMILY_COLOR["target-event"],
    "All closed-loop": FAMILY_COLOR["state-feedback"],
    "Timing only": MUTED,
}


def fig_mechanism(x, series: dict, title: str, xlabel: str, ylabel: str,
                  caption: str = "", colors: dict | None = None):
    """Does the advantage move the way the theory says it should?"""
    colors = {**MECHANISM_COLOR, **(colors or {})}
    fig, ax = plt.subplots(figsize=(9.5, 5.0), constrained_layout=True)
    ax.axhline(0.0, color=INK, lw=1.0)
    ends = []
    for i, (label, ys) in enumerate(series.items()):
        color = colors.get(label, SERIES[i % len(SERIES)])
        ax.plot(x, ys, marker="o", markersize=7, color=color, label=label,
                markeredgecolor=SURFACE, markeredgewidth=1.2)
        ends.append([float(ys[-1]), label, color])
    # Label ladder, as in the frontier: end labels that would collide are
    # nudged apart to a minimum gap.
    span = max(e[0] for e in ends) - min(e[0] for e in ends)
    gap = max(span * 0.08, 0.012)
    placed = -np.inf
    for y_end, label, color in sorted(ends, key=lambda e: e[0]):
        y_label = max(y_end, placed + gap)
        ax.annotate(label, (x[-1], y_label), textcoords="offset points",
                    xytext=(8, 0), fontsize=9, color=color, va="center",
                    annotation_clip=False)
        placed = y_label
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(loc="best")
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


# --------------------------------------------------------------- phase 5/7


def fig_nav(navs: dict, title: str, caption: str = "", logy: bool = True,
            highlight: str | None = None, index=None):
    """Equity curves. The highlighted arm is the one the argument is about."""
    fig, ax = plt.subplots(figsize=(10, 5.2), constrained_layout=True)
    for i, (label, nav) in enumerate(navs.items()):
        nav = np.asarray(nav, float)
        x = index if index is not None else np.arange(len(nav))
        is_focus = (label == highlight)
        # Every series keeps its own hue; the one the argument is about is drawn
        # heavier and on top rather than being the only coloured line.
        ax.plot(x, nav, color=SERIES[i % len(SERIES)],
                lw=2.6 if is_focus else 1.4,
                alpha=1.0 if (is_focus or highlight is None) else 0.8,
                label=label + ("  (ours)" if is_focus else ""),
                zorder=4 if is_focus else 2)
    if logy:
        ax.set_yscale("log")
    ax.set_ylabel("Growth of 1 unit (log scale)" if logy else "Growth of 1 unit")
    ax.set_xlabel("")
    ax.set_title(title)
    ax.legend(loc="upper left", ncols=2)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def fig_placebo(dist, observed: float, title: str, caption: str = ""):
    """Is the detector detecting anything? The null distribution decides."""
    dist = np.asarray(dist, float)
    fig, ax = plt.subplots(figsize=(9.5, 4.8), constrained_layout=True)
    ax.hist(dist, bins=28, color=AXIS, edgecolor=SURFACE, linewidth=1.0,
            label="random-timing placebo")
    pct = float((dist < observed).mean() * 100)
    ax.axvline(observed, color=SERIES[5], lw=2.4,
               label=f"our rule = {observed:.3f} ({pct:.0f}th pct)")
    ax.set_xlabel("Net Sharpe")
    ax.set_ylabel("Number of placebo draws")
    ax.set_title(title)
    ax.legend(loc="upper left")
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def fig_benchmarks(rows: list[dict], title: str, caption: str = "",
                   xlabel: str = "Net Sharpe ratio",
                   extra_label: str = "x/yr turnover"):
    """Head-to-head against the benchmarks, with the price paid for each result
    annotated beside it. `xlabel` and `extra_label` are explicit because this
    chart is reused for levels (net Sharpe, turnover) and for differences
    (delta Sharpe, turnover saved), and a mislabelled axis is worse than no
    chart at all."""
    rows = sorted(rows, key=lambda r: r["Net Sharpe"])
    names = [r["Label"] for r in rows]
    vals = np.array([r["Net Sharpe"] for r in rows])
    turn = np.array([r["Turnover/yr"] for r in rows])
    focus = [r.get("Focus", False) for r in rows]
    y = np.arange(len(rows))

    fig, ax = plt.subplots(figsize=(10, 0.5 * len(rows) + 2.4), constrained_layout=True)
    fams = [r.get("Family", "") for r in rows]

    def _bar_color(is_focus: bool, label: str, fam: str) -> str:
        low = label.lower()
        if is_focus:
            return FAMILY_COLOR["state-feedback"]   # the rule the argument is about
        if "ceiling" in low:
            return "#86b6ef"                     # unreachable, not a competitor
        if "placebo" in low or "hold" in low:
            return MUTED                         # controls
        return FAMILY_COLOR.get(fam, SERIES[0])  # each family keeps its colour

    colors = [_bar_color(f, n, fa) for f, n, fa in zip(focus, names, fams)]
    ax.barh(y, vals, color=colors, height=0.62)
    for i in range(len(rows)):
        extra = "" if np.isnan(turn[i]) else f"   {turn[i]:.0f} {extra_label}"
        ax.annotate(f"{vals[i]:.2f}{extra}",
                    (vals[i], y[i]), textcoords="offset points", xytext=(8, 0),
                    fontsize=9, color=INK_2, va="center")
    ax.set_yticks(y, names, fontsize=9)
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    ax.set_xlim(min(0, vals.min() * 1.15), vals.max() * 1.45)
    ax.grid(axis="y", visible=False)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


# ------------------------------------------------------------ bottom line
# Four charts for a reader who is not a quant. Each answers one question in
# its title, says which direction is better on its axis, and puts the number
# on the bar so nothing has to be read off a gridline. Our rule keeps the
# state-feedback colour it has everywhere else; every benchmark is a clock
# rule and keeps the clock colour.

OURS_COLOR = FAMILY_COLOR["state-feedback"]
BENCH_COLOR = FAMILY_COLOR["clock"]


def fig_scorecard(scorecard, headline: dict, title: str, caption: str = ""):
    """Our rule against the benchmark and the calendars, on three measures.

    Three panels rather than one chart with three axes: profit, trading and
    worst fall are different units and must never share a scale.
    """
    rows = scorecard.to_dict("records")
    names = [r["Rule"] for r in rows]
    colors = [OURS_COLOR if r["Ours"] else BENCH_COLOR for r in rows]
    y = np.arange(len(rows))[::-1]
    panels = [
        ("Profit after costs (net Sharpe)", "Profit after costs\n(Sharpe ratio, higher is better)", "{:.2f}"),
        ("Trading per year (x NAV)", "How much you trade\n(x portfolio value per year, lower is cheaper)", "{:.0f}x"),
        ("Worst fall (max drawdown)", "Worst fall from a peak\n(closer to zero is safer)", "{:.0%}"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(13, 0.62 * len(rows) + 2.6),
                             sharey=True, constrained_layout=True)
    for ax, (col, label, fmt) in zip(axes, panels):
        vals = np.array([r[col] for r in rows], float)
        ax.barh(y, vals, color=colors, height=0.6)
        for yi, v in zip(y, vals):
            ax.annotate(fmt.format(v), (v, yi), textcoords="offset points",
                        xytext=(-6 if v < 0 else 6, 0), ha="right" if v < 0 else "left",
                        va="center", fontsize=10, color=INK, fontweight="semibold")
        lo, hi = min(0.0, vals.min()), max(0.0, vals.max())
        span = hi - lo
        ax.set_xlim(lo - (0.3 * span if lo < 0 else 0), hi + 0.3 * span)
        ax.set_xlabel(label)
        ax.grid(axis="y", visible=False)
        ax.axvline(0, color=AXIS, lw=0.8)
        _despine(ax)
    axes[2].xaxis.set_major_formatter(mpl.ticker.PercentFormatter(1.0, decimals=0))
    paper = headline["Paper Sharpe (free trading)"]
    axes[0].axvline(paper, color=INK, lw=1.1, ls=(0, (4, 3)))
    axes[0].annotate("best possible\n(free trading)", (paper, y.max() + 0.45),
                     ha="center", va="bottom", fontsize=8, color=INK_2,
                     annotation_clip=False)
    axes[0].set_yticks(y, names, fontsize=10)
    for lbl, r in zip(axes[0].get_yticklabels(), rows):
        if r["Ours"]:
            lbl.set_fontweight("bold")
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_budget_bars(group, title: str, caption: str = ""):
    """At each trading budget: the best clock rule against the best of ours.

    Paired bars, one pair per budget, with the paired difference and its 95%
    interval written above each pair. A budget is dropped only when both of
    its picks repeat another budget's; the same feedback rule can appear twice
    when it is compared with two different calendars.
    """
    g = group.drop_duplicates(subset=["Closed-loop pick", "Open-loop pick"]).reset_index(drop=True)
    x = np.arange(len(g))
    w = 0.36
    fig, ax = plt.subplots(figsize=(11, 5.4), constrained_layout=True)
    ax.bar(x - w / 2, g["Open Sharpe"], w, color=BENCH_COLOR, label="Best calendar rule")
    ax.bar(x + w / 2, g["Closed Sharpe"], w, color=OURS_COLOR, label="Best feedback rule (ours)")
    top = max(g["Open Sharpe"].max(), g["Closed Sharpe"].max())
    for i, r in g.iterrows():
        ax.annotate(f"{r['Open Sharpe']:.2f}", (i - w / 2, r["Open Sharpe"]),
                    textcoords="offset points", xytext=(0, 4), ha="center", fontsize=9, color=INK_2)
        ax.annotate(f"{r['Closed Sharpe']:.2f}", (i + w / 2, r["Closed Sharpe"]),
                    textcoords="offset points", xytext=(0, 4), ha="center", fontsize=9, color=INK_2)
        ax.annotate(f"{r['Delta Sharpe']:+.2f}\n(95% CI {r['95% lo']:+.2f} to {r['95% hi']:+.2f})",
                    (i, top * 1.12), ha="center", va="bottom", fontsize=9,
                    color=INK, fontweight="semibold")
    ax.set_xticks(x, [f"up to {b:g}x / yr" for b in g["Budget"]])
    ax.set_xlabel("Trading budget (how much each rule is allowed to trade per year)")
    ax.set_ylabel("Profit after costs (Sharpe ratio)")
    ax.set_ylim(0, top * 1.4)
    ax.set_title(title)
    ax.legend(loc="upper left")
    ax.grid(axis="x", visible=False)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def fig_real_growth(real: dict, title: str, caption: str = ""):
    """Growth of $1 on real BTC/ETH, out-of-sample half only, one panel per
    alpha. Our rule is drawn heavier and on top; the benchmarks keep the clock
    colour, the calendar dashed so the two clocks stay distinguishable without
    a new hue."""
    alphas = list(real)
    fig, axes = plt.subplots(1, len(alphas), figsize=(6.4 * len(alphas), 4.8),
                             constrained_layout=True, squeeze=False)
    for ax, alpha in zip(axes[0], alphas):
        d = real[alpha]
        idx = d["_index"]
        ends = []
        for label, nav in d.items():
            if label.startswith("_"):
                continue
            ours = label.startswith("Our rule")
            dashed = "calendar" in label.lower()
            ax.plot(idx, nav, color=OURS_COLOR if ours else BENCH_COLOR,
                    lw=2.6 if ours else 1.6, ls=(0, (5, 3)) if dashed else "-",
                    zorder=4 if ours else 2, label=label)
            ends.append((float(nav[-1]), ours))
        # End labels, nudged apart when two lines finish close together. The
        # gap is a share of the axis height, so labels never print on top of
        # each other whatever the scale.
        lo_y, hi_y = ax.get_ylim()
        gap = 0.045 * (hi_y - lo_y)
        placed = -np.inf
        for y_end, ours in sorted(ends):
            y_lab = max(y_end, placed + gap)
            ax.annotate(f"${y_end:.2f}", (idx[-1], y_lab), textcoords="offset points",
                        xytext=(6, 0), va="center", fontsize=9, color=INK,
                        fontweight="semibold" if ours else "normal",
                        annotation_clip=False)
            placed = y_lab
        ax.axhline(1.0, color=AXIS, lw=0.9)
        ax.set_title(f"Signal: {alpha}", fontsize=11)
        ax.set_ylabel("Value of $1 invested")
        # Every panel gets its own legend (its Sharpes live there), placed
        # below the axes so it never covers a line.
        ax.legend(loc="upper left", bbox_to_anchor=(0.0, -0.12), fontsize=8.5, frameon=False)
        _despine(ax)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_gain_split(attribution, title: str, caption: str = ""):
    """Where our gain over the benchmark comes from: picking the moment (WHEN)
    vs pacing the trade (HOW FAR each day).

    Horizontal bars with 95% whiskers, plain-language labels. This is the
    honest qualifier on the recommendation, so it gets the same visual weight
    as the charts that make the case.
    """
    labels = ["Picking the moment\n(WHEN to trade)", "Pacing the trade\n(HOW FAR to move each day)",
              "Total gain over the benchmark"]
    a = attribution.reset_index(drop=True)
    vals = a["Delta Sharpe"].to_numpy(float)
    lo, hi = a["95% lo"].to_numpy(float), a["95% hi"].to_numpy(float)
    y = np.arange(len(a))[::-1]
    colors = [MUTED, OURS_COLOR, OURS_COLOR]
    fig, ax = plt.subplots(figsize=(10, 3.8), constrained_layout=True)
    ax.barh(y, vals, color=colors[:len(a)], height=0.55)
    ax.errorbar(vals, y, xerr=[vals - lo, hi - vals], fmt="none", ecolor=INK,
                elinewidth=1.2, capsize=4)
    for i, (yi, v, h) in enumerate(zip(y, vals, hi)):
        share = ("" if i == len(a) - 1 or abs(vals[-1]) < 1e-12
                 else f"  ({100 * v / vals[-1]:.0f}% of the gain)")
        ax.annotate(f"{v:+.3f} Sharpe{share}", (h, yi), textcoords="offset points",
                    xytext=(8, 0), va="center", fontsize=10, color=INK)
    ax.set_yticks(y, labels[:len(a)], fontsize=10)
    ax.axvline(0, color=INK, lw=0.9)
    ax.set_xlim(min(0, lo.min()) - 0.005, hi.max() * 1.9)
    ax.set_xlabel("Extra profit after costs vs. the benchmark (Sharpe ratio), with 95% interval")
    ax.set_title(title)
    ax.grid(axis="y", visible=False)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


# ------------------------------------------------------- report analytics

# Group colours follow the family slots used everywhere else; the one new
# group (a feedback trigger that moves all the way) takes the next unused slot.
TRADEOFF_COLOR = {
    "Calendar (clock)": FAMILY_COLOR["clock"],
    "Volume clock": FAMILY_COLOR["activity"],
    "Price-move trigger": FAMILY_COLOR["price-event"],
    "Target-move trigger": FAMILY_COLOR["target-event"],
    "Band trigger, full move": SERIES[4],
    "Band, move part way": SERIES[6],
    "Partial adjustment": FAMILY_COLOR["state-feedback"],
}


def fig_example_path(ex: dict, labels: dict, title: str, caption: str = "",
                     highlight: str | None = None):
    """What each rule actually does: the target weight (grey) against the
    weight the rule holds, one asset, one held-out path. Small multiples on a
    shared y-axis, so the four rules are compared on the same scale."""
    names = [k for k in ex if k not in ("bar", "Target")]
    ncol = 2
    nrow = int(np.ceil(len(names) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(12, 3.0 * nrow + 1.2),
                             sharex=True, sharey=True, constrained_layout=True,
                             squeeze=False)
    x = ex["bar"]
    for ax, name in zip(axes.flat, names):
        d = ex[name]
        color = OURS_COLOR if name == highlight else BENCH_COLOR
        ax.plot(x, ex["Target"], color=MUTED, lw=1.4, label="Target (what the signal wants)")
        ax.step(x, d["held"], where="post", color=color, lw=2.2,
                label="What the rule holds")
        ax.set_title(f"{labels.get(name, name)}\n"
                     f"trades {d['turnover_yr']:.0f}x/yr  |  average gap to target "
                     f"{d['gap']:.3f}", fontsize=10, loc="left")
        ax.axhline(0, color=AXIS, lw=0.8)
        _despine(ax)
    for ax in axes.flat[len(names):]:
        ax.axis("off")
    for ax in axes[-1]:
        ax.set_xlabel("Trading day")
    for ax in axes[:, 0]:
        ax.set_ylabel("Portfolio weight, one asset")
    axes.flat[0].legend(loc="upper left", fontsize=8.5)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_tradeoff(table, title: str, caption: str = ""):
    """Why moving part of the way wins. Left: Sharpe lost to holding a stale
    book. Right: Sharpe lost to trading costs. Both against turnover, one line
    per group. Two panels, never one chart with two scales."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2), sharex=True,
                             constrained_layout=True)
    panels = [("Tracking loss", "Lost to holding a stale book\n(Sharpe, lower is better)"),
              ("Cost drag", "Lost to trading costs\n(Sharpe, lower is better)")]
    for ax, (col, label) in zip(axes, panels):
        for group, color in TRADEOFF_COLOR.items():
            g = table[table["Group"] == group].sort_values("Turnover/yr")
            if g.empty:
                continue
            ours = group == "Partial adjustment"
            ax.plot(g["Turnover/yr"], g[col], color=color, lw=2.6 if ours else 1.6,
                    marker="o", markersize=5 if not ours else 6,
                    markeredgecolor=SURFACE, markeredgewidth=1.0,
                    zorder=4 if ours else 2, label=group)
        ax.set_xscale("log")
        _plain_log(ax)
        ax.set_xlabel("How much the rule trades (x portfolio value per year, log scale)")
        ax.set_ylabel(label)
        ax.set_ylim(bottom=0)
        _despine(ax)
    axes[0].legend(loc="lower left", fontsize=8.5)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_robustness(rob: dict, title: str, caption: str = ""):
    """Net Sharpe across every setting of the recommended rule, against the
    trade-every-change benchmark (dashed). Simulated panel: filled markers
    where the paired 95% interval against the benchmark excludes zero.
    Real panels: out-of-sample half; the ringed point is the setting picked
    on the first half."""
    panels = [("Simulated market (held-out paths)", rob["lab"], "Net Sharpe",
               rob["lab_benchmark"], rob["lab_picked"])]
    for alpha, t in rob["real"].items():
        panels.append((f"Real BTC/ETH, {alpha}\n(2021-24, out of sample)", t, "OOS Sharpe",
                       t.attrs["benchmark"], t.attrs["picked"]))
    fig, axes = plt.subplots(1, len(panels), figsize=(5.0 * len(panels), 4.6),
                             constrained_layout=True, squeeze=False)
    for ax, (name, t, col, bench, picked) in zip(axes[0], panels):
        x, y = t["Setting"].to_numpy(float), t[col].to_numpy(float)
        ax.plot(x, y, color=OURS_COLOR, lw=2.2, zorder=3)
        sig = t["Significant"].to_numpy(bool) if "Significant" in t else np.ones(len(t), bool)
        ax.scatter(x[sig], y[sig], s=46, color=OURS_COLOR, edgecolor=SURFACE,
                   linewidth=1.0, zorder=4)
        ax.scatter(x[~sig], y[~sig], s=46, facecolor=SURFACE, edgecolor=OURS_COLOR,
                   linewidth=1.6, zorder=4)
        k = int(np.flatnonzero(t["Scheduler"].to_numpy() == picked)[0]) \
            if picked in set(t["Scheduler"]) else None
        if k is not None:
            ax.scatter([x[k]], [y[k]], s=190, facecolor="none", edgecolor=INK,
                       linewidth=1.4, zorder=5)
            ax.annotate("picked", (x[k], y[k]), textcoords="offset points",
                        xytext=(0, 12), ha="center", fontsize=8.5, color=INK)
        ax.axhline(bench, color=BENCH_COLOR, lw=1.4, ls=(0, (5, 3)))
        ax.annotate("trade on every signal change", (x.min(), bench),
                    textcoords="offset points", xytext=(2, 4), fontsize=8.5,
                    color=INK_2)
        ax.set_xscale("log")
        _plain_log(ax)
        ax.set_xlabel("Fraction of the gap closed each day (log scale)")
        ax.set_title(name, fontsize=10.5, loc="left")
        _despine(ax)
    axes[0][0].set_ylabel("Profit after costs (Sharpe ratio)")
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


# ------------------------------------------------------------ fresh holdout


def _short_signal(name: str) -> str:
    return name.split(" (")[0]


def fig_period_consistency(table, title: str, caption: str = ""):
    """Ours minus each benchmark, in both periods the rule never saw.

    One panel per benchmark, on a shared x-axis so the two can be compared.
    Each row is one signal in one period: a 95% interval with its estimate.
    Filled markers: the interval excludes zero. Circles are the 2021-24 test
    half, diamonds the 2025-26 fresh holdout.
    """
    benches = list(dict.fromkeys(table["Benchmark"]))
    signals = list(dict.fromkeys(table["Signal"]))
    periods = list(dict.fromkeys(table["Period"]))
    marker = {p: m for p, m in zip(periods, ["o", "D"])}
    fig, axes = plt.subplots(1, len(benches), figsize=(6.4 * len(benches), 4.6),
                             sharex=True, sharey=True, constrained_layout=True,
                             squeeze=False)
    labels, ys = [], []
    k = 0
    for sig in signals:
        for per in periods:
            labels.append(f"{_short_signal(sig)}  |  {per}")
            ys.append(k)
            k += 1
        k += 0.6                                 # gap between signals
    ys = np.array(ys)[::-1]
    for ax, bench in zip(axes[0], benches):
        sub = table[table["Benchmark"] == bench]
        i = 0
        for sig in signals:
            for per in periods:
                r = sub[(sub["Signal"] == sig) & (sub["Period"] == per)].iloc[0]
                y = ys[i]
                ax.plot([r["95% lo"], r["95% hi"]], [y, y], color=OURS_COLOR, lw=2.2,
                        solid_capstyle="round", zorder=2)
                ax.scatter([r["Delta Sharpe"]], [y], s=70, marker=marker[per], zorder=3,
                           facecolor=OURS_COLOR if r["Significant"] else SURFACE,
                           edgecolor=OURS_COLOR, linewidth=1.8)
                ax.annotate(f"{r['Delta Sharpe']:+.2f}", (r["95% hi"], y),
                            textcoords="offset points", xytext=(6, 0), va="center",
                            fontsize=9, color=INK)
                i += 1
        ax.axvline(0, color=INK, lw=1.0)
        ax.set_title(f"Our rule {bench}", fontsize=10.5, loc="left")
        ax.set_xlabel("Difference in profit after costs (Sharpe ratio), 95% interval")
        ax.grid(axis="y", visible=False)
        _despine(ax)
    axes[0][0].set_yticks(ys, labels, fontsize=9.5)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_holdout_sensitivity(sens, title: str, caption: str = ""):
    """Every setting of our rule in both unseen periods, against the benchmark
    in that period. One panel per signal. Solid: 2025-26 holdout; dashed:
    2021-24 test half. Ringed: the setting picked on 2017-21."""
    signals = list(dict.fromkeys(sens["Signal"]))
    fig, axes = plt.subplots(1, len(signals), figsize=(6.4 * len(signals), 4.6),
                             constrained_layout=True, squeeze=False)
    styles = {"2021-24": dict(ls=(0, (5, 3)), alpha=0.75, lw=1.8),
              "2025-26": dict(ls="-", alpha=1.0, lw=2.6)}
    for ax, sig in zip(axes[0], signals):
        t = sens[sens["Signal"] == sig].sort_values("Setting")
        x = t["Setting"].to_numpy(float)
        for per, st in styles.items():
            y = t[f"Sharpe {per}"].to_numpy(float)
            ax.plot(x, y, color=OURS_COLOR, marker="o", markersize=5,
                    markeredgecolor=SURFACE, label=f"Our rule, {per}", **st)
            bench = float(t[f"Benchmark {per}"].iloc[0])
            ax.axhline(bench, color=BENCH_COLOR, lw=1.3,
                       ls=(0, (5, 3)) if per == "2021-24" else "-", alpha=st["alpha"])
            ax.annotate(f"every change, {per}", (x.min(), bench), textcoords="offset points",
                        xytext=(2, 4), fontsize=8, color=INK_2)
            pk = t["Picked"].to_numpy(bool)
            if pk.any():
                ax.scatter(x[pk], y[pk], s=170, facecolor="none", edgecolor=INK,
                           linewidth=1.3, zorder=5)
        ax.set_xscale("log")
        _plain_log(ax)
        ax.set_xlabel("Fraction of the gap closed each day (log scale)")
        ax.set_title(f"Signal: {sig}", fontsize=10.5, loc="left")
        _despine(ax)
    axes[0][0].set_ylabel("Profit after costs (Sharpe ratio)")
    axes[0][0].legend(loc="upper right", fontsize=8.5)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


# ------------------------------------------------------- phase 6 regime maps

_HL, _COST = "Alpha half-life (bars)", "Cost (bps)"


def fig_regime_maps(ga, prefix: str = "") -> dict:
    """All three phase-6 maps, keyed equal_turnover / timing_only /
    vs_best_calendar (see `fig_regime_map`)."""
    return {k: fig_regime_map(ga, k, prefix)
            for k in ("equal_turnover", "timing_only", "vs_best_calendar")}


def fig_regime_map(ga, which: str, prefix: str = ""):
    """One phase-6 map (signal speed x trading cost), labelled so it says what
    it measures. Cells whose 95% interval includes zero are marked n.s. where
    an interval exists."""
    kw = dict(row_fmt=lambda v: f"{v:g} days", col_fmt=lambda v: f"{v:g} bps",
              xlabel="Trading cost per unit traded (bps)",
              ylabel="How fast the signal fades (half-life)")

    def sig(lo, hi):
        if lo not in ga or hi not in ga:
            return None
        m = ga.assign(_s=(ga[lo] > 0) | (ga[hi] < 0))
        return m.pivot(index=_HL, columns=_COST, values="_s")

    label = "Difference in Sharpe ratio"
    if which == "equal_turnover":
        return fig_heatmap(
            ga.pivot(index=_HL, columns=_COST, values="Advantage"),
            prefix + "Feedback rule vs a calendar trading exactly as much", label,
            "Measured at the trading level where the gap is largest, usually a slow, stale calendar. "
            "It is not the gain from switching (see 'When switching pays'). n.s.: interval includes zero.",
            sig=sig("Advantage 95% lo", "Advantage 95% hi"), **kw)
    if which == "timing_only":
        return fig_heatmap(
            ga.pivot(index=_HL, columns=_COST, values="Timing-only advantage"),
            prefix + "Picking the moment alone: rules that move all the way, vs a calendar trading as much",
            label,
            "How far is fixed at 100%, so this is the value of when by itself. "
            "n.s.: the 95% interval includes zero.",
            sig=sig("Timing-only 95% lo", "Timing-only 95% hi"), **kw)
    if which == "vs_best_calendar":
        gain = ga.assign(_g=ga["Closed-loop Sharpe"] - ga["Best calendar Sharpe"])
        return fig_heatmap(
            gain.pivot(index=_HL, columns=_COST, values="_g"),
            prefix + "When switching pays: best feedback rule minus best calendar", label,
            "Each side picked on calibration paths, at whatever trading level suits it. "
            "Blue: switching to the feedback rule pays. Grey: no difference.", **kw)
    raise ValueError(f"unknown regime map {which!r}")


# --------------------------------------------------- when x how far (6b, 7b)


def _signed_cell(ax, data, labels, vmax, row_names, col_names, vmin=None):
    """A small heatmap with a label printed in every cell: diverging around
    zero for a signed quantity, a blue ramp from `vmin` for a level."""
    if vmin is None:
        im = ax.imshow(data, cmap=DIVERGING, vmin=-vmax, vmax=vmax, aspect="auto")
    else:
        im = ax.imshow(data, cmap=SEQ_BLUE, vmin=vmin, vmax=vmax, aspect="auto")
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            v = data[i, j]
            if np.isnan(v):
                continue
            shade = (abs(v) / (vmax + 1e-12) if vmin is None
                     else (v - vmin) / max(vmax - vmin, 1e-12))
            ax.text(j, i, labels[i][j], ha="center", va="center", fontsize=9,
                    color="white" if shade > 0.55 else INK, linespacing=1.35)
    ax.set_xticks(range(len(col_names)), col_names, fontsize=9.5)
    ax.set_yticks(range(len(row_names)), row_names, fontsize=9.5)
    ax.tick_params(length=0)
    ax.grid(False)
    for side in ax.spines.values():
        side.set_visible(False)
    return im


def fig_two_by_two(cells, margins: dict, title: str, caption: str = ""):
    """When x how far. Left: the best rule in each cell (knob picked on
    calibration paths) and its net Sharpe on held-out paths. Right: the four
    margins, each holding one decision fixed and changing the other."""
    whens = list(dict.fromkeys(cells["When"]))
    hows = list(dict.fromkeys(cells["How far"]))
    data = np.full((len(whens), len(hows)), np.nan)
    labels = [["" for _ in hows] for _ in whens]
    for _, r in cells.iterrows():
        i, j = whens.index(r["When"]), hows.index(r["How far"])
        data[i, j] = r["Net Sharpe"]
        labels[i][j] = (f"{r['Net Sharpe']:.3f}\n{r['Rule']}\n"
                        f"trades {r['Turnover/yr']:.0f}x/yr")
    lo = float(np.nanmin(data) - 0.25 * (np.nanmax(data) - np.nanmin(data) + 1e-3))

    fig = plt.figure(figsize=(14, 4.9), constrained_layout=True)
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.25])
    ax = fig.add_subplot(gs[0])
    im = _signed_cell(ax, data, labels, float(np.nanmax(data)),
                      [f"WHEN: {w.lower()}" for w in whens],
                      [f"HOW FAR: {h.lower()}" for h in hows], vmin=lo)
    ax.set_title("Best rule in each cell: profit after costs (net Sharpe)",
                 fontsize=10.5, loc="left")
    cb = fig.colorbar(im, ax=ax, shrink=0.8)
    cb.outline.set_visible(False)

    ax2 = fig.add_subplot(gs[1])
    keys = list(margins)
    y = np.arange(len(keys))[::-1]
    ax2.axvline(0, color=INK, lw=1.0)
    for yi, k in zip(y, keys):
        d = margins[k]
        color = GOOD if d.lo > 0 else (CRITICAL if d.hi < 0 else MUTED)
        ax2.plot([d.lo, d.hi], [yi, yi], color=color, lw=2.4, solid_capstyle="round")
        ax2.plot([d.mean], [yi], "o", color=color, markersize=8,
                 markeredgecolor=SURFACE, markeredgewidth=1.2)
        ax2.annotate(f"{d.mean:+.3f}", (d.hi, yi), textcoords="offset points",
                     xytext=(8, 0), va="center", fontsize=9, color=INK_2)
    ax2.set_yticks(y, keys, fontsize=9.5)
    ax2.set_xlabel("Difference in profit after costs (Sharpe ratio), 95% interval")
    ax2.set_title("Change one decision, hold the other fixed (best vs best)",
                  fontsize=10.5, loc="left")
    ax2.grid(axis="y", visible=False)
    lo = min(d.lo for d in margins.values())
    hi = max(d.hi for d in margins.values())
    ax2.set_xlim(min(lo, 0) - 0.02, hi + 0.25 * (hi - min(lo, 0) + 1e-9))
    _despine(ax2)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_cost_shape(table, keys: list, title: str, caption: str = "",
                   material: float = 0.01):
    """Phase 6b: one small heatmap per test (rows: cost shape; columns: fixed
    fee per order), all on one colour scale so they can be compared. Each cell
    is the best rule of one design minus the best of the other. n.s. marks an
    interval that includes zero; tiny, a significant difference smaller than
    `material` Sharpe; same rule, a cell where both sides picked one schedule."""
    shapes = list(dict.fromkeys(table["Cost shape"]))
    fees = sorted(table["Order fee (bps)"].unique())
    grids, texts = [], []
    for k in keys:
        g = np.full((len(shapes), len(fees)), np.nan)
        t = [["" for _ in fees] for _ in shapes]
        for _, r in table.iterrows():
            i, j = shapes.index(r["Cost shape"]), fees.index(r["Order fee (bps)"])
            g[i, j] = r[f"{k} | Delta Sharpe"]
            if r[f"{k} | Rule"] == r[f"{k} | Reference"] or not np.isfinite(r[f"{k} | 95% lo"]):
                tag = "\nsame rule"          # both sides picked the same schedule
            elif not r[f"{k} | Significant"]:
                tag = "\nn.s."
            elif abs(g[i, j]) < material:
                tag = "\ntiny"
            else:
                tag = ""
            t[i][j] = f"{_signed(g[i, j], 3)}{tag}"
        grids.append(g)
        texts.append(t)
    vmax = max(np.nanmax(np.abs(np.stack(grids))), 1e-3)
    ncol = 2
    nrow = int(np.ceil(len(keys) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(12, 3.1 * nrow + 1.0),
                             constrained_layout=True, squeeze=False)
    fee_names = [f"{f:g} bps/order" for f in fees]
    for ax, k, g, t in zip(axes.flat, keys, grids, texts):
        im = _signed_cell(ax, g, t, vmax, shapes, fee_names)
        ax.set_title(k, fontsize=10.5, loc="left")
    for ax in axes.flat[len(keys):]:
        ax.axis("off")
    cb = fig.colorbar(im, ax=axes, shrink=0.75)
    cb.set_label("Delta Sharpe, best rule vs best rule", color=INK_2)
    cb.outline.set_visible(False)
    fig.suptitle(title, x=0.01, ha="left", fontsize=13, fontweight="semibold", color=INK)
    if caption:
        _caption(fig, caption)
    return fig


def fig_timing_recheck(table, title: str, caption: str = ""):
    """Timing's best grid cells against the same rules on fresh paths: one row
    per cost level, grid estimate (open) above the fresh estimate (filled)."""
    rows = table.reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(10, 0.9 * len(rows) + 2.0), constrained_layout=True)
    ax.axvline(0, color=INK, lw=1.0)
    ticks, names = [], []
    for i, r in rows.iterrows():
        base = (len(rows) - 1 - i) * 1.0
        for off, kind, filled in ((0.18, "Grid", False), (-0.18, "Fresh", True)):
            lo, hi, m = r[f"{kind} 95% lo"], r[f"{kind} 95% hi"], r[f"{kind} estimate"]
            color = GOOD if lo > 0 else (CRITICAL if hi < 0 else MUTED)
            ax.plot([lo, hi], [base + off] * 2, color=color, lw=2.2, solid_capstyle="round")
            ax.scatter([m], [base + off], s=60, zorder=3, edgecolor=color, linewidth=1.6,
                       facecolor=color if filled else SURFACE)
            ax.annotate(f"{kind.lower()} {m:+.3f}", (hi, base + off), textcoords="offset points",
                        xytext=(6, 0), va="center", fontsize=8.5, color=INK_2)
        ticks.append(base)
        names.append(f"{r['Cost (bps)']:g} bps: {r['Timing rule (frozen)']}")
    ax.set_yticks(ticks, names, fontsize=9)
    ax.set_xlabel("Timing rule minus a calendar trading as much (Sharpe), 95% interval")
    ax.set_title(title)
    ax.grid(axis="y", visible=False)
    _despine(ax)
    if caption:
        _caption(fig, caption)
    return fig


def build_figures(res: dict) -> dict:
    """Every figure in the deck, from a `phases.run_all` result.

    The notebook calls the individual builders so it can interleave prose; this
    bundle is what the one-command runner writes to disk.
    """
    use_style()
    p2, p3, p4, p5, p6, p7, p8 = (res[k] for k in ("p2", "p3", "p4", "p5", "p6", "p7", "p8"))
    figs: dict = {}

    an_ex = res.get("analytics")
    bl = res.get("bottom")
    if bl is not None:
        h = bl["headline"].iloc[0].to_dict()
        figs["00a_scorecard"] = fig_scorecard(
            bl["scorecard"], h, "Our rule against the benchmark: more profit, less trading",
            "Simulated market, held-out paths only. Same signal and same costs for every rule.")
        figs["00b_every_budget"] = fig_budget_bars(
            bl["budgets"], "At every trading budget, the feedback rule earns more",
            "Each pair trades no more than the budget on the axis. An interval that excludes "
            "zero means the gap is real.")
        if bl["_real"]:
            figs["00c_real_btc_eth"] = fig_real_growth(
                bl["_real"], "Real BTC/ETH, out of sample: growth of $1",
                "Our rule and the calendar were both chosen on 2017-2021; only 2021-2024 is shown. "
                "A line can end higher by taking "
                "more risk, so compare the Sharpe in the legend. Costs: 4 bps + market impact.")
        figs["00d_gain_split"] = fig_gain_split(
            bl["attribution"], "Where the gain comes from",
            "Almost all of it comes from pacing the trade (moving part of the way each day). "
            "Picking the moment adds very little.")
    if an_ex is not None:
        figs["00e_sensitivity"] = fig_robustness(
            an_ex["robustness"], "How sensitive is our rule to its one setting?",
            "Closing the whole gap each day (1.0) is the benchmark itself. "
            "Too slow and the book goes stale; too fast and costs pile up.")
    p7b = res.get("p7b")
    if p7b is not None and len(p7b["cells"]):
        figs["00f_when_vs_how_far"] = fig_two_by_two(
            p7b["cells"], p7b["_margins"],
            "When to trade, or how far to move? Every trigger x every move fraction",
            "Simulated market. Each side's setting is picked on calibration paths and scored on "
            "held-out ones, best rule against best rule.")

    if an_ex is not None:
        figs["01a_example_path"] = fig_example_path(
            an_ex["example"], an_ex["labels"],
            "Phase 1  What each rule does: target weight against what the rule holds",
            "One asset, half a year of one held-out path. Grey: what the signal wants. "
            "Colour: what the rule holds. Green: the rule Phase 7 goes on to recommend.",
            highlight=an_ex["highlight"])
    figs["01_frontier"] = fig_frontier(
        p2["_selected"], p2["paper_sharpe"],
        "Phase 2  Net Sharpe against turnover, by scheduler family",
        "Higher and further left is better. Knobs are chosen on calibration paths and scored on held-out ones.")
    figs["02_decomposition"] = fig_decomposition(
        p2["decomposition"].to_dict("records"),
        f"Phase 2  Where the Sharpe went, at a turnover budget of {p2['budget_mid']:g}x/yr",
        "The three segments sum to the paper portfolio's Sharpe for every arm.")
    an = res.get("analytics")
    if an is not None:
        figs["02b_tradeoff"] = fig_tradeoff(
            an["tradeoff"], "Phase 2  Same trading, less staleness: why moving part of the way wins",
            "Each point is one rule setting, scored on held-out paths. Left: Sharpe lost to a "
            "stale book. Right: Sharpe lost to costs.")
    if len(p2.get("_matched_diffs", [])):
        figs["03b_equal_turnover"] = fig_forest(
            p2["_matched_diffs"],
            "Phase 2  Each family minus a calendar trading exactly as much",
            "The strict test: both arms trade the same amount, so turnover cannot "
            "be the explanation.")
    figs["04_execution"] = fig_execution(
        p3["curve"], "Phase 3  Execution algorithms, measured not assumed",
        "Cheaper fills are bought with exposure to price drift; both panels are in bps.")
    figs["05_power"] = fig_power(
        p4["power"], "Phase 4  The effect available vs the effect detectable",
        "An effect whose bar is shorter than its resolution bar cannot be found by any backtest, "
        "however careful.")
    hd = res.get("p5h")
    if hd is not None and hd.get("_navs"):
        per = hd["period"]
        figs["06a_holdout_growth"] = fig_real_growth(
            hd["_navs"], f"Fresh holdout {per['start']} to {per['end']}: growth of $1",
            "Rules picked on 2017-21 and never re-tuned. A line can end higher by taking more "
            "risk, so compare the Sharpe in the legend. Costs: 4 bps + market impact.")
        figs["06b_period_consistency"] = fig_period_consistency(
            hd["consistency"], "Ours minus each benchmark, on data it never saw: 2021-24 and 2025-26",
            "Filled marker: the 95% interval excludes zero. Circles: 2021-24 test half. "
            "Diamonds: 2025-26 fresh holdout.")
        figs["06c_holdout_sensitivity"] = fig_holdout_sensitivity(
            hd["sensitivity"], "Every setting of our rule, in both unseen periods",
            "Solid: 2025-26. Dashed: 2021-24. Blue lines: trading on every change in that "
            "period. Ringed: the setting picked on 2017-21.")
    regime = fig_regime_maps(p6["regime_half_life_cost"], prefix="Phase 6  ")
    figs["07_regime"] = regime["equal_turnover"]
    figs["07b_regime_timing_only"] = regime["timing_only"]
    figs["07c_regime_vs_best_calendar"] = regime["vs_best_calendar"]
    rc = p6.get("timing_recheck")
    if rc is not None and len(rc):
        figs["07e_timing_recheck"] = fig_timing_recheck(
            rc, f"Phase 6  Picking the moment's best case, rebuilt on {int(rc['Fresh paths'].iloc[0])} fresh paths",
            "The half-life row where full-move timing did best in the grid. Same rules, frozen; "
            "only the paths are new. Open: grid estimate. Filled: fresh paths.")
    p6b = res.get("p6b")
    if p6b is not None and len(p6b.get("cost_shape", [])):
        from .phases import MARGINS
        figs["07d_cost_shape"] = fig_cost_shape(
            p6b["cost_shape"], list(MARGINS),
            "Phase 6b  How cost grows with trade size decides whether when or how far matters",
            "Rows: cost shape, all charging the same per unit on a typical trade. Columns: a fixed "
            "fee per order (bps of NAV; 0.5 bps is \\$5 on a \\$100k book). n.s.: interval includes zero. "
            "tiny: significant but under 0.01 Sharpe.")
    gb = p6["mechanism_burst_coupling"]
    xc = sorted(gb["Coupling"].unique())
    figs["08_mechanism_coupling"] = fig_mechanism(
        xc,
        {"Price CUSUM": [gb[gb.Coupling == c]["Price-CUSUM - clock"].mean() for c in xc],
         "Target CUSUM": [gb[gb.Coupling == c]["Target-CUSUM - clock"].mean() for c in xc],
         "All closed-loop": [gb[gb.Coupling == c]["Closed-loop advantage"].mean() for c in xc]},
        "Phase 6  Mechanism: does a price detector need the price to carry the information?",
        "Coupling: share of return volatility moving when the target moves",
        "Advantage over a calendar trading as much (Sharpe)")
    xb = sorted(gb["Burstiness"].unique())
    figs["08b_mechanism_burstiness"] = fig_mechanism(
        xb,
        {"All closed-loop": [gb[gb.Burstiness == b]["Closed-loop advantage"].mean() for b in xb],
         "Timing only": [gb[gb.Burstiness == b]["Timing-only advantage"].mean() for b in xb]},
        "Phase 6  Mechanism: does clustered information arrival help event-driven timing?",
        "Burstiness: clustering of information arrival, average rate held fixed",
        "Advantage over a calendar trading as much (Sharpe)")
    figs["09_benchmarks"] = fig_benchmarks(
        p7["benchmarks"].to_dict("records"),
        "Phase 7  Head to head against the standard benchmarks",
        "Our rule is highlighted; the ceiling is the paper portfolio traded free.")
    figs["10_placebo"] = fig_placebo(
        p7["_placebo_dist"], p7["ours_sharpe"],
        "Phase 7  Against random timing at the same trade rate and move size",
        "Same trade rate and move size, random times. Our rule sits near the top of the random "
        "draws but not clear of them: picking the moment adds little.")
    figs["11_attribution"] = fig_forest(
        p7["_attribution"] + p7["_timing_diffs"],
        "Phase 7  When to trade, and how far to move, measured separately",
        "The first two rows add up to the third by construction.")
    if p7b is not None and (p7b["_when"] or p7b["_how_far"]):
        figs["11b_factorial_tests"] = fig_forest(
            p7b["_when"] + p7b["_how_far"],
            "Phase 7b  WHEN at each move fraction, HOW FAR for each trigger",
            "Top rows: best event trigger vs calendar at the same move fraction. Bottom rows: "
            "each trigger moving part of the way vs the same trigger moving all the way.")
    figs["12_verdict"] = fig_verdict(
        p8["criteria"].to_dict("records"), "Phase 8  Success criteria (C4 post-hoc)")
    return figs


def fig_verdict(rows: list[dict], title: str, caption: str = ""):
    """The study's criteria, scored. Green passed, red did not."""
    y = np.arange(len(rows))[::-1]
    fig, ax = plt.subplots(figsize=(10, 0.56 * len(rows) + 2.0), constrained_layout=True)
    for i, r in enumerate(rows):
        passed = bool(r["Passed"])
        color = GOOD if passed else CRITICAL
        ax.scatter([0], [y[i]], s=620, color=color, zorder=3,
                   marker="o", edgecolor=SURFACE, linewidth=1.4)
        ax.annotate("PASS" if passed else "FAIL", (0, y[i]), ha="center", va="center",
                    fontsize=8, color="white", fontweight="bold", zorder=4)
        ax.annotate(r["Criterion"], (0.06, y[i]), fontsize=10, color=INK,
                    va="center", fontweight="semibold")
        ax.annotate(r["Evidence"], (0.06, y[i] - 0.34), fontsize=9, color=INK_2,
                    va="center")
    ax.set_xlim(-0.05, 1.0)
    ax.set_ylim(-0.8, len(rows) - 0.3)
    ax.axis("off")
    ax.set_title(title, loc="left")
    if caption:
        _caption(fig, caption)
    return fig
