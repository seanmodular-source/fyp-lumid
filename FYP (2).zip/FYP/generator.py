"""Synthetic market generator -- the controlled laboratory.

Why a lab at all? Because on real data you cannot separate "my scheduler is
better" from "my alpha was lucky in this sample". Here the alpha is a known
quantity with a calibrated gross Sharpe of 1.0 (hit to within 1e-3 on a
separate calibration seed; it varies by sampling error on the evaluation
paths), identical across every arm, and only the scheduler changes. Monte-Carlo over many paths then
shrinks the standard error of a paired comparison to something that can
actually resolve a 0.05 Sharpe difference -- which ~7 years of two crypto
assets cannot (see phase 4).

Generative model
----------------
Latent alpha per asset follows an AR(1) with half-life `half_life`, driven by
innovations that arrive at random times::

    a[t] = phi * a[t-1] + xi[t] * 1{arrival at t},   phi = 0.5 ** (1/half_life)

Arrivals are governed by a two-state Markov chain whose *average* rate is fixed
at `arrival_rate` but whose clustering is controlled by `burstiness`:

    burstiness = 0  -> i.i.d. arrivals, information trickles in uniformly
    burstiness -> 1 -> arrivals cluster in bursts, quiet spells in between

Because the average rate is held constant, burstiness isolates *clustering*
from *frequency*. That matters: the central claim of event-driven rebalancing
is that it wins when information arrives in bursts, and this knob is what makes
that claim falsifiable.

Returns decompose into three orthogonal pieces with a fixed total variance::

    r[t] = sigma * [ sqrt(1 - la^2 - lk^2) * eps[t]   # unpredictable noise
                   + la * a_std[t-1]                  # the predictable part
                   + lk * xi_std[t] ]                 # information *visible in
                                                      # the price as it arrives

`coupling` (= lk) is the second mechanism knob. It sets how much of an alpha
update is simultaneously visible as a price move:

    coupling = 0    -> the target moves without the price moving. A price-based
                       CUSUM is structurally blind and must degrade to random.
    coupling large  -> information is in the tape, and price events are
                       informative about target changes.

`la` is not chosen by hand: it is solved by a secant iteration so that the paper
portfolio -- holding the target exactly, every bar, at zero cost, under the
same execution lag as every other arm -- has an annualised Sharpe of 1.0.

References for the design
    Clark (1973), "A subordinated stochastic process model with finite variance
        for speculative prices", Econometrica 41(1), 135-155.
    Ane & Geman (2000), Journal of Finance 55(5), 2259-2284.
    Grinold (1989), "The fundamental law of active management", JPM 15(3).
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np

from .core import MarketData, SimConfig, paper_portfolio
from .evaluation import annualised_sharpe


@dataclass
class SyntheticParams:
    """Every knob of the laboratory. Defaults describe a liquid, moderately
    volatile six-asset book with a 10-bar alpha."""

    n_assets: int = 6
    n_bars: int = 1008            # ~4 years of daily bars
    ann_factor: int = 252
    ann_vol: float = 0.35         # per-asset annualised volatility
    corr: float = 0.30            # equicorrelation between assets
    half_life: float = 10.0       # alpha decay half-life, in bars
    arrival_rate: float = 0.35    # average arrivals per bar per asset
    # Default burstiness is deliberately NOT zero. Information arriving in
    # clusters is one of the most robust stylised facts in finance (volatility
    # clustering; Cont 2001, "Empirical properties of asset returns"), so a lab
    # with uniform arrivals would be the unrealistic choice, not the neutral
    # one. Phase 6 sweeps this knob from 0 to 0.95 so the result is reported
    # across the whole range rather than at one convenient setting.
    burstiness: float = 0.60      # 0 = uniform, 1 = strongly clustered
    coupling: float = 0.40        # share of return vol carrying the arrival
    lam_alpha: float = 0.06       # predictive strength (set by calibration)
    vol_target: float = 0.15      # annualised portfolio volatility target
    max_gross: float = 2.0        # gross exposure cap
    vol_window: int = 20          # trailing window for vol and z-scores
    adv_usd: float = 5.0e8        # average daily dollar volume per asset
    volume_info: float = 0.6      # how strongly volume responds to information
    long_only: bool = False       # lab runs long/short by default

    @property
    def phi(self) -> float:
        return 0.5 ** (1.0 / max(self.half_life, 1e-9))

    @property
    def sigma_bar(self) -> float:
        return self.ann_vol / np.sqrt(self.ann_factor)


# ------------------------------------------------------------------ pieces


def _markov_arrivals(params: SyntheticParams, S: int, T: int, N: int, rng) -> np.ndarray:
    """Arrival indicators with a fixed average rate and tunable clustering."""
    b = float(np.clip(params.burstiness, 0.0, 1.0))
    rate = float(np.clip(params.arrival_rate, 1e-6, 1.0))
    if b <= 0.0:
        return (rng.random((S, T, N)) < rate).astype(float)

    # Symmetric 2-state chain -> stationary distribution is 50/50, so the
    # average arrival rate stays `rate` for every value of b.
    hi = np.clip(rate * (1.0 + 0.95 * b), 0.0, 1.0)
    lo = np.clip(rate * (1.0 - 0.95 * b), 0.0, 1.0)
    # The two states must straddle `rate` symmetrically for the average
    # arrival rate to stay fixed as burstiness varies -- which is the whole
    # point of the knob. If the high state saturates at 1.0 the mean drifts
    # and the alpha's unit-variance normalisation goes with it.
    if not np.isclose(0.5 * (hi + lo), rate, rtol=1e-6):
        raise ValueError(
            f"arrival_rate={rate} with burstiness={b} saturates the high state "
            f"(hi={hi:.3f}, lo={lo:.3f}); the average arrival rate would no "
            f"longer be held fixed across the sweep. Lower arrival_rate.")
    switch = 0.05                      # mean sojourn of 20 bars in each state

    state = rng.random((S, N)) < 0.5   # True = high-intensity regime
    out = np.empty((S, T, N))
    u_state = rng.random((S, T, N))
    u_fire = rng.random((S, T, N))
    for t in range(T):
        flip = u_state[:, t, :] < switch
        state = np.where(flip, ~state, state)
        p = np.where(state, hi, lo)
        out[:, t, :] = (u_fire[:, t, :] < p).astype(float)
    return out


def build_components(params: SyntheticParams, n_paths: int, seed: int) -> dict:
    """Draw everything that does NOT depend on the predictive strength `la`.

    Separating this from assembly means the calibration can re-price
    the same random draws dozens of times without redrawing them -- and it
    guarantees that two values of `la` differ only in signal strength.
    """
    rng = np.random.default_rng(seed)
    S, T, N = n_paths, params.n_bars, params.n_assets

    # --- correlated unpredictable noise ---------------------------------
    corr = np.full((N, N), params.corr, dtype=float)
    np.fill_diagonal(corr, 1.0)
    chol = np.linalg.cholesky(corr)
    eps = rng.standard_normal((S, T, N)) @ chol.T

    # --- alpha process ---------------------------------------------------
    arrivals = _markov_arrivals(params, S, T, N, rng)
    xi = rng.standard_normal((S, T, N)) * arrivals

    phi = params.phi
    a = np.empty((S, T, N))
    prev = np.zeros((S, N))
    for t in range(T):
        prev = phi * prev + xi[:, t, :]
        a[:, t, :] = prev

    # Theoretical stationary scale of the AR(1) with Bernoulli arrivals.
    sd_a = np.sqrt(params.arrival_rate / max(1.0 - phi ** 2, 1e-12))
    sd_xi = np.sqrt(params.arrival_rate)
    a_std = a / sd_a
    xi_std = xi / sd_xi

    return {
        "eps": eps,
        "a_std": a_std,
        "xi_std": xi_std,
        "arrivals": arrivals,
        "corr": corr,
        "shape": (S, T, N),
        "rng_state_seed": seed,
    }


def _targets_from_alpha(params: SyntheticParams, a_std: np.ndarray,
                        resid: float = 1.0) -> np.ndarray:
    """Map the alpha vector to target weights at a fixed volatility target.

    Uses the *true* covariance of the generated returns (a known constant of
    the lab, not an estimate from the future), so the sizing step introduces no
    estimation noise and no look-ahead. Sizing is held constant across arms.

    The correlation that matters is NOT `params.corr`. Only the noise term
    carries cross-asset correlation, and it enters with weight sqrt(resid), so
    the realised correlation is `resid * corr` while each asset's variance
    stays sigma^2. Using `corr` here would miss the volatility target by an
    amount that varies with the coupling knob -- putting a systematic leverage
    gradient across the very sweep that phase 6 uses to test the mechanism.
    """
    S, T, N = a_std.shape
    sigma_bar = params.sigma_bar
    corr = np.full((N, N), params.corr * float(resid), dtype=float)
    np.fill_diagonal(corr, 1.0)
    cov = corr * sigma_bar ** 2

    u = np.maximum(a_std, 0.0) if params.long_only else a_std
    gross = np.abs(u).sum(axis=2, keepdims=True)
    w_raw = np.divide(u, gross, out=np.zeros_like(u), where=gross > 1e-12)

    # Ex-ante portfolio volatility of the unit-gross book, annualised.
    quad = np.einsum("stn,nm,stm->st", w_raw, cov, w_raw)
    ex_ante = np.sqrt(np.maximum(quad, 1e-24) * params.ann_factor)
    scale = params.vol_target / np.maximum(ex_ante, 1e-12)

    w = w_raw * scale[:, :, None]
    g = np.abs(w).sum(axis=2, keepdims=True)
    over = g > params.max_gross
    w = np.where(over, w * (params.max_gross / np.maximum(g, 1e-12)), w)

    # Warm-up: no positions until trailing statistics exist, identically for
    # every arm, so nobody gets an advantage from the burn-in period.
    w[:, : params.vol_window, :] = 0.0
    return w


def assemble(params: SyntheticParams, comp: dict, lam_alpha: float | None = None):
    """Turn pre-drawn components into a MarketData + target path."""
    la = params.lam_alpha if lam_alpha is None else float(lam_alpha)
    lk = float(np.clip(params.coupling, 0.0, 0.95))
    resid = 1.0 - la ** 2 - lk ** 2
    if resid <= 0:
        raise ValueError(
            f"lam_alpha={la:.3f} and coupling={lk:.3f} exceed the variance budget"
        )

    S, T, N = comp["shape"]
    sigma_bar = params.sigma_bar

    a_lag = np.zeros_like(comp["a_std"])
    a_lag[:, 1:, :] = comp["a_std"][:, :-1, :]      # a[t-1] predicts r[t]

    r = sigma_bar * (
        np.sqrt(resid) * comp["eps"] + la * a_lag + lk * comp["xi_std"]
    )

    # --- derived, strictly backward-looking market statistics ------------
    log_r = np.log1p(np.clip(r, -0.99, None))
    vol_prev = _trailing_std(log_r, params.vol_window)
    vol_prev = np.where(vol_prev > 0, vol_prev, sigma_bar)
    z = log_r / vol_prev
    z[:, : params.vol_window, :] = 0.0

    ret_vol_prev = _trailing_std(r, params.vol_window)
    ret_vol_prev = np.where(ret_vol_prev > 0, ret_vol_prev, sigma_bar)

    # --- volume: reacts to both realised moves and information arrival ----
    rng = np.random.default_rng(comp["rng_state_seed"] + 101)
    shock = rng.lognormal(mean=0.0, sigma=0.30, size=(S, T, N))
    activity = (
        1.0
        + params.volume_info * (np.abs(z) - 0.8)
        + params.volume_info * comp["arrivals"]
    )
    activity = np.clip(activity, 0.15, None) * shock
    dollar_volume = params.adv_usd * activity / activity.mean()
    adv = _trailing_mean(dollar_volume, params.vol_window)
    adv = np.where(adv > 0, adv, params.adv_usd)

    market = MarketData(
        returns=r,
        z_returns=z,
        dollar_volume=dollar_volume,
        adv=adv,
        vol=ret_vol_prev,
    )
    targets = _targets_from_alpha(params, comp["a_std"], resid=resid)
    return market, targets


# ---------------------------------------------------------------- helpers


def _window_bounds(T: int, window: int):
    """Index helpers for a trailing window that ends at t-1 (never includes t)."""
    hi = np.arange(T)
    lo = np.maximum(0, hi - window)
    n = (hi - lo).astype(float)
    return lo, hi, n


def _trailing_std(x: np.ndarray, window: int) -> np.ndarray:
    """Std over the `window` bars *strictly before* each bar (no look-ahead).

    Cumulative-sum implementation: O(T) instead of O(T*window), which matters
    because the calibration rebuilds these arrays many times.
    """
    S, T, N = x.shape
    c1 = np.zeros((S, T + 1, N))
    c2 = np.zeros((S, T + 1, N))
    np.cumsum(x, axis=1, out=c1[:, 1:, :])
    np.cumsum(x * x, axis=1, out=c2[:, 1:, :])

    lo, hi, n = _window_bounds(T, window)
    s1 = c1[:, hi, :] - c1[:, lo, :]
    s2 = c2[:, hi, :] - c2[:, lo, :]
    n_safe = np.maximum(n, 1.0)[None, :, None]
    mean = s1 / n_safe
    var = np.maximum(s2 / n_safe - mean ** 2, 0.0)
    # population -> sample variance
    adj = np.where(n > 1, n / np.maximum(n - 1.0, 1.0), 0.0)[None, :, None]
    out = np.sqrt(var * adj)
    out[:, n < 2, :] = 0.0
    return out


def _trailing_mean(x: np.ndarray, window: int) -> np.ndarray:
    """Mean over the `window` bars strictly before each bar."""
    S, T, N = x.shape
    c1 = np.zeros((S, T + 1, N))
    np.cumsum(x, axis=1, out=c1[:, 1:, :])
    lo, hi, n = _window_bounds(T, window)
    s1 = c1[:, hi, :] - c1[:, lo, :]
    out = s1 / np.maximum(n, 1.0)[None, :, None]
    out[:, n < 1, :] = x[:, :1, :]    # bar 0 has no history; use its own value
    return out


# ------------------------------------------------------------ calibration


def calibrate_lam_alpha(
    params: SyntheticParams,
    target_sharpe: float = 1.0,
    n_paths: int = 96,
    seed: int = 9973,
    sim_cfg: SimConfig | None = None,
    tol: float = 1e-3,
    max_iter: int = 40,
    return_achieved: bool = False,
):
    """Solve for the predictive strength that makes the paper portfolio's
    annualised Sharpe equal `target_sharpe`.

    Calibration runs on its own seed, disjoint from every evaluation seed, so
    the ceiling is not fitted to the paths it is later measured on.
    """
    sim_cfg = sim_cfg or SimConfig(ann_factor=params.ann_factor)
    comp = build_components(params, n_paths, seed)
    budget = np.sqrt(max(1.0 - float(params.coupling) ** 2, 1e-6)) * 0.98

    def paper_sharpe(la: float) -> float:
        market, targets = assemble(params, comp, la)
        res = paper_portfolio(market, targets, sim_cfg)
        return float(np.mean(annualised_sharpe(res.net_returns, params.ann_factor)))

    # Sharpe is very nearly proportional to the predictive strength while the
    # noise term dominates the variance, so a secant iteration converges in a
    # handful of evaluations where bisection needs dozens. Each evaluation is a
    # full simulation, and the grids in phase 6 calibrate a fresh lab per cell,
    # so this is the difference between a minute and ten.
    def done(la: float, s: float):
        # Always hand back what was actually achieved. The claim "the ceiling
        # is 1.0" is the foundation every later number rests on, and a solver
        # that can exit four different ways must not be trusted to have hit it.
        return (la, s) if return_achieved else la

    la0 = min(0.04, budget * 0.5)
    s0 = paper_sharpe(la0)
    if s0 <= 0:
        return done(la0, s0)
    la1 = float(np.clip(la0 * target_sharpe / s0, 1e-4, budget))
    s1 = paper_sharpe(la1)

    for _ in range(max_iter):
        if abs(s1 - target_sharpe) < tol:
            return done(la1, s1)
        denom = s1 - s0
        if abs(denom) < 1e-12:
            break
        la2 = la1 + (target_sharpe - s1) * (la1 - la0) / denom
        la2 = float(np.clip(la2, 1e-4, budget))
        if abs(la2 - la1) < 1e-6:
            return done(la2, paper_sharpe(la2))
        la0, s0 = la1, s1
        la1, s1 = la2, paper_sharpe(la2)
    return done(la1, s1)


@dataclass
class Lab:
    """A calibrated laboratory: identical market and alpha for every arm."""

    params: SyntheticParams
    market: MarketData
    targets: np.ndarray
    lam_alpha: float
    seed: int
    calibrated_sharpe: float = float("nan")   # achieved on the calibration seed

    @property
    def shape(self) -> tuple[int, int, int]:
        return self.market.shape


def make_lab(
    params: SyntheticParams,
    n_paths: int = 256,
    seed: int = 7,
    calibrate: bool = True,
    target_sharpe: float = 1.0,
    sim_cfg: SimConfig | None = None,
    lam_alpha: float | None = None,
    calib_paths: int = 160,
) -> Lab:
    """Build a calibrated lab. Every scheduler will see exactly these paths."""
    achieved = float("nan")
    if lam_alpha is None:
        if calibrate:
            lam_alpha, achieved = calibrate_lam_alpha(
                params, target_sharpe, n_paths=calib_paths, sim_cfg=sim_cfg,
                return_achieved=True)
        else:
            lam_alpha = params.lam_alpha
    comp = build_components(params, n_paths, seed)
    market, targets = assemble(params, comp, lam_alpha)
    return Lab(
        params=replace(params, lam_alpha=lam_alpha),
        market=market,
        targets=targets,
        lam_alpha=lam_alpha,
        seed=seed,
        calibrated_sharpe=achieved,
    )
