"""Intra-bar execution: how a decided order actually gets filled.

This layer is easy to conflate with scheduling, and the two must be kept
apart. Spreading a portfolio rebalance over several *daily* bars is a
scheduling decision, not an execution algorithm; and a saving written into the
cost model as a constant is an assumption, not a measurement, so an experiment
built on one cannot conclude anything else.

Here a parent order is sliced across sub-bar intervals against a simulated
order flow, and the cost is *measured* as implementation shortfall against the
arrival (decision) price:

    IS(bps) = side * (average fill / arrival price - 1) * 1e4 + spread + fees

    Perold (1988), "The implementation shortfall: paper versus reality",
        Journal of Portfolio Management 14(3), 4-9.
    Almgren & Chriss (2000), "Optimal execution of portfolio transactions",
        Journal of Risk 3(2), 5-39.
    Toth et al. (2011), Physical Review X 1, 021006 (square-root impact).

The trade-off the simulation reproduces is the real one: slicing an order more
finely lowers impact but exposes the order to price drift for longer. Cost and
timing risk move in opposite directions, so "which algorithm is best" is a
question about size and urgency, never a constant.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class IntradayParams:
    """Microstructure environment for one bar."""

    n_slices: int = 13            # sub-intervals per daily bar
    daily_vol: float = 0.02       # per-bar volatility of the asset
    adv: float = 1.0              # average volume per bar, in units/notional
    temp_eta: float = 0.6         # temporary impact coefficient (square-root)
    perm_gamma: float = 0.15      # permanent impact coefficient (linear)
    half_spread_bps: float = 1.0
    fee_bps: float = 0.5
    volume_noise: float = 0.25    # lognormal dispersion of realised volume
    profile: np.ndarray | None = field(default=None)

    def volume_profile(self) -> np.ndarray:
        """Stylised U-shaped intra-bar volume curve, normalised to sum to one.

        An assumption: crypto trades around the clock and has no session open
        or close, so this shape stands in for intra-day liquidity variation in
        general. It is the reason a volume-weighted schedule differs from a
        time-weighted one at all.
        """
        if self.profile is not None:
            p = np.asarray(self.profile, float)
            return p / p.sum()
        x = np.linspace(0.0, 1.0, self.n_slices)
        u = 1.0 + 1.6 * (np.exp(-6.0 * x) + np.exp(-6.0 * (1.0 - x)))
        return u / u.sum()


# ------------------------------------------------------------------ algos


def schedule_fractions(algo: str, params: IntradayParams, urgency: float = 0.6) -> np.ndarray | None:
    """Deterministic slice fractions, or None for volume-reactive algos."""
    M = params.n_slices
    if algo == "market":                       # cross immediately, one slice
        f = np.zeros(M)
        f[0] = 1.0
        return f
    if algo == "twap":                         # equal slices in clock time
        return np.full(M, 1.0 / M)
    if algo == "vwap":                         # slices proportional to expected volume
        return params.volume_profile()
    if algo == "is":                           # Almgren-Chriss: front-loaded
        k = np.arange(M)
        w = np.exp(-urgency * k)
        return w / w.sum()
    if algo == "pov":                          # reacts to realised volume
        return None
    raise ValueError(f"unknown execution algo '{algo}'")


ALGO_LABELS = {
    "market": "Market (immediate fill)",
    "twap": "TWAP (time-weighted)",
    "vwap": "VWAP (volume-profile)",
    "pov": "POV (participation-capped)",
    "is": "IS / Almgren-Chriss (front-loaded)",
}


# ------------------------------------------------------------- simulation


def simulate_execution(
    algo: str,
    participation: float,
    params: IntradayParams | None = None,
    n_sims: int = 4000,
    side: int = 1,
    pov_rate: float = 0.10,
    urgency: float = 0.6,
    seed: int = 0,
) -> dict:
    """Fill one parent order of size `participation` x ADV, `n_sims` times.

    Returns the distribution of implementation shortfall in bps, plus the
    completion rate. Completion is 1 by construction: whatever a participation-
    capped (POV) order has not worked off by the last slice is forced through
    there, which is what produces the POV cost kink for large orders.

    Each slice fills at the price *before* its own permanent impact, as in
    Almgren & Chriss (2000): permanent impact moves the price for later slices,
    the temporary concession is paid on this one, and the first slice fills at
    the arrival price (an immediate market order carries no timing risk).
    """
    params = params or IntradayParams()
    M = params.n_slices
    rng = np.random.default_rng(seed)

    Q = float(participation) * params.adv                 # parent order size
    sigma_slice = params.daily_vol / np.sqrt(M)

    # Realised volume per slice: the expected profile times lognormal noise.
    prof = params.volume_profile()
    noise = rng.lognormal(0.0, params.volume_noise, size=(n_sims, M))
    vol_slice = np.maximum(params.adv * prof[None, :] * noise, 1e-12)

    frac = schedule_fractions(algo, params, urgency)
    shocks = rng.standard_normal((n_sims, M)) * sigma_slice

    price = np.ones(n_sims)                # arrival price normalised to 1.0
    notional = np.zeros(n_sims)
    filled = np.zeros(n_sims)
    remaining = np.full(n_sims, Q)

    for k in range(M):
        if frac is not None:
            x = np.minimum(np.full(n_sims, Q * frac[k]), remaining)
        else:                               # POV: trade a fixed share of flow
            x = np.minimum(pov_rate * vol_slice[:, k], remaining)
        if k == M - 1:                      # complete the order on the last slice
            x = remaining.copy()

        rate = x / vol_slice[:, k]
        temp = params.temp_eta * params.daily_vol * np.sqrt(np.clip(rate, 0, None))
        perm = params.perm_gamma * params.daily_vol * np.clip(rate, 0, None)

        # Fill at the current price plus the temporary concession; then the
        # market moves on its own and our flow leaves its permanent mark, which
        # later slices pay for.
        fill = price * (1.0 + side * temp)
        price = price * (1.0 + shocks[:, k] + side * perm)

        notional += x * fill
        filled += x
        remaining = np.maximum(remaining - x, 0.0)

    avg_fill = notional / np.maximum(filled, 1e-12)
    slip_bps = side * (avg_fill - 1.0) * 1e4
    total_bps = slip_bps + params.half_spread_bps + params.fee_bps

    return {
        "algo": algo,
        "label": ALGO_LABELS.get(algo, algo),
        "participation": float(participation),
        "is_bps_mean": float(total_bps.mean()),
        "is_bps_median": float(np.median(total_bps)),
        "is_bps_std": float(total_bps.std(ddof=1)),     # timing risk
        "is_bps_p95": float(np.percentile(total_bps, 95)),
        "impact_only_bps": float(slip_bps.mean()),
        "completion": float((filled / Q).mean()),
        "samples": total_bps,
    }


def execution_curve(
    algos=("market", "twap", "vwap", "pov", "is"),
    participations=(0.001, 0.005, 0.01, 0.025, 0.05, 0.10, 0.20),
    params: IntradayParams | None = None,
    n_sims: int = 4000,
    seed: int = 0,
    **kw,
) -> pd.DataFrame:
    """Measured cost curve: implementation shortfall vs order size, per algo."""
    rows = []
    for algo in algos:
        for j, part in enumerate(participations):
            # The seed depends on the order size only, never on the algorithm,
            # so at a given size every algorithm faces the *same* price path and
            # the same realised volume. Common random numbers again: the
            # difference between two algorithms is then a paired quantity and
            # far better determined than either cost on its own.
            r = simulate_execution(
                algo, part, params, n_sims=n_sims, seed=seed + j, **kw
            )
            r.pop("samples")
            rows.append(r)
    return pd.DataFrame(rows)


def fit_square_root_law(curve: pd.DataFrame,
                        fixed_bps: float | None = None) -> pd.DataFrame:
    """Fit IS(bps) = a + b * participation^(1/2) per algorithm.

    The fitted `b` is the impact coefficient the portfolio-level cost model
    should use for that algorithm -- so the scheduler layer inherits a cost
    curve that was *measured here* rather than one asserted by a constant.

    Pass `fixed_bps` to pin the intercept to the cost that is known by
    construction (half-spread plus fee) and fit the impact term alone. Leaving
    it free lets the intercept absorb the curvature the square root does not
    capture over the fitted range, which can drive it negative -- arithmetically
    fine, but it is not a "fixed cost" any more, and reporting it as one
    invites exactly the wrong question.
    """
    rows = []
    for algo, g in curve.groupby("algo", sort=False):
        x = np.sqrt(g["participation"].to_numpy(float))
        y = g["is_bps_mean"].to_numpy(float)
        if fixed_bps is None:
            A = np.column_stack([np.ones_like(x), x])
            coef, *_ = np.linalg.lstsq(A, y, rcond=None)
            a, b = float(coef[0]), float(coef[1])
        else:
            a = float(fixed_bps)
            b = float(np.linalg.lstsq(x[:, None], y - a, rcond=None)[0][0])
        pred = a + b * x
        ss_res = float(((y - pred) ** 2).sum())
        ss_tot = float(((y - y.mean()) ** 2).sum())
        rows.append({
            "algo": algo,
            "label": ALGO_LABELS.get(algo, algo),
            "fixed_bps": a,
            "fixed_cost_pinned": fixed_bps is not None,
            "impact_bps_per_sqrt_participation": b,
            "r2": 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan,
        })
    return pd.DataFrame(rows)


def savings_vs_baseline(curve: pd.DataFrame, baseline: str = "market") -> pd.DataFrame:
    """Cost saving in bps of each algo against the naive immediate fill, and
    the timing risk it takes on in exchange."""
    base = curve[curve["algo"] == baseline].set_index("participation")
    rows = []
    for algo, g in curve.groupby("algo", sort=False):
        if algo == baseline:
            continue
        g = g.set_index("participation")
        for part in g.index:
            rows.append({
                "algo": algo,
                "label": ALGO_LABELS.get(algo, algo),
                "participation": part,
                "IS bps": g.loc[part, "is_bps_mean"],
                "Baseline bps": base.loc[part, "is_bps_mean"],
                "Saving bps": base.loc[part, "is_bps_mean"] - g.loc[part, "is_bps_mean"],
                "Timing risk bps": g.loc[part, "is_bps_std"],
                "Baseline timing risk bps": base.loc[part, "is_bps_std"],
            })
    return pd.DataFrame(rows)
