"""Build FYP_upload.zip for the Lumid workflow (run from anywhere: python lumid/make_upload_zip.py).

Uses forward slashes inside the zip (Windows' Compress-Archive writes backslashes, which Linux
cannot unpack into folders), keeps the market-data cache so the study runs offline, and leaves
out generated results, which the workflow rebuilds.
"""
import os
import zipfile

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(os.path.dirname(SRC), "FYP_upload.zip")
SKIP_DIRS = {"__pycache__", ".ipynb_checkpoints", "artifacts_sandbox", "artifacts_quick", ".git"}
SKIP_EXT = (".pyc", ".aux", ".log", ".out")

n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel = os.path.relpath(root, SRC).replace("\\", "/")
        if rel == "artifacts":                      # ship only the data cache
            dirs[:] = [d for d in dirs if d == "cache"]
            continue
        for f in files:
            if f.endswith(SKIP_EXT):
                continue
            arc = "FYP/" + ("" if rel == "." else rel + "/") + f
            z.write(os.path.join(root, f), arc)
            n += 1
print(f"{OUT}: {n} files, {os.path.getsize(OUT) / 1e6:.1f} MB")
