# What this project does, in plain words

## 1. The problem

You have a signal that tells you which portfolio to hold. The signal keeps changing.

- **Every time you trade** to follow it, you pay fees and move the price against yourself.
- **Every time you don't**, you are holding the wrong portfolio and missing some of the profit.

So every trading system has to answer two questions:

1. **When** should I trade?
2. When I do, **how far** should I move: all the way to the new target, or part of the way?

## 2. The two ways to decide "when"

| | How it decides | Everyday analogy |
|---|---|---|
| **Open loop** (clock) | Trade every day / week / month, no matter what | A heater on a timer |
| **Closed loop** (feedback) | Trade only when my portfolio has drifted far enough from the target | A thermostat |
| **Partial moves** (feedback in *how far*) | Trade every day, but close only part of the gap | A dimmer |

**The hypothesis:** the thermostat beats the timer. Rules that look at how wrong the
portfolio currently is should earn more after costs than rules that trade on a schedule.

**What it turned out to be about.** Every rule makes *two* choices: **when** to trade and
**how far** to move. The study found the gain is almost all in the second. But "how far
each day" is itself a kind of timing: closing a quarter of the gap every day spreads one
rebalance over several days, like buying a position in instalments instead of all at
once. So there are two kinds of timing:

- **Pacing the trade** (the dimmer): spread each move over several days. **This works.**
- **Picking the moment** (the thermostat): wait for the right moment, then trade it all.
  **This adds nothing** - unless every order carries a fixed fee.

Moving only part of the way is a known idea (Garleanu and Pedersen 2013), so what is new
here is what the comparisons say about the two kinds of timing - see section 7.

## 3. Why a fair test is hard, and the two fixes

| Trap | Why it misleads | Fix used here |
|---|---|---|
| A rule that simply trades less looks better when costs are high | You'd be measuring "trade less", not "trade smarter" | Compare timing rules against a clock rule that trades **exactly as much**; elsewhere, give both sides the same trading budget, or let both choose their best trading level |
| A rule might look good because its signal got lucky | You'd be measuring luck, not the rule | Every rule gets the **same signal**, with a known quality (Sharpe 1.0 if traded for free) |

## 4. The steps

**Step 1 - Build a fake market where the truth is known.**
On real data you can't tell skill from luck. So the program generates 256 artificial
4-year price histories for 6 assets, with a hidden signal whose quality is set exactly:
trading it perfectly and for free earns a Sharpe ratio of 1.0.

**Step 2 - Race about 77 trading rules on the same fake histories.**
Calendar rules, volume rules, "trade when the price moves a lot" rules (CUSUM),
"trade when I'm too far off" rules (no-trade bands), and "move only part of the way"
rules (partial adjustment). Each rule's setting is chosen on some histories and scored on
different ones, so nothing is picked with hindsight.

**Step 3 - Measure what a trade really costs.**
A big order is split into small pieces through the day (TWAP, VWAP and so on), and the
cost is measured against the price when the order started, rather than assumed.

**Step 4 - Ask whether real data could even show the effect.**
Before testing on BTC/ETH, calculate the smallest improvement one price history can
reliably detect. For BTC/ETH the possible cost saving is far smaller than that, which is
why the main test (Step 1) is simulated.

**Step 5 - Check on real BTC and ETH prices.**
Run the same rules on real BTC/ETH history. Choose each rule's setting on the first half
(2017-2021) and score it on the second half (2021-2024). Use two signals:
- a **controlled** signal that peeks at the future on purpose, so its quality is known
  (a measuring tool, not a strategy);
- a plain **momentum** signal (buy what went up over the last 20 days) with no peeking.

**Step 5b - Check again on brand-new data.**
Freeze every choice made in Step 5 and score the rules on BTC/ETH data from 2025-01-01 to
2026-10-10 - data that did not exist when the choices were made. It is the strictest
real-data check in the study, but because it was added after the results were known it
is reported as evidence, not scored as a pass/fail test.

**Step 6 - Test where the advantage should appear.**
The theory makes predictions that could fail: the advantage should grow when news
arrives in bursts, and price-based triggers should work better when news shows up in
the price. If these don't hold, the story is wrong even if the rule wins.
It also re-checks the one place where picking the moment seemed to help, on 256 brand-new
histories: the advantage shrank from +0.12 to +0.05 and could be luck.

**Step 6b - When does "when" matter? Change only the shape of the costs.**
Three cost shapes that charge the same for a typical trade but differ for big and small
ones: a flat rate (*proportional*), the usual *square-root* impact, and *linear* impact
(big trades very expensive). Then add a fixed fee for every order (0, 0.1 or 0.5 bps of
the portfolio; 0.5 bps is $5 a ticket on a $100k book). Theory says: the more big trades
are penalised, the more "move part of the way" should win; a fee per order should favour
trading rarely, which is where picking the moment could finally help.

**Step 7 - Head to head, and split the gain in two.**
Compare our best rule with **AlwaysTrade** (trade every time the signal changes). Then
split the gain into:
- **WHEN**: our rule vs. the same rule firing at **random** times (a placebo);
- **HOW FAR**: the gain from moving only part of the way.

**Step 7b - Every timing rule x every move size.**
Take five timing rules (calendar, volume, price move, target move, "too far off" band) and
run each moving all the way, half the way and a quarter of the way: 141 rules. Then ask
two clean questions: keeping the move size fixed, does the timing rule matter? Keeping the
timing rule fixed, does the move size matter?

Steps 6b and 7b were added after the pass/fail tests were scored, to explain the result.
They are reported as findings, never as pass/fail tests.

**Step 8 - Score five pass/fail tests.**
Four were written down before the results, so the goalposts can't move. The fifth (C4, the
real-data check) was reworded when the study was narrowed to BTC/ETH, after earlier crypto
results were known, so it counts as a post-hoc check.

## 5. The data

| | Simulated market (Steps 1-3, 6, 6b, 7, 7b) | Real data (Steps 5, 5b) |
|---|---|---|
| What | 256 artificial histories, 6 assets | BTC-USD and ETH-USD |
| Source | Generated by the code | Yahoo Finance (free, no key) |
| Period | 4 years of daily bars each | 2017-11-09 to 2024-12-31, plus a fresh holdout to 2026-10-10 |
| Fields | Prices, volume, the hidden signal | Daily close and daily volume |
| Trading cost | 0.5 bps fee + 1 bp half-spread + impact | 2 bps fee + 2 bps half-spread + impact |

*1 bp (basis point) = 0.01%. Impact = the extra cost of a large trade pushing the price;
it grows with the square root of the trade's share of the day's volume.*

## 6. Key assumptions

1. Trades decided at one day's close are filled at the next day's close.
2. Costs are a fixed fee and spread plus modelled impact, not real bid/ask quotes.
3. The book is $10m, scaled to 15% annual volatility. In the simulated market, weights are
   proportional to the signal across 6 assets; on BTC/ETH it is long one coin and short the
   other, sized by risk parity.
4. Shorting is free (no borrow or funding cost).
5. Yahoo's BTC/ETH price is treated as the tradable price.
6. With two assets, momentum is simply "long the stronger coin, short the weaker".

## 7. What it found

**3 of the 5 pass/fail tests passed** (one of the three, C4, is post-hoc). In plain words:

| Finding | Number | Meaning |
|---|---|---|
| Feedback rules beat clock rules at every trading budget | 5 of 5 budgets, +0.20 Sharpe (median) | Feedback wins (the best feedback rules move part of the way) |
| Best rule vs. AlwaysTrade (simulated) | 0.89 vs 0.78 Sharpe, 58% less trading | Less trading **and** more profit |
| Where the gain comes from | WHEN: +0.002 &nbsp; HOW FAR: +0.111 | Almost all the gain is from **pacing the trade** (moving part of the way each day), not from picking the moment |
| Picking the moment alone, at equal trading | +0.006 (no significant difference) | A plain calendar is already a good timer |
| Beats random timing? | p = 0.066 | Just misses the 0.05 bar (**fail**). A weak fail: only 7 of 120 random schedules did as well, but with so few draws that share is uncertain (0.03 to 0.12) |
| Mechanism predictions | Burstiness effect went the wrong way | The "why" story is not confirmed (**fail**) |
| Real BTC/ETH, controlled signal | 1.06 vs -0.72 Sharpe, 85% less trading | Large win over AlwaysTrade, statistically clear |
| Real BTC/ETH, momentum signal | -0.35 vs -0.48 Sharpe | Smaller loss than AlwaysTrade, but within noise |
| **Fresh 2025-26 data, rules frozen since 2021** | 0.98 vs -0.08 (controlled), 0.92 vs 0.12 (momentum), against trading on every change | Still working in recent years; both wins are statistically clear |
| Real BTC/ETH vs. a calendar picked the same way | 1.06 vs 0.58 (controlled), -0.35 vs -0.42 (momentum) | Ahead on both, but within the noise of one price path; with hindsight some calendars did better |

**What the comparisons add** (Steps 6, 6b, 7, 7b; findings, not pass/fail tests):

| Finding | Number | Meaning |
|---|---|---|
| Keep the move size fixed, change the timing rule | -0.007, -0.006, -0.002 (all moves, half, quarter) | **Picking the moment does not matter**, at any move size |
| Keep the timing rule fixed, move part of the way | +0.107 to +0.114, for all 5 timing rules | **Pacing always matters**, by the same amount |
| Best "part of the way" version of each timing rule | trades on 75-98% of days | Once moves are small, every timing rule turns into "trade almost every day" |
| A trigger vs random times, vs a calendar | +0.052 vs random; -0.001 vs calendar | Beating random timing is easy; a regular calendar is already a good timer |
| Move size, by cost shape (no fee) | +0.03 flat, +0.12 square-root, +0.44 linear | The more big trades cost, the more moving part of the way is worth |
| With a $5-a-ticket fee | move size worth -0.03 / 0.00 / +0.26; timing up to +0.09 | A fee per order is what makes picking the moment start to matter |

**The one-line conclusion:** feedback beats the timer, but the timing that pays is the
**dimmer** (pacing: moving part of the way every day), not the **thermostat** (picking the
moment to switch) - for every timing rule tested. That holds because big trades cost more
per dollar than small ones and placing an order is cheap; if every order carried a sizeable
fixed fee, picking the moment would start to matter again.

**What to do with it.** Don't trade a strategy's signal blindly - all the way, every time it
changes. Pace each rebalance, and set the pace from what trading costs you (fees, spread,
and price impact, which depends on how big your trade is against the day's volume) and from
how fast the signal goes stale. Choose it on past data, then freeze it.

## 8. Glossary

| Term | Meaning |
|---|---|
| **Alpha / signal** | The forecast that says which portfolio to hold |
| **Target / paper portfolio** | What you'd hold if trading were free and instant |
| **Sharpe ratio** | Return divided by risk; higher is better; 1.0 is good |
| **Net Sharpe** | Sharpe after paying trading costs |
| **Turnover** | How much you trade per year, as multiples of the portfolio's value |
| **Out of sample** | Scored on data that wasn't used to choose the settings |
| **Placebo** | A fake version of the rule (random timing) to check the real one isn't luck |
| **Trigger / move fraction** | The two choices every rule makes: what makes it trade (when), and what share of the gap it closes (how far) |
| **Cost shape** | How the cost of a trade grows with its size: flat (proportional), square-root, or linear impact |
| **Fee per order** | A fixed charge every time an order is placed, however small |
| **Confidence interval** | The range the true answer probably lies in; if it excludes zero, the effect is unlikely to be chance |
