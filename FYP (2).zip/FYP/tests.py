"""Invariant tests. Run with `python -m FYP.tests` (or pytest).

Every defect that matters in a backtest is silent. A risk-parity solver that
returns 1/N, weights that never drift, a wiped-out path that keeps trading, an
execution saving that was written in rather than measured - none of these raise
an error. The numbers simply mean something other than what the labels claim.
Each test below pins one such property down so it cannot drift.
"""
from __future__ import annotations

import numpy as np

from .alpha import build_market
from .core import MarketData, SimConfig, paper_portfolio, simulate
from .costs import CostModel, equal_cost_shapes
from .evaluation import (ArmStats, annualised_sharpe, arm_stats, decompose,
                         select_by_budget)
from .generator import SyntheticParams, make_lab
from .portfolio import risk_parity_cov
from .schedulers import (AlwaysTrade, BuyAndHold, Calendar, NoTradeBand,
                         PartialAdjustment, PriceCUSUM, default_zoo, factorial_zoo)

FREE = CostModel(fee_bps=0.0, half_spread_bps=0.0, enable_impact=False)
FLAT = CostModel(fee_bps=2.0, half_spread_bps=3.0, enable_impact=False)


def _toy_market(S=2, T=60, N=3, seed=0) -> tuple[MarketData, np.ndarray]:
    rng = np.random.default_rng(seed)
    r = rng.standard_normal((S, T, N)) * 0.01
    ones = np.ones_like(r)
    market = MarketData(returns=r, z_returns=r / 0.01,
                        dollar_volume=ones * 1e9, adv=ones * 1e9, vol=ones * 0.01)
    base = np.linspace(0.5, 0.2, N)
    targets = np.tile(base / base.sum(), (S, T, 1))
    return market, targets


# ---------------------------------------------------------------- no look-ahead


def test_no_lookahead():
    """Perturbing the future must not change the past.

    The strongest available check on leakage: build two markets that agree up
    to bar k and differ afterwards, and require every result up to k to be
    bit-identical.
    """
    market, targets = _toy_market(S=4, T=80, N=3, seed=1)
    k = 40
    rng = np.random.default_rng(99)
    future = MarketData(
        returns=market.returns.copy(), z_returns=market.z_returns.copy(),
        dollar_volume=market.dollar_volume.copy(), adv=market.adv.copy(),
        vol=market.vol.copy(),
    )
    for arr in (future.returns, future.z_returns, future.dollar_volume,
                future.adv, future.vol):
        arr[:, k + 1:, :] += rng.standard_normal(arr[:, k + 1:, :].shape) * 0.05

    for sched in (AlwaysTrade(), Calendar(7), PriceCUSUM(1.0), NoTradeBand(0.1),
                  PartialAdjustment(0.3)):
        a = simulate(market, targets, sched, FLAT)
        b = simulate(future, targets, sched, FLAT)
        assert np.array_equal(a.net_returns[:, :k + 1], b.net_returns[:, :k + 1]), \
            f"{sched.name}: future data leaked into the past"
        assert np.array_equal(a.turnover[:, :k + 1], b.turnover[:, :k + 1]), \
            f"{sched.name}: future data changed past turnover"


def test_execution_lag_is_one_bar():
    """A decision at close_t is filled at close_{t+1} and earns from t+2."""
    market, targets = _toy_market(S=1, T=30, N=2, seed=2)
    targets[:] = 0.0
    targets[:, 10:, :] = 0.5            # target appears at bar 10

    class OnlyAtTen(Calendar):
        force_initial = False

        def __init__(self):
            super().__init__(1)

        def _trigger(self, t, w_now, target, market):
            return np.full(w_now.shape[0], t == 10, dtype=bool)

    res = simulate(market, targets, OnlyAtTen(), FREE, SimConfig(exec_lag=1),
                   name="x")
    traded = np.flatnonzero(res.turnover[0] > 0)
    assert traded.tolist() == [11], f"expected a single fill at bar 11, got {traded}"
    assert res.gross_returns[0, 11] == 0.0, "position earned before it was filled"
    assert res.gross_returns[0, 12] != 0.0, "position did not earn after filling"


# -------------------------------------------------------------------- accounting


def test_buy_and_hold_tracks_the_asset():
    """One asset, fully invested, never traded: NAV must equal the price path.

    Holding weights constant instead of letting them drift is only correct for
    a single asset, and for more than one it silently grants free rebalancing.
    """
    rng = np.random.default_rng(3)
    r = rng.standard_normal((1, 50, 1)) * 0.02
    ones = np.ones_like(r)
    market = MarketData(returns=r, z_returns=r / 0.02, dollar_volume=ones * 1e9,
                        adv=ones * 1e9, vol=ones * 0.02)
    targets = np.ones((1, 50, 1))
    res = simulate(market, targets, BuyAndHold(), FREE)
    entry = int(np.flatnonzero(res.turnover[0] > 0)[0])
    price = np.cumprod(1 + r[0, :, 0])
    expected = price[-1] / price[entry]
    assert abs(res.nav[0, -1] - expected) < 1e-10, \
        f"NAV {res.nav[0, -1]:.8f} != asset return {expected:.8f}"


def test_weights_drift_between_rebalances():
    """Between trades the book must drift with prices, not stay pinned."""
    market, targets = _toy_market(S=1, T=40, N=2, seed=4)
    market.returns[0, :, 0] = 0.05        # asset 0 rallies every bar
    market.returns[0, :, 1] = -0.02
    res = simulate(market, targets, Calendar(100), FREE,
                   SimConfig(store_weights=True))
    w = res.weights[0]
    assert w[5, 0] < w[-1, 0], "winner's weight did not grow between rebalances"
    assert abs(w[-1].sum() - 1.0) < 1e-9, "weights stopped summing to one"


def test_cost_equals_turnover_times_rate():
    """With proportional costs only, cost must equal turnover x rate exactly."""
    market, targets = _toy_market(S=3, T=50, N=3, seed=5)
    res = simulate(market, targets, Calendar(5), FLAT)
    expected = res.turnover * FLAT.linear_bps * 1e-4
    assert np.allclose(res.cost, expected), "cost is not turnover x rate"
    assert np.allclose(res.net_returns, res.gross_returns - res.cost), \
        "net is not gross minus cost"


def test_no_trade_means_no_turnover():
    """A scheduler that declines to act must not generate drift-turnover.

    Turnover has to be measured against the *drifted* book; measuring it
    against the previous target invents trades that never happened.
    """
    market, targets = _toy_market(S=2, T=40, N=3, seed=6)
    res = simulate(market, targets, Calendar(1000), FLAT)
    # Bar 1 carries the initial fill of the decision made at bar 0; after that
    # the scheduler never acts again, so nothing may appear.
    assert (res.turnover[:, 2:] == 0).all(), "turnover appeared without a trade"
    assert (res.cost[:, 2:] == 0).all(), "cost appeared without a trade"
    assert (res.turnover[:, 1] > 0).all(), "the initial position was never established"


def test_ruin_is_absorbing():
    """A wiped-out path stays wiped out: no book, no trades, no returns.

    The subtle failure this pins down: an order decided on the bar before ruin
    is already queued, and if it is allowed to fill the path re-acquires a
    full-size book on a NAV of zero and goes on reporting returns - and a
    perfectly respectable Sharpe ratio - for the rest of the sample.
    """
    r = np.zeros((1, 20, 1))
    r[0, 5, 0] = -0.9
    r[0, 6, 0] = -0.9                     # -99% cumulative on a 12x long book
    r[0, 8:, 0] = 0.05                    # a rally a dead path must not enjoy
    ones = np.ones_like(r)
    market = MarketData(returns=r, z_returns=r, dollar_volume=ones * 1e9,
                        adv=ones * 1e9, vol=ones * 0.5)
    targets = np.full((1, 20, 1), 12.0)   # extreme leverage, on purpose
    res = simulate(market, targets, AlwaysTrade(), FREE,
                   SimConfig(max_gross=12.0, store_weights=True))
    ruin_bar = int(np.flatnonzero(res.nav[0] <= 0.0)[0])
    assert res.nav[0, -1] == 0.0, "ruined path did not stay at zero"
    assert (res.turnover[0, ruin_bar + 1:] == 0).all(), "ruined path kept trading"
    assert (res.net_returns[0, ruin_bar + 1:] == 0).all(), \
        "ruined path kept earning returns on a NAV of zero"
    assert (res.weights[0, ruin_bar:] == 0).all(), "ruined path re-acquired a book"
    assert np.isfinite(res.net_returns).all(), "ruin produced non-finite returns"
    assert annualised_sharpe(res.net_returns)[0] <= 0 or np.isnan(
        annualised_sharpe(res.net_returns)[0]), "a dead path reported a positive Sharpe"


def test_total_loss_does_not_fabricate_a_position():
    """A bar that wipes the book must not leave a position behind.

    Dividing the drifted weights by a clamped 1+return would manufacture a
    book ~1e6 times too large, and the turnover and cost measured against it
    would be nonsense while the truncated return still looked sane.
    """
    r = np.zeros((1, 10, 1))
    r[0, 3, 0] = -1.0                      # instant total loss on a long book
    ones = np.ones_like(r)
    market = MarketData(returns=r, z_returns=r, dollar_volume=ones * 1e9,
                        adv=ones * 1e9, vol=ones * 0.5)
    targets = np.ones((1, 10, 1))
    res = simulate(market, targets, AlwaysTrade(), FLAT)
    assert res.turnover.max() <= 2.0 + 1e-9, \
        f"fabricated turnover of {res.turnover.max():.1f}x NAV"
    assert res.cost.max() <= 1.0, f"fabricated cost of {res.cost.max():.1f} of NAV"
    assert np.isfinite(res.nav).all()
    assert res.net_returns[0, 3] <= -1.0 + 1e-9, \
        "the bar that wiped the book out was not recorded as a total loss"


def test_a_rule_that_never_trades_is_not_scored_zero():
    """A do-nothing arm must be undefined, not 0.0.

    Scoring it zero would rank it above every rule that genuinely lost money,
    and a knob-selection that maximises Sharpe would then hand a whole family's
    frontier point to an arm that holds nothing.
    """
    market, targets = _toy_market(S=3, T=40, N=3, seed=8)
    dead = NoTradeBand(99.0)               # wider than any achievable gap
    res = simulate(market, targets, dead, FLAT)
    assert res.turnover.sum() == 0.0, "the control arm traded after all"
    assert np.isnan(annualised_sharpe(res.net_returns)).all(), \
        "a constant return series was given a finite Sharpe"
    from .evaluation import selection_score
    assert selection_score(annualised_sharpe(res.net_returns)) == -np.inf, \
        "an undefined arm could still win a selection"


# --------------------------------------------------------------------- sizing


def test_risk_parity_equalises_risk_contributions():
    rng = np.random.default_rng(7)
    for n in (3, 5, 9):
        a = rng.standard_normal((300, n))
        cov = np.cov(a, rowvar=False) * np.outer(np.linspace(1, 4, n),
                                                 np.linspace(1, 4, n))
        w = risk_parity_cov(cov)
        rc = w * (cov @ w)
        assert abs(rc.max() / rc.min() - 1) < 1e-6, f"n={n}: risk not equalised"
        assert abs(w.sum() - 1) < 1e-10 and (w > 0).all()


def test_risk_parity_equals_inverse_vol_for_two_assets():
    """Not a bug -- a fact: on BTC and ETH alone, risk parity *is*
    inverse-volatility, so the real-data leg cannot tell the two allocators
    apart. Only the six-asset lab can."""
    for rho in (-0.5, 0.0, 0.3, 0.9):
        sd = np.array([0.2, 0.35])
        cov = np.array([[sd[0] ** 2, rho * sd[0] * sd[1]],
                        [rho * sd[0] * sd[1], sd[1] ** 2]])
        w = risk_parity_cov(cov)
        iv = (1 / sd) / (1 / sd).sum()
        assert np.allclose(w, iv, atol=1e-8), f"rho={rho}: ERC != inverse-vol"


# ----------------------------------------------------------------- lab & stats


def test_lab_is_calibrated_to_sharpe_one():
    params = SyntheticParams(n_bars=756, n_assets=4)
    lab = make_lab(params, n_paths=96, seed=11)
    s = annualised_sharpe(paper_portfolio(lab.market, lab.targets).net_returns)
    se = s.std(ddof=1) / np.sqrt(s.size)
    assert abs(s.mean() - 1.0) < max(4 * se, 0.15), \
        f"paper Sharpe {s.mean():.3f} is not 1.0 (se {se:.3f})"


def test_common_random_numbers_are_shared():
    """Every arm must see identical prices: that is what makes the paired
    comparison valid."""
    params = SyntheticParams(n_bars=300, n_assets=3)
    lab = make_lab(params, n_paths=8, seed=12, calibrate=False)
    cfg = SimConfig(store_weights=True)
    r = lab.market.returns
    for sched in (Calendar(3), PartialAdjustment(0.4)):
        res = simulate(lab.market, lab.targets, sched, FLAT, cfg)
        # Each bar's gross return must be the book held into that bar priced
        # off the one shared return array - i.e. every arm sees the same prices.
        implied = (res.weights[:, :-1, :] * r[:, 1:, :]).sum(axis=2)
        assert np.allclose(res.gross_returns[:, 1:], implied), \
            f"{sched.name} was not priced off the shared market"
    assert lab.market.returns.shape == (8, 300, 3)


def test_decomposition_is_additive():
    params = SyntheticParams(n_bars=400, n_assets=4)
    lab = make_lab(params, n_paths=16, seed=13, calibrate=False)
    paper = arm_stats(paper_portfolio(lab.market, lab.targets))
    for sched in (Calendar(5), NoTradeBand(0.2), PartialAdjustment(0.3)):
        arm = arm_stats(simulate(lab.market, lab.targets, sched, FLAT))
        d = decompose(arm, paper)
        total = d["Net Sharpe"] + d["Cost drag"] + d["Tracking loss"]
        assert abs(total - d["Paper Sharpe"]) < 1e-9, "decomposition does not close"


def test_budget_selection_respects_the_budget():
    params = SyntheticParams(n_bars=400, n_assets=4)
    lab = make_lab(params, n_paths=20, seed=14, calibrate=False)
    arms = [arm_stats(simulate(lab.market, lab.targets, s, FLAT))
            for s in default_zoo()]
    calib, ev = np.arange(10), np.arange(10, 20)
    sel = select_by_budget(arms, np.array([5.0, 20.0]), calib, ev)
    for family, rows in sel.items():
        for row in rows:
            arm = next(a for a in arms if a.name == row["Scheduler"])
            assert arm.turnover[calib].mean() <= row["Budget"] + 1e-9, \
                f"{family}: selected an arm above its turnover budget"


def test_simulation_is_deterministic():
    params = SyntheticParams(n_bars=300, n_assets=3)
    lab = make_lab(params, n_paths=8, seed=15, calibrate=False)
    for sched_factory in (lambda: PriceCUSUM(1.5), lambda: PartialAdjustment(0.25)):
        a = simulate(lab.market, lab.targets, sched_factory(), FLAT)
        b = simulate(lab.market, lab.targets, sched_factory(), FLAT)
        assert np.array_equal(a.net_returns, b.net_returns), "run is not reproducible"


def test_more_trading_costs_more():
    params = SyntheticParams(n_bars=500, n_assets=4)
    lab = make_lab(params, n_paths=12, seed=16, calibrate=False)
    costs = [simulate(lab.market, lab.targets, Calendar(k), FLAT).cost.sum()
             for k in (1, 5, 21, 63)]
    assert costs == sorted(costs, reverse=True), "cost is not monotone in frequency"


# ------------------------------------------------------- when x how far axes


def test_partial_calendar_is_partial_adjustment():
    """The recommended rule has a clock trigger: a calendar firing every bar
    and moving lam of the way must be partial adjustment, bit for bit."""
    params = SyntheticParams(n_bars=300, n_assets=3)
    lab = make_lab(params, n_paths=6, seed=17, calibrate=False)
    a = simulate(lab.market, lab.targets, Calendar(1, lam=0.25), FLAT)
    b = simulate(lab.market, lab.targets, PartialAdjustment(0.25, min_trade=0.0), FLAT)
    assert np.array_equal(a.net_returns, b.net_returns),         "Calendar(1, lam) and PartialAdjustment(lam) disagree"


def test_every_rule_names_its_two_decisions():
    """Every scheduler states its trigger (when) and move fraction (how far),
    a rule that moves all the way keeps its old name, and the factorial has
    no duplicates."""
    triggers = {"clock", "activity", "price-event", "target-event", "gap",
                "random", "once"}
    for s in default_zoo() + factorial_zoo():
        assert s.trigger in triggers, f"{s.name}: unknown trigger {s.trigger!r}"
        f = s.move_fraction
        assert f is None or 0.0 < f <= 1.0, f"{s.name}: move fraction {f}"
        assert s.moves_fully == (f is not None and f >= 1.0), f"{s.name}: moves_fully"
        if s.moves_fully:
            assert "-lam" not in s.name, f"{s.name}: full move renamed"
    names = [s.name for s in factorial_zoo()]
    assert len(names) == len(set(names)), "factorial zoo has duplicate names"
    assert PartialAdjustment(0.25).trigger == "clock", "partial adjustment is clock-timed"


def test_order_fee_is_charged_once_per_order():
    cm = CostModel(fee_bps=0.0, half_spread_bps=0.0, enable_impact=False,
                   order_fee_bps=2.0)
    dw = np.array([[0.1, 0.0, -0.2],      # two orders
                   [0.0, 0.0, 0.0],       # none
                   [1e-12, 0.0, 0.0]])    # dust is not an order
    got = cm.trade_cost(dw, 1e7)
    assert np.allclose(got, [4e-4, 0.0, 0.0]), f"order fee charged wrongly: {got}"


def test_cost_shapes_agree_at_the_typical_trade():
    """The three shapes of phase 6b charge the same at the typical trade, so
    only the shape differs: below it linear impact is cheapest, above it the
    proportional rate is."""
    base = CostModel(fee_bps=0.5, half_spread_bps=1.0, impact_eta=0.5)
    p, sig = 6e-4, 0.02
    shapes = equal_cost_shapes(base, p, sig)
    at = {k: m.effective_bps(p, sig) for k, m in shapes.items()}
    assert np.allclose(list(at.values()), at["square-root"]), f"unequal at typical: {at}"
    small = {k: m.effective_bps(p / 4, sig) for k, m in shapes.items()}
    big = {k: m.effective_bps(4 * p, sig) for k, m in shapes.items()}
    assert small["linear impact"] < small["square-root"] < small["proportional"]
    assert big["proportional"] < big["square-root"] < big["linear impact"]


def test_equal_turnover_reference_is_exact_at_its_knots():
    """A candidate trading exactly as much as a reference knob is compared
    with that knob, and a copy of the reference scores zero."""
    from .phases import compare_at_equal_turnover

    def arm(name, turn, sharpe):
        n = len(sharpe)
        z = np.zeros(n)
        return ArmStats(name, "clock", None, np.asarray(sharpe, float), z, z, z, z,
                        np.full(n, float(turn)), z, z)

    refs = [arm("r1", 5.0, [0.1, 0.2, 0.3, 0.4]), arm("r2", 20.0, [0.5, 0.6, 0.7, 0.8])]
    calib, ev = np.arange(2), np.arange(2, 4)
    copy = compare_at_equal_turnover([arm("c", 20.0, [0.5, 0.6, 0.7, 0.8])], refs, calib, ev)
    assert np.allclose(copy.base, refs[1].net_sharpe) and abs(copy.diff.mean) < 1e-12
    mid = compare_at_equal_turnover([arm("m", 10.0, [1.0] * 4)], refs, calib, ev)
    w = np.log(10 / 5) / np.log(20 / 5)                   # log-turnover weight
    want = (1 - w) * refs[0].net_sharpe + w * refs[1].net_sharpe
    assert np.allclose(mid.base, want), "interpolation is not linear in log turnover"


# ------------------------------------------------------------------- execution


def test_execution_algos_are_ordered_and_measured():
    """Slower schedules must cost less and carry more timing risk."""
    from .microstructure import IntradayParams, execution_curve
    curve = execution_curve(algos=("market", "twap", "vwap"),
                            participations=(0.02, 0.1), n_sims=3000,
                            params=IntradayParams(daily_vol=0.02), seed=3)
    for part in (0.02, 0.1):
        g = curve[curve["participation"] == part].set_index("algo")
        for algo in ("twap", "vwap"):
            assert g.loc[algo, "is_bps_mean"] < g.loc["market", "is_bps_mean"], \
                f"{algo}: slicing did not reduce cost"
            assert g.loc[algo, "is_bps_std"] > g.loc["market", "is_bps_std"], \
                f"{algo}: slicing did not increase timing risk"


def test_real_market_builder_has_no_lookahead():
    """The trailing statistics on real data must not peek at bar t or later -
    including during the warm-up, where back-filling would leak the future."""
    import pandas as pd
    idx = pd.date_range("2020-01-01", periods=120, freq="D")
    rng = np.random.default_rng(17)
    px = pd.DataFrame(100 * np.cumprod(1 + rng.standard_normal((120, 3)) * 0.01, axis=0),
                      index=idx, columns=["A", "B", "C"])
    vol = pd.DataFrame(1e6, index=idx, columns=["A", "B", "C"])
    base = build_market(px, vol)
    for k in (10, 60):                        # inside and after the warm-up
        px2 = px.copy()
        px2.iloc[k:] *= 1.5                   # change bar k and everything after
        pert = build_market(px2, vol)
        assert np.allclose(base.vol[0, :k + 1], pert.vol[0, :k + 1]), \
            f"volatility estimate up to bar {k} used bar {k} or later"
        assert np.allclose(base.adv[0, :k + 1], pert.adv[0, :k + 1]), \
            f"liquidity estimate up to bar {k} used bar {k} or later"


def test_crypto_volume_is_counted_once():
    """Yahoo reports crypto volume in dollars. After conversion to coins, the
    market builder's volume x price must give back Yahoo's dollar figure, not
    dollars x price."""
    import pandas as pd
    from .data import dollar_volume_to_units
    idx = pd.date_range("2024-01-01", periods=40, freq="D")
    px = pd.DataFrame({"BTC-USD": 60_000.0, "ETH-USD": 3_000.0}, index=idx)
    usd = pd.DataFrame({"BTC-USD": 3e10, "ETH-USD": 1.5e10}, index=idx)
    m = build_market(px, dollar_volume_to_units(usd, px))
    assert np.allclose(m.dollar_volume[0], usd.to_numpy()),         "dollar volume was multiplied by price twice"


# ------------------------------------------------------------------- runner


def main() -> int:
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = []
    for fn in tests:
        try:
            fn()
            print(f"  PASS  {fn.__name__}")
        except AssertionError as exc:
            failures.append((fn.__name__, str(exc)))
            print(f"  FAIL  {fn.__name__}: {exc}")
        except Exception as exc:                      # pragma: no cover
            failures.append((fn.__name__, repr(exc)))
            print(f"  ERROR {fn.__name__}: {exc!r}")
    print(f"\n{len(tests) - len(failures)}/{len(tests)} passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
