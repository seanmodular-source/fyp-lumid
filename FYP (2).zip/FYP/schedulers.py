"""The scheduler zoo: *when to trade* and *how far to move*.

Every rebalancing rule is two decisions, and every scheduler here exposes both
as attributes so they can be varied one at a time:

  trigger        WHEN to trade     clock, activity, price-event, target-event,
                                   gap (the book is far enough from target),
                                   random, once
  move_fraction  HOW FAR to move   1.0 = all the way to the target; lam < 1 =
                                   that fraction of the gap; None = a rule that
                                   is not a constant fraction (to a band edge)

Any trigger can be combined with any fraction (`lam` on every scheduler), which
is what lets the study run a when x how-far factorial (phase 7b) instead of
comparing bundles. Note what this makes explicit: PartialAdjustment, the rule
the study ends up recommending, has a *clock* trigger (every bar) - all of its
feedback is in how far it moves, none in when.

The `family` label below is the study's original taxonomy, kept so every table
and criterion keeps its meaning. It groups rules by the proxy they use for "is
moving worth it?":

  family           proxy for "worth trading"            classical reference
  ---------------- ------------------------------------ ----------------------
  clock            time elapsed                         industry practice
  activity         traded volume (a business clock)     Easley, Lopez de Prado
                                                        & O'Hara (2012)
  price-event      cumulative standardised price move   Lopez de Prado (2018),
                                                        CUSUM filter, ch. 2
  target-event     cumulative motion of the target      this project
  state-feedback   the actual gap between book and      Constantinides (1986);
                   target, and how far to close it      Davis & Norman (1990);
                                                        Garleanu & Pedersen (2013)
  control          benchmarks and placebos              -

Open-loop families (clock, activity) cannot see how wrong the book currently
is. Closed-loop families can. The project's hypothesis is that closed-loop
sampling dominates open-loop sampling at equal trading budget -- the portfolio
analogue of a known result in control engineering:

    Astrom & Bernhardsson (2002), "Comparison of Riemann and Lebesgue sampling
    for first order stochastic systems", Proc. 41st IEEE CDC, 2011-2016.

Each scheduler exposes ONE trigger knob (plus the move fraction), so a family
traces a frontier in (turnover, net Sharpe) space rather than occupying a
single cherry-picked point.

The project's result, stated in these terms: holding the move fraction fixed,
changing the trigger is worth almost nothing; holding the trigger fixed,
changing the move fraction is worth most of the gain (phases 7 and 7b), except
when acting carries a fixed cost per order (phase 6b).
"""
from __future__ import annotations

import numpy as np


def _lam_suffix(lam: float) -> str:
    """Name suffix for a partial move. Empty at lam = 1, so every rule that
    moves all the way keeps the name it has always had in the tables."""
    return "" if lam >= 1.0 else f"-lam{lam:g}"


class Scheduler:
    """Base class. Subclasses implement `_trigger` and optionally `_desired`.

    decide(t, w_now, target, market) -> (desired (S,N), mask (S,))
        desired : the weight vector the scheduler wants to hold.
        mask    : which paths actually trade this bar.

    `_trigger` is the WHEN decision and `_desired` the HOW FAR decision. The
    default `_desired` closes `lam` of the gap, so any trigger can be paired
    with any move fraction.

    Contract: only information dated <= t may be read.
    """

    family: str = "unknown"      # the study's original taxonomy (see module doc)
    trigger: str = "unknown"     # WHEN axis: what decides that this bar trades
    force_initial: bool = True   # take the first position when a target exists

    def __init__(self, knob: float | None = None, label: str | None = None,
                 lam: float = 1.0):
        self.knob = knob
        self._label = label
        self.lam = float(np.clip(lam, 0.0, 1.0))

    # -- the two axes --------------------------------------------------------

    @property
    def move_fraction(self) -> float | None:
        """HOW FAR axis: the fraction of the gap closed on each trade, or None
        when the move is not a constant fraction (e.g. to a band edge)."""
        return self.lam

    @property
    def moves_fully(self) -> bool:
        """True -> trades all the way to the target, so a comparison between
        two such schedulers is a pure test of *when* to trade."""
        return self.move_fraction is not None and self.move_fraction >= 1.0

    # -- naming --------------------------------------------------------------

    @property
    def name(self) -> str:
        if self._label:
            return self._label
        if self.knob is None:
            return type(self).__name__
        return f"{type(self).__name__}({self.knob:g}){_lam_suffix(self.lam)}"

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<{self.name} family={self.family}>"

    # -- lifecycle -----------------------------------------------------------

    def reset(self, S: int, N: int) -> None:
        self.S, self.N = S, N
        self._started = np.zeros(S, dtype=bool)

    def _trigger(self, t, w_now, target, market) -> np.ndarray:
        raise NotImplementedError

    def _desired(self, t, w_now, target, market) -> np.ndarray:
        """Where to move to when triggered: `lam` of the way to the target
        (all the way, exactly, at the default lam = 1)."""
        if self.lam >= 1.0:
            return target
        return w_now + (target - w_now) * self.lam

    def decide(self, t, w_now, target, market):
        mask = self._trigger(t, w_now, target, market)
        if self.force_initial:
            # Every arm takes its first position on the first bar where a
            # target actually exists, not on bar 0 (partial-move rules move
            # only their usual fraction of the way, which may be nothing).
            #
            # This matters more than it looks. During the warm-up the target is
            # all zeros for everybody. A rule that fires on bar 0 and then
            # sleeps - Calendar(126), say - would "rebalance" into an empty
            # target and then sit in cash for 126 bars, losing an eighth of the
            # sample to an artefact of where the warm-up boundary happens to
            # fall. Since the slow calendars are precisely the open-loop
            # benchmark at low turnover, that would quietly flatter every
            # closed-loop rule it is compared against.
            live = np.abs(target).sum(axis=1) > 1e-12
            first = live & ~self._started
            self._started |= live
            mask = mask | first
        desired = self._desired(t, w_now, target, market)
        return desired, mask


# ------------------------------------------------------------------ clock


class Calendar(Scheduler):
    """Rebalance every `step` bars, regardless of what the market did.

    The control group: this is what "month-end rebalancing" means. With
    `lam` < 1 it moves only part of the way on each date, which is the
    clock-timed cell of the when x how-far factorial (Calendar(1, lam) is
    partial adjustment).
    """

    family = "clock"
    trigger = "clock"

    def __init__(self, step: int = 5, lam: float = 1.0):
        super().__init__(knob=float(step), lam=lam)
        self.step = int(max(1, step))

    def _trigger(self, t, w_now, target, market):
        fire = (t % self.step) == 0
        return np.full(w_now.shape[0], fire, dtype=bool)


class AlwaysTrade(Calendar):
    """Trade to the target on every single bar.

    This is the naive benchmark the project must beat: follow the signal
    agnostically, with no regard for volume, price action or the size of the
    move. It maximises fidelity to the paper portfolio and pays the most cost.
    """

    def __init__(self):
        super().__init__(step=1)
        self._label = "AlwaysTrade"


# --------------------------------------------------------------- activity


class VolumeClock(Scheduler):
    """Rebalance every `knob` units of average daily volume traded.

    Sampling in business time rather than calendar time: when the market is
    busy the clock runs fast, when it is quiet it runs slow. Returns sampled on
    a volume clock are closer to i.i.d. normal than calendar-sampled returns.

        Ane & Geman (2000), "Order flow, transaction clock and normality of
        asset returns", Journal of Finance 55(5), 2259-2284.
        Easley, Lopez de Prado & O'Hara (2012), "Flow toxicity and liquidity in
        a high-frequency world", Review of Financial Studies 25(5), 1457-1493.
    """

    family = "activity"
    trigger = "activity"

    def __init__(self, volume_units: float = 5.0, lam: float = 1.0):
        super().__init__(knob=float(volume_units), lam=lam)
        self.volume_units = float(volume_units)

    def reset(self, S, N):
        super().reset(S, N)
        self._acc = np.zeros(S)

    def _trigger(self, t, w_now, target, market):
        dv = market.dollar_volume[:, t, :].sum(axis=1)
        adv = np.maximum(market.adv[:, t, :].sum(axis=1), 1e-12)
        self._acc += dv / adv                       # today's volume, in ADV units
        fire = self._acc >= self.volume_units
        # Subtract rather than zero, so the long-run event rate is exact
        # while the clock runs slower than one event per bar. Below about
        # one ADV per event the trigger saturates at once per bar and the
        # rule degenerates to trading every bar - a grid endpoint, not a
        # separate policy.
        self._acc = np.where(fire, self._acc - self.volume_units, self._acc)
        return fire


# ------------------------------------------------------------ price-event


class PriceCUSUM(Scheduler):
    """The project's original detector: symmetric, volatility-scaled CUSUM.

    Accumulate standardised log returns in two running sums; when either side
    breaches `h`, enough directional information has arrived -- fire and reset.
    Per-asset accumulators; the portfolio fires if ANY asset fires.

        Lopez de Prado (2018), "Advances in Financial Machine Learning", ch. 2.
        Page (1954), "Continuous inspection schemes", Biometrika 41, 100-115.

    Note what this can and cannot see: it watches *prices*. It detects that the
    target has probably moved only when the target is a function of price.
    """

    family = "price-event"
    trigger = "price-event"

    def __init__(self, threshold: float = 1.0, lam: float = 1.0):
        super().__init__(knob=float(threshold), lam=lam)
        self.threshold = float(threshold)

    def reset(self, S, N):
        super().reset(S, N)
        self._pos = np.zeros((S, N))
        self._neg = np.zeros((S, N))

    def _trigger(self, t, w_now, target, market):
        z = np.nan_to_num(market.z_returns[:, t, :], nan=0.0, posinf=0.0, neginf=0.0)
        self._pos = np.maximum(0.0, self._pos + z)
        self._neg = np.minimum(0.0, self._neg + z)
        fired = (self._pos > self.threshold) | (self._neg < -self.threshold)
        self._pos = np.where(fired, 0.0, self._pos)
        self._neg = np.where(fired, 0.0, self._neg)
        return fired.any(axis=1)


# ----------------------------------------------------------- target-event


class TargetCUSUM(Scheduler):
    """Fire when the *target* has travelled far enough since the last trade.

    The natural generalisation of the price CUSUM: it watches the quantity that
    actually matters (the desired book) instead of a proxy for it. It therefore
    remains informative when the alpha updates on information that is not in
    the price -- exactly the case where the price CUSUM goes blind.

    Accumulates the L1 path length of the target, so a target that oscillates
    and returns still registers motion, unlike a pure gap measure.
    """

    family = "target-event"
    trigger = "target-event"

    def __init__(self, threshold: float = 0.5, lam: float = 1.0):
        super().__init__(knob=float(threshold), lam=lam)
        self.threshold = float(threshold)

    def reset(self, S, N):
        super().reset(S, N)
        self._acc = np.zeros(S)
        self._prev = None

    def _trigger(self, t, w_now, target, market):
        if self._prev is None:
            self._prev = target.copy()
            return np.zeros(target.shape[0], dtype=bool)
        self._acc += np.abs(target - self._prev).sum(axis=1)
        self._prev = target.copy()
        fire = self._acc >= self.threshold
        # Trading consumes all accumulated target motion. The jump from an empty
        # warm-up target to the first live one is not motion either: the forced
        # initial trade absorbs it (`_started` is updated after this call).
        self._acc = np.where(fire | ~self._started, 0.0, self._acc)
        return fire


# --------------------------------------------------------- state-feedback


class NoTradeBand(Scheduler):
    """Trade only when the book is further than `tau` (L1) from the target,
    and then only back to the edge of the band.

    Under proportional transaction costs the optimal policy has this shape -
    a no-trade region, trading only to its boundary - for a fixed target. The
    L1 band around a moving target used here is a heuristic of that form.

        Constantinides (1986), "Capital market equilibrium with transaction
        costs", Journal of Political Economy 94(4), 842-862.
        Davis & Norman (1990), "Portfolio selection with transaction costs",
        Mathematics of Operations Research 15(4), 676-713.

    It is included as the theoretical yardstick, so every heuristic can be
    scored against how much of the achievable gap it captures.
    """

    family = "state-feedback"
    trigger = "gap"

    def __init__(self, tau: float = 0.2, to_edge: bool = True):
        super().__init__(knob=float(tau))
        self.tau = float(tau)
        self.to_edge = to_edge
        self._label = f"NoTradeBand({tau:g})" + ("" if to_edge else "-full")

    @property
    def move_fraction(self) -> float | None:
        # Back to the band edge is a move whose fraction depends on the gap.
        return None if self.to_edge else self.lam

    def _gap(self, w_now, target):
        return np.abs(target - w_now).sum(axis=1)

    def _trigger(self, t, w_now, target, market):
        return self._gap(w_now, target) > self.tau

    def _desired(self, t, w_now, target, market):
        if not self.to_edge:
            return target
        gap = np.maximum(self._gap(w_now, target), 1e-12)
        # Move just far enough that the residual L1 gap equals tau.
        frac = np.clip(1.0 - self.tau / gap, 0.0, 1.0)
        return w_now + (target - w_now) * frac[:, None]


class PartialAdjustment(Scheduler):
    """Trade every bar, but only `lam` of the way to the target.

    With quadratic (impact) costs and predictable returns, the optimal policy
    moves a constant fraction toward an *aim* portfolio - a weighted average
    of current and expected future targets - rather than jumping to the
    current one. This rule is the simplified version that aims at the
    current target.

        Garleanu & Pedersen (2013), "Dynamic trading with predictable returns
        and transaction costs", Journal of Finance 68(6), 2309-2340.

    This is the "how far to move" axis in isolation: it never asks *when*.
    Its trigger is the clock (every bar, dust trades skipped), so it is the
    Calendar(1) cell of the factorial with a partial move; it sits in the
    state-feedback family because the size of every trade is set by the gap.
    """

    family = "state-feedback"
    trigger = "clock"

    def __init__(self, lam: float = 0.2, min_trade: float = 1e-4):
        super().__init__(knob=float(lam), lam=lam,
                         label=f"PartialAdjustment({float(lam):g})")
        self.min_trade = float(min_trade)

    def _trigger(self, t, w_now, target, market):
        move = self.lam * np.abs(target - w_now).sum(axis=1)
        return move > self.min_trade      # skip dust trades

    def _desired(self, t, w_now, target, market):
        # Always the formula, even at lam = 1, so PartialAdjustment(1) stays
        # bit-for-bit what it has always been.
        return w_now + (target - w_now) * self.lam


class BandPartial(Scheduler):
    """Hybrid: wait for the gap to exceed `tau` (when), then close `lam` of it
    (how far). Combines both control axes, which is the policy shape suggested
    by impact costs plus a fixed cost of acting."""

    family = "state-feedback"
    trigger = "gap"

    def __init__(self, tau: float = 0.2, lam: float = 0.5):
        super().__init__(knob=float(tau), lam=lam,
                         label=f"BandPartial({tau:g},{lam:g})")
        self.tau = float(tau)

    def _trigger(self, t, w_now, target, market):
        return np.abs(target - w_now).sum(axis=1) > self.tau

    def _desired(self, t, w_now, target, market):
        return w_now + (target - w_now) * self.lam


# ---------------------------------------------------------------- control


class BuyAndHold(Scheduler):
    """Buy the first usable target and never trade again. The passive floor.

    "First usable" means the first bar on which the target is non-zero: during
    the warm-up every arm is flat, and a benchmark that bought an all-zero book
    and then stopped would be measuring nothing at all.
    """

    family = "control"
    trigger = "once"
    force_initial = False

    def __init__(self):
        super().__init__(knob=None, label="BuyAndHold")

    def reset(self, S, N):
        super().reset(S, N)
        self._done = np.zeros(S, dtype=bool)

    def _trigger(self, t, w_now, target, market):
        live = np.abs(target).sum(axis=1) > 1e-12
        fire = live & ~self._done
        self._done |= fire
        return fire


class RandomPlacebo(Scheduler):
    """Trade at random times, at a chosen average rate.

    The falsification test for every event-driven claim: if random timing at
    the same trade count does just as well, the detector is not detecting
    anything. Draws are per path, so a Monte-Carlo run yields a full null
    distribution rather than a single lucky or unlucky draw.

    `lam` lets the placebo copy the *how far* rule of the scheduler it is
    testing, so the only difference left is *when* -- which is what makes it a
    clean null for the event-timing claim rather than a test of two things at
    once.
    """

    family = "control"
    trigger = "random"

    def __init__(self, rate: float = 0.2, seed: int = 0, lam: float = 1.0):
        super().__init__(knob=float(rate), lam=lam,
                         label=f"RandomPlacebo({rate:g})" + (
                             f"-lam{lam:g}" if lam != 1.0 else ""))
        self.rate = float(np.clip(rate, 0.0, 1.0))
        self.seed = int(seed)

    def reset(self, S, N):
        super().reset(S, N)
        self._rng = np.random.default_rng(self.seed)

    def _trigger(self, t, w_now, target, market):
        return self._rng.random(w_now.shape[0]) < self.rate


# ------------------------------------------------------------------ zoo


def default_zoo(
    # The calendar grid is deliberately the densest of the families: it is the
    # benchmark every other rule is interpolated against, and a sparse grid
    # would flatter the challengers by making the interpolation cut a chord
    # under a concave frontier.
    calendar_steps=(1, 2, 3, 4, 5, 7, 10, 14, 21, 32, 42, 63, 90, 126),
    cusum_thresholds=(0.5, 1.0, 2.0, 3.0, 5.0, 8.0, 12.0, 20.0, 32.0),
    target_thresholds=(0.05, 0.1, 0.2, 0.4, 0.8, 1.6, 3.2, 6.4, 12.0),
    # Bands are an L1 distance between two books, so a threshold wider than the
    # largest gap the target can ever open is a rule that never fires. Such an
    # arm holds nothing, has zero return variance, and would otherwise be
    # scored 0.0 and picked as the family's representative at low turnover -
    # a frontier point that is not a policy result at all. The achievable gap
    # is bounded by |target|_1 + |book|_1 <= 2 x gross; lab gross is ~0.9
    # (max ~1.2).
    bands=(0.02, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0),
    lams=(0.01, 0.02, 0.05, 0.1, 0.25, 0.5, 0.75, 1.0),
    volume_units=(1.0, 2.0, 3.0, 5.0, 10.0, 21.0, 50.0, 100.0),
    placebo_rates=(0.008, 0.02, 0.05, 0.1, 0.25, 0.5, 1.0),
    seed: int = 0,
) -> list[Scheduler]:
    """One scheduler per (family, knob) pair -- the full grid that the frontier
    analysis consumes. Knob ranges are chosen so that every family spans
    roughly the same turnover range; that is what makes the frontiers
    comparable rather than the individual points."""
    zoo: list[Scheduler] = []
    # Step 1 is the agnostic benchmark: trade on every signal change. It is
    # named rather than numbered because the whole study is measured against it.
    zoo += [AlwaysTrade() if int(s) == 1 else Calendar(s) for s in calendar_steps]
    zoo += [VolumeClock(v) for v in volume_units]
    zoo += [PriceCUSUM(h) for h in cusum_thresholds]
    zoo += [TargetCUSUM(h) for h in target_thresholds]
    zoo += [NoTradeBand(tau) for tau in bands]
    # The same trigger, but moving all the way: a *pure timing* rule driven by
    # portfolio state, directly comparable with the clock and the detectors.
    zoo += [NoTradeBand(tau, to_edge=False) for tau in bands]
    zoo += [PartialAdjustment(l) for l in lams]
    zoo += [BandPartial(tau, 0.5) for tau in bands]
    # A distinct seed per rate, so the placebo arms are independent draws
    # from the null rather than one schedule sampled at different rates.
    zoo += [RandomPlacebo(r, seed + 7919 * i) for i, r in enumerate(placebo_rates)]
    zoo += [BuyAndHold()]
    return zoo


def factorial_zoo(
    lams=(1.0, 0.5, 0.25),
    calendar_steps=(1, 2, 3, 4, 5, 7, 10, 14, 21, 32, 42, 63, 90, 126),
    volume_units=(1.0, 2.0, 3.0, 5.0, 10.0, 21.0, 50.0, 100.0),
    cusum_thresholds=(0.5, 1.0, 2.0, 3.0, 5.0, 8.0, 12.0, 20.0, 32.0),
    target_thresholds=(0.05, 0.1, 0.2, 0.4, 0.8, 1.6, 3.2, 6.4, 12.0),
    bands=(0.02, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0),
) -> list[Scheduler]:
    """Every trigger crossed with every move fraction: the when x how-far
    factorial (phases 6b and 7b).

    Within one move fraction, the triggers differ only in WHEN; within one
    trigger, the fractions differ only in HOW FAR. Knob grids default to the
    main zoo's, so every rule that also appears there (AlwaysTrade, the
    calendars, PartialAdjustment(lam), BandPartial(tau, lam), the full-move
    triggers) keeps its name and its numbers.
    """
    zoo: list[Scheduler] = []
    for lam in lams:
        full = lam >= 1.0
        zoo += [(AlwaysTrade() if full else PartialAdjustment(lam)) if int(s) == 1
                else Calendar(s, lam=lam) for s in calendar_steps]
        zoo += [VolumeClock(v, lam=lam) for v in volume_units]
        zoo += [PriceCUSUM(h, lam=lam) for h in cusum_thresholds]
        zoo += [TargetCUSUM(h, lam=lam) for h in target_thresholds]
        zoo += [NoTradeBand(tau, to_edge=False) if full else BandPartial(tau, lam)
                for tau in bands]
    return zoo


# Order of the WHEN axis in every table and figure; "event" groups the four
# triggers that are not a clock.
TRIGGER_ORDER = ["clock", "activity", "price-event", "target-event", "gap"]
EVENT_TRIGGERS = {"activity", "price-event", "target-event", "gap"}
TRIGGER_LABEL = {
    "clock": "Calendar (clock)",
    "activity": "Volume clock",
    "price-event": "Price-move trigger",
    "target-event": "Target-move trigger",
    "gap": "Band trigger (gap)",
}


FAMILY_ORDER = [
    "clock",
    "activity",
    "price-event",
    "target-event",
    "state-feedback",
    "control",
]

OPEN_LOOP = {"clock", "activity"}
CLOSED_LOOP = {"price-event", "target-event", "state-feedback"}
